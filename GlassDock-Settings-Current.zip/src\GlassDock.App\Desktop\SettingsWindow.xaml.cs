using GlassDock.Core.Settings;
using GlassDock.Core.Desktop;
using GlassDock.Windows.Settings;
using Microsoft.UI;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;

namespace GlassDock.App.Desktop;

public sealed partial class SettingsWindow : Window
{
    private readonly GlassDockSettingsSession settingsSession;
    private readonly GlassDockSettingsStore settingsStore;
    private readonly ApplicationShutdownState shutdown;
    private bool saving;
    private bool closed;
    private bool populating;

    public SettingsWindow(
        GlassDockSettingsSession settingsSession,
        GlassDockSettingsStore settingsStore,
        ApplicationShutdownState shutdown)
    {
        this.settingsSession = settingsSession;
        this.settingsStore = settingsStore;
        this.shutdown = shutdown;

        InitializeComponent();
        Title = "GlassDock Settings";
        AppWindow.Resize(new global::Windows.Graphics.SizeInt32(720, 820));
        Populate(settingsSession.Current);
        SetStatus("Settings loaded.", success: true);
        Closed += (_, _) => closed = true;
    }

    private void Populate(GlassDockSettings settings)
    {
        populating = true;
        DockAppearanceModeBox.SelectedIndex = (int)settings.DockAppearanceMode;
        DockDisplayModeBox.SelectedIndex = (int)settings.DockDisplayMode;
        BottomMarginBox.Value = settings.BottomMargin;
        AutoHideDelayBox.Value = settings.AutoHideDelayMilliseconds / 1000d;
        PeekDelayBox.Value = settings.PeekDelayMilliseconds / 1000d;
        IconSizeBox.Value = settings.IconSize;
        MagnificationScaleBox.Value = settings.MagnificationScale;
        IconSpacingBox.Value = settings.IconSpacing;
        GlassBlurAmountBox.Value = settings.GlassBlurAmount;
        DockOpacityBox.Value = settings.DockOpacity * 100;
        BorderThicknessBox.Value = settings.BorderThickness;
        BorderOpacityBox.Value = settings.BorderOpacity * 100;
        HoverWaveToggle.IsOn = settings.HoverWaveEnabled;
        populating = false;
    }

    private DockAppearanceMode SelectedDockAppearance =>
        Enum.IsDefined((DockAppearanceMode)DockAppearanceModeBox.SelectedIndex)
            ? (DockAppearanceMode)DockAppearanceModeBox.SelectedIndex
            : DockAppearanceMode.Dark;

    private void DockAppearanceChanged(object sender, SelectionChangedEventArgs e)
    {
        if (populating || SelectedDockAppearance.GlassStyle() is not { } style) return;
        var preset = DockMaterialStylePresets.Create(style);
        GlassBlurAmountBox.Value = preset.BlurAmount;
        DockOpacityBox.Value = preset.Opacity * 100;
        BorderThicknessBox.Value = preset.BorderThickness;
        BorderOpacityBox.Value = preset.BorderOpacity * 100;
    }

    private DockDisplayMode SelectedDisplayMode =>
        DockDisplayModeBox.SelectedIndex switch
        {
            (int)DockDisplayMode.Pointer => DockDisplayMode.Pointer,
            (int)DockDisplayMode.Foreground => DockDisplayMode.Foreground,
            _ => DockDisplayMode.Primary
        };

    private void ResetClick(object sender, RoutedEventArgs e)
    {
        var defaults = settingsSession.CreateDefaultEditableSettings();
        Populate(defaults);
        SetStatus("Defaults are ready. Select Apply to save them.", success: true);
    }

    private async void ApplyClick(object sender, RoutedEventArgs e)
    {
        if (saving || closed || shutdown.IsRequested)
            return;

        saving = true;
        ApplyButton.IsEnabled = false;
        SetStatus("Saving…", success: true);

        try
        {
            var current = settingsSession.Current;
            var edited = settingsSession.CreateDockSettingsUpdate(
                BottomMarginBox.Value,
                ToMilliseconds(
                    AutoHideDelayBox.Value,
                    current.AutoHideDelayMilliseconds),
                ToMilliseconds(
                    PeekDelayBox.Value,
                    current.PeekDelayMilliseconds),
                SelectedDockAppearance.GlassStyle() ?? current.GlassMaterialMode,
                IconSizeBox.Value,
                MagnificationScaleBox.Value,
                IconSpacingBox.Value,
                GlassBlurAmountBox.Value,
                DockOpacityBox.Value / 100,
                BorderThicknessBox.Value,
                BorderOpacityBox.Value / 100,
                SelectedDisplayMode,
                HoverWaveToggle.IsOn) with
            {
                DockAppearanceMode = SelectedDockAppearance
            };

            await settingsStore.SaveAsync(edited, shutdown.CancellationToken);
            if (closed || shutdown.IsRequested)
                return;

            settingsSession.Replace(edited);
            Populate(settingsSession.Current);
            SetStatus("Saved. Changes are active now.", success: true);
        }
        catch (OperationCanceledException) when (shutdown.IsRequested)
        {
        }
        catch (Exception error)
        {
            if (!closed)
                SetStatus($"Settings could not be saved: {error.Message}", success: false);
        }
        finally
        {
            saving = false;
            if (!closed && !shutdown.IsRequested)
                ApplyButton.IsEnabled = true;
        }
    }

    private static int ToMilliseconds(double seconds, int fallback)
    {
        if (!double.IsFinite(seconds))
            return fallback;

        var milliseconds = seconds * 1000;
        if (milliseconds <= int.MinValue)
            return int.MinValue;
        if (milliseconds >= int.MaxValue)
            return int.MaxValue;
        return (int)Math.Round(milliseconds, MidpointRounding.AwayFromZero);
    }

    private void SetStatus(string message, bool success)
    {
        StatusText.Text = message;
        StatusText.Foreground = new SolidColorBrush(success
            ? ColorHelper.FromArgb(255, 151, 208, 192)
            : Colors.IndianRed);
    }
}

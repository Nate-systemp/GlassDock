using GlassDock.Core.Desktop;
using GlassDock.Core.Applications;
using GlassDock.Core.Settings;
using GlassDock.Windows.Interop;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace GlassDock.Windows.Desktop;

public sealed class WindowsKeyboardService : IKeyboardService
{
    private readonly nint hwnd;
    private readonly NativeMethods.SubclassProc callback;
    private readonly bool dockShortcutsEnabled;
    private readonly WindowsInputHelperBridge? elevatedHelper;
    private WindowsKeyHook? hook;
    private readonly UtilityKeyInput? utilityKeys;
    private Func<uint, bool>? volumeKeyHandler;
    private bool suppressDockToggle, captureBareWindowsKey, disposed;
    private uint revision;
    private readonly InputSignalMailbox signals = new();
    private readonly InputLifecycleRecoveryGate lifecycleGate = new();
    private readonly CancellationTokenSource lifecycleLifetime = new();
    private bool sessionNotificationsRegistered, clipboardNotificationsRegistered;
    private nint displayPowerNotification;
    private const uint SignalMessage = 0x8047, OwnershipMessage = 0x8049, SnippingMessage = 0x804A, SnippingEndMessage = 0x804B, ShortcutMessage = 0x804C;
    private const uint PowerBroadcastMessage = 0x0218, PowerSettingChange = 0x8013;
    private const uint PowerSuspend = 0x0004, PowerResumeCritical = 0x0006;
    private const uint PowerResumeSuspend = 0x0007, PowerResumeAutomatic = 0x0012;
    private const uint WtsSessionChange = 0x02B1, WtsNotifyForThisSession = 0;
    private const uint WtsSessionLock = 0x0007, WtsSessionUnlock = 0x0008;
    private const uint DisplayStateOn = 1;
    private static readonly Guid ConsoleDisplayState = new("6fe69556-704a-47a0-8f24-c28d936fda47");

    public bool CaptureBareWindowsKey
    {
        get => captureBareWindowsKey;
        set => captureBareWindowsKey = value;
    }
    public bool SuppressDockToggle
    {
        get => suppressDockToggle;
        set
        {
            if (suppressDockToggle == value) return;
            suppressDockToggle = value;
            revision++;
            UpdateState();
        }
    }
    public bool IsRegistered { get; private set; }
    public Task<bool> RestoreElevatedWindowAsync(ApplicationWindow window) =>
        disposed || elevatedHelper is null || !Applications.WindowsApplicationService.IsEligible(window)
            ? Task.FromResult(false) : elevatedHelper.RestoreWindowAsync(window);
    public event EventHandler? HomeRequested;
    public event Action<int>? DockShortcutRequested;
    public event EventHandler? BareWindowsRequested;
    public event EventHandler? LauncherRequested;
    public event EventHandler? RecoveryRequested;
    public event EventHandler? SnippingRequested;
    public event EventHandler? SnippingCanceled;
    public event EventHandler? ClipboardChanged;
    public event Action<UtilityKind, bool>? UtilityKeyChanged;

    public WindowsKeyboardService(nint hwnd, bool enableDockShortcuts = true, string? elevatedHelperPath = null)
    {
        this.hwnd = hwnd;
        dockShortcutsEnabled = enableDockShortcuts;
        callback = WindowMessage;
        if (!NativeMethods.SetWindowSubclass(hwnd, callback, 1, 0))
            throw new InvalidOperationException("Cannot attach Doky hotkeys.");
        if (enableDockShortcuts)
        {
            utilityKeys = new(hwnd, (kind, down) => UtilityKeyChanged?.Invoke(kind, down));
            clipboardNotificationsRegistered = AddClipboardFormatListener(hwnd);
            sessionNotificationsRegistered = NativeMethods.WTSRegisterSessionNotification(hwnd, WtsNotifyForThisSession);
            var displayState = ConsoleDisplayState;
            displayPowerNotification = NativeMethods.RegisterPowerSettingNotification(hwnd, ref displayState, 0);
        }
        if (enableDockShortcuts) NativeMethods.RegisterHotKey(hwnd, 0x4701, 0x4003, 0x20);
        IsRegistered = NativeMethods.RegisterHotKey(hwnd, 0x4702, 0x4003, 0x7B);
        StartFallback();
        if (enableDockShortcuts && !string.IsNullOrWhiteSpace(elevatedHelperPath) && File.Exists(elevatedHelperPath))
        {
            elevatedHelper = new WindowsInputHelperBridge(elevatedHelperPath,
                take => NativeMethods.PostMessageW(hwnd, OwnershipMessage, take ? 1u : 0u, 0),
                PostSignal,
                PostSnipping,
                PostSnippingCancel,
                PostShortcut,
                key => Volatile.Read(ref volumeKeyHandler)?.Invoke(key));
            UpdateState();
        }
    }

    private void UpdateState()
    {
        var captureWinDown = dockShortcutsEnabled;
        hook?.UpdateState(suppressDockToggle, captureWinDown, revision);
        elevatedHelper?.UpdateState(suppressDockToggle, captureWinDown, revision);
    }
    public void SetVolumeKeyHandler(Func<uint, bool>? handler)
    {
        if (disposed) return;
        Volatile.Write(ref volumeKeyHandler, handler);
        elevatedHelper?.UpdateVolumeCapture(handler is not null);
    }
    private void StartFallback()
    {
        if (!dockShortcutsEnabled || disposed || hook is not null) return;
        hook = new WindowsKeyHook((launcher, version) =>
            PostSignal(new InputSignal(launcher, version, Environment.TickCount64)),
            PostSnipping,
            PostSnippingCancel,
            PostShortcut);
        UpdateState();
    }
    private void PostSignal(InputSignal signal)
    {
        if (signals.Publish(signal)) NativeMethods.PostMessageW(hwnd, SignalMessage, 0, 0);
    }

    private void PostShortcut(int index, uint version) => NativeMethods.PostMessageW(hwnd, ShortcutMessage, version, index);
    private void PostSnipping(uint version) => NativeMethods.PostMessageW(hwnd, SnippingMessage, version, 0);
    private void PostSnippingCancel(uint version) => NativeMethods.PostMessageW(hwnd, SnippingEndMessage, version, 0);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool AddClipboardFormatListener(nint hwnd);
    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool RemoveClipboardFormatListener(nint hwnd);

    private void MarkLifecycleBoundary(string reason)
    {
        if (disposed) return;
        lifecycleGate.MarkBoundary();
        utilityKeys?.Reset();
        revision++;
        signals.Clear();
        hook?.ResetInputState();
        UpdateState();
        Debug.WriteLine($"Doky input lifecycle boundary: {reason}; revision={revision}");
    }

    private void RequestLifecycleRecovery(string reason)
    {
        if (disposed || !lifecycleGate.RequestRecovery()) return;
        utilityKeys?.Reset();
        revision++;
        signals.Clear();
        UpdateState();

        if (hook is not null)
        {
            try { hook.RecoverAfterResume(); }
            catch (Exception error) when (error is InvalidOperationException or Win32Exception)
            {
                Debug.WriteLine($"Doky fallback hook recovery deferred (previous hook retained): {error.Message}");
            }
        }
        else if (elevatedHelper is null)
        {
            try { StartFallback(); }
            catch (Exception fallbackError) when (fallbackError is InvalidOperationException or Win32Exception)
            { Debug.WriteLine($"Doky fallback hook start failed: {fallbackError.Message}"); }
        }

        var helper = elevatedHelper;
        if (helper is null) return;
        _ = RecoverHelperAsync(helper, reason);
    }

    private async Task RecoverHelperAsync(WindowsInputHelperBridge helper, string reason)
    {
        try
        {
            await helper.RecoverAsync().WaitAsync(lifecycleLifetime.Token);
            Debug.WriteLine($"Doky input lifecycle recovery completed: {reason}; revision={revision}");
        }
        catch (OperationCanceledException) when (lifecycleLifetime.IsCancellationRequested) { }
        catch (Exception error) when (error is IOException or InvalidOperationException or TimeoutException or ObjectDisposedException)
        { Debug.WriteLine($"Doky input lifecycle recovery deferred: {error.Message}"); }
    }

    private static bool IsDisplayOn(nint lParam)
    {
        if (lParam == 0) return true;
        try
        {
            return Marshal.ReadInt32(lParam, 20) == DisplayStateOn;
        }
        catch (AccessViolationException) { return true; }
    }

    private nint WindowMessage(nint window, uint message, nuint wParam, nint lParam, nuint id, nuint data)
    {
        if (!disposed && message == 0x00FF) utilityKeys?.Read(lParam);
        if (!disposed && message == 0x00FE && wParam == 2) utilityKeys?.Remove(lParam);
        if (message == PowerBroadcastMessage)
        {
            switch ((uint)wParam)
            {
                case PowerSuspend:
                    MarkLifecycleBoundary("suspend");
                    return 1;
                case PowerResumeCritical:
                case PowerResumeSuspend:
                case PowerResumeAutomatic:
                    RequestLifecycleRecovery("resume");
                    return 1;
                case PowerSettingChange:
                    if (IsDisplayOn(lParam)) RequestLifecycleRecovery("display-on");
                    else MarkLifecycleBoundary("display-off");
                    return 1;
            }
        }
        if (message == WtsSessionChange)
        {
            switch ((uint)wParam)
            {
                case WtsSessionLock:
                    MarkLifecycleBoundary("session-lock");
                    break;
                case WtsSessionUnlock:
                    RequestLifecycleRecovery("session-unlock");
                    break;
            }
            return 0;
        }
        if (message == ShortcutMessage)
        {
            var index = (int)lParam;
            if (!disposed && dockShortcutsEnabled && !suppressDockToggle &&
                (uint)wParam == revision && index is >= 0 and <= 9)
                DockShortcutRequested?.Invoke(index);
            return 0;
        }
        if (message == SnippingMessage)
        {
            if (!disposed && dockShortcutsEnabled && (uint)wParam == revision)
                SnippingRequested?.Invoke(this, EventArgs.Empty);
            return 0;
        }
        if (message == SnippingEndMessage)
        {
            if (!disposed && (uint)wParam == revision)
                SnippingCanceled?.Invoke(this, EventArgs.Empty);
            return 0;
        }
        if (message == 0x031D)
        {
            if (!disposed) ClipboardChanged?.Invoke(this, EventArgs.Empty);
            return NativeMethods.DefSubclassProc(window, message, wParam, lParam);
        }
        if (message == OwnershipMessage)
        {
            if (!disposed && elevatedHelper is not null)
            {
                if (wParam == 1)
                {
                    hook?.Dispose(); hook = null;
                    signals.Clear();
                    elevatedHelper.AllowHelper();
                }
                else StartFallback();
            }
            return 0;
        }
        if (message == SignalMessage)
        {
            var signal = signals.Take(Environment.TickCount64);
            if (!disposed && signal is not null && signal.Revision == revision && !suppressDockToggle)
            {
                if (signal.Launcher) LauncherRequested?.Invoke(this, EventArgs.Empty);
                else BareWindowsRequested?.Invoke(this, EventArgs.Empty);
            }
            return 0;
        }
        if (message == 0x0021) return 3;
        if (message == 0x0312)
        {
            if (wParam == 0x4701 && !suppressDockToggle) HomeRequested?.Invoke(this, EventArgs.Empty);
            if (wParam == 0x4702) RecoveryRequested?.Invoke(this, EventArgs.Empty);
            return 0;
        }
        return NativeMethods.DefSubclassProc(window, message, wParam, lParam);
    }
    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        lifecycleLifetime.Cancel();
        lifecycleGate.Shutdown();
        signals.Clear();
        elevatedHelper?.Dispose();
        utilityKeys?.Dispose();
        hook?.Dispose(); hook = null;
        if (clipboardNotificationsRegistered) RemoveClipboardFormatListener(hwnd);
        if (sessionNotificationsRegistered) NativeMethods.WTSUnRegisterSessionNotification(hwnd);
        if (displayPowerNotification != 0) NativeMethods.UnregisterPowerSettingNotification(displayPowerNotification);
        NativeMethods.UnregisterHotKey(hwnd, 0x4701);
        NativeMethods.UnregisterHotKey(hwnd, 0x4702);
        NativeMethods.RemoveWindowSubclass(hwnd, callback, 1);
        IsRegistered = false;
    }
}

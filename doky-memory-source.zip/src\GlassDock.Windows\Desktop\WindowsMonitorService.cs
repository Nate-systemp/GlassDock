using System.ComponentModel;
using System.Runtime.InteropServices;
using GlassDock.Core.Applications;
using GlassDock.Core.Desktop;
using GlassDock.Windows.Interop;

namespace GlassDock.Windows.Desktop;

public readonly record struct DesktopMonitor(
    nint Handle,
    PixelRect Bounds,
    bool IsPrimary)
{
    public string Key => $"0x{Handle.ToInt64():X}";
}

public static class WindowsMonitorService
{
    public static nint ForegroundMonitorHandle() => NativeMethods.MonitorFromWindow(NativeMethods.GetForegroundWindow(), 2);

    public static PixelRect GetWorkAreaForWindow(nint window)
    {
        var monitor = NativeMethods.MonitorFromWindow(window, 2);
        var info = new NativeMethods.MonitorInfo { Size = Marshal.SizeOf<NativeMethods.MonitorInfo>() };
        if (!NativeMethods.GetMonitorInfo(monitor, ref info))
            throw new Win32Exception(Marshal.GetLastWin32Error());

        return new PixelRect(info.Work.Left, info.Work.Top,
            info.Work.Right - info.Work.Left, info.Work.Bottom - info.Work.Top);
    }

    public static void BringWindowToFront(nint window)
    {
        NativeMethods.ShowWindow(window, 9);
        GlassDock.Windows.Applications.ApplicationNative.SetForegroundWindow(window);
    }

    public static IReadOnlyList<DesktopMonitor> GetMonitors()
    {
        var result = new List<DesktopMonitor>();
        NativeMethods.MonitorEnumProc callback = (nint monitor, nint hdc, ref NativeMethods.Rect monitorRect, nint data) =>
        {
            var info = new NativeMethods.MonitorInfo
            {
                Size = Marshal.SizeOf<NativeMethods.MonitorInfo>()
            };

            if (!NativeMethods.GetMonitorInfo(monitor, ref info))
                return true;

            result.Add(new DesktopMonitor(
                monitor,
                new PixelRect(
                    info.Monitor.Left,
                    info.Monitor.Top,
                    info.Monitor.Right - info.Monitor.Left,
                    info.Monitor.Bottom - info.Monitor.Top),
                (info.Flags & 1u) != 0));
            return true;
        };

        if (!NativeMethods.EnumDisplayMonitors(0, 0, callback, 0))
            throw new Win32Exception(Marshal.GetLastWin32Error());

        GC.KeepAlive(callback);
        return result
            .OrderByDescending(monitor => monitor.IsPrimary)
            .ThenBy(monitor => monitor.Bounds.X)
            .ThenBy(monitor => monitor.Bounds.Y)
            .ToArray();
    }

    public static nint PrimaryMonitorHandle()
    {
        var primary = GetMonitors().FirstOrDefault(monitor => monitor.IsPrimary);
        if (primary.Handle != 0)
            return primary.Handle;

        return NativeMethods.MonitorFromPoint(new NativeMethods.Point(), 1);
    }

    public static ApplicationSnapshot FilterSnapshotForMonitor(
        ApplicationSnapshot snapshot,
        nint monitor)
    {
        if (monitor == 0)
            return snapshot;

        return DockApplicationMonitorFilter.ForMonitor(
            snapshot,
            window => window.Handle != 0 &&
                NativeMethods.MonitorFromWindow((nint)window.Handle, 2) == monitor);
    }
}

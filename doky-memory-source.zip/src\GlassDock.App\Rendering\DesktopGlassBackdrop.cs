using System.Numerics;
using System.Runtime.InteropServices;
using Microsoft.Graphics.Canvas;
using Microsoft.Graphics.Canvas.Geometry;
using Microsoft.Graphics.Canvas.Effects;
using GlassDock.Core.Materials;
using GlassDock.Core.Settings;
using Microsoft.UI.Composition;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Media;
using W = global::Windows.UI.Composition;

namespace GlassDock.App.Rendering;

internal sealed class DesktopGlassBackdrop : SystemBackdrop
{
    internal event EventHandler? PopupSurfaceChanged;
    internal DockAppearanceMode PopupMode { get; private set; }
    internal LiquidGlassMaterial PopupOptics { get; private set; } = new() { RefractionStrength = 12 };
    internal void SetPopupMode(DockAppearanceMode mode, LiquidGlassMaterial optics)
    {
        PopupMode = mode;
        PopupOptics = optics;
        PopupSurfaceChanged?.Invoke(this, EventArgs.Empty);
    }
    private double SurfaceLeft => (lastWindowWidth - lastWidth) / 2;
    internal (Vector4 Bounds, float Radius, float Scale) PopupGeometry =>
        (new((float)SurfaceLeft,
            (float)(lastWindowHeight - lastBottom - lastHeight), (float)lastWidth, (float)lastHeight),
            (float)Math.Min(material.CornerRadius, Math.Min(lastWidth, lastHeight) / 2), (float)lastScale);
    private GlassDock.Core.Desktop.HomeCardRect[]? surfaceRegions;
    private double surfaceRegionScale = 1;
    private (Vector4 Bounds, float Opacity)[] utilitySurfaces = [];
    private readonly List<UtilityMask> utilityMasks = [];
    private W.ContainerVisual? utilityMaskRoot;
    internal bool SupportsUtilitySurfaces => utilityMaskRoot is not null && !UseSolidSurface &&
        dockStyle is (GlassMaterialMode.Frosted or GlassMaterialMode.Acrylic);

    internal void SetUtilitySurfaces(IEnumerable<(Vector4 Bounds, float Opacity)> surfaces)
    {
        var next = surfaces.ToArray();
        if (utilitySurfaces.SequenceEqual(next)) return;
        utilitySurfaces = next;
        UpdateUtilityMasks();
    }

    private sealed class UtilityMask : IDisposable
    {
        internal required W.ShapeVisual Visual;
        internal required W.CompositionPathGeometry Geometry;
        internal required W.CompositionSpriteShape Shape;
        internal CanvasGeometry? Path;
        internal Vector4 Bounds;
        internal double Scale;
        public void Dispose() { Visual.Dispose(); Shape.Dispose(); Geometry.Dispose(); Path?.Dispose(); }
    }

    private void UpdateUtilityMasks()
    {
        if (utilityMaskRoot is null || compositor is null || canvasDevice is null || fill is null || !hasBounds) return;
        for (var i = utilitySurfaces.Length; i < utilityMasks.Count; i++)
            utilityMasks[i].Visual.Opacity = 0;
        var sampling = UseInnerEdge || UseSolidSurface ? 2f : 1f;
        var size = new Vector2((float)(lastWindowWidth * lastScale), (float)(lastWindowHeight * lastScale)) * sampling;
        utilityMaskRoot.Size = size;
        for (var i = 0; i < utilitySurfaces.Length; i++)
        {
            if (i == utilityMasks.Count)
            {
                var path = compositor.CreatePathGeometry();
                var shape = compositor.CreateSpriteShape(path); shape.FillBrush = fill;
                var visual = compositor.CreateShapeVisual(); visual.BorderMode = W.CompositionBorderMode.Soft;
                visual.Shapes.Add(shape); utilityMaskRoot.Children.InsertAtTop(visual);
                utilityMasks.Add(new() { Geometry = path, Shape = shape, Visual = visual });
            }
            var entry = utilitySurfaces[i]; var mask = utilityMasks[i];
            if (mask.Path is null || mask.Bounds != entry.Bounds || mask.Scale != lastScale)
            {
                var rect = entry.Bounds * (float)lastScale;
                var radius = Math.Min(rect.Z, rect.W) / 2;
                var next = CanvasGeometry.CreateRoundedRectangle(canvasDevice, rect.X, rect.Y, rect.Z, rect.W, radius, radius);
                mask.Geometry.Path = new W.CompositionPath(next);
                mask.Path?.Dispose(); mask.Path = next; mask.Bounds = entry.Bounds; mask.Scale = lastScale;
            }
            mask.Visual.Size = size; mask.Shape.Scale = new(sampling);
            mask.Visual.Opacity = Math.Clamp(entry.Opacity * (VisualMaterial?.SurfaceOpacity ?? 1), 0, 1);
        }
    }

    public void SetSurfaceRegions(IEnumerable<GlassDock.Core.Desktop.HomeCardRect> regions, double contentScale = 1)
    {
        var next = regions.ToArray();
        if (surfaceRegions is not null && surfaceRegions.SequenceEqual(next) && surfaceRegionScale == contentScale) return;
        surfaceRegions = next;
        surfaceRegionScale = contentScale;
        renderedMask = null;
        UpdateMaskPath();
    }
    public bool UseInnerEdge { get; set; }
    public bool UseDockSpecular { get; set; }
    public bool CircularHighlightsEnabled { get; set; } = true;
    public double DockLayoutScale { get; set; } = 1;
    public double SpecularHighlightAngle { get; set; } = 45;
    public LiquidGlassMaterial? VisualMaterial { get; set; }
    private GlassMaterialMode? dockStyle;
    private ClearDockSpecular? clearSpecular;
    private bool clearSpecularUnavailable;

    public void ApplyMainDock(GlassMaterialMode style, GlassMaterial value)
    {
        var qualityChanged = material.BlurQuality != value.BlurQuality;
        dockStyle = style;
        Apply(value);
        if (qualityChanged) RebuildConnectedSurface();
    }
    public bool UseSolidSurface { get; set; }
    private double presentationOpacity = 1;
    private Matrix4x4 presentationTransform = Matrix4x4.Identity;
    private BackdropCompositionTrack? bodyTrack, rimTrack;

    public void AnimatePresentation(PopupCompositionFrame[] frames, TimeSpan duration)
    {
        if (visual is null) return;
        bodyTrack ??= new BackdropCompositionTrack(visual);
        bodyTrack.Bind();
        var units = (float)(lastScale * (UseInnerEdge || UseSolidSurface ? 2 : 1));
        bodyTrack.Start(frames, duration, units);
        if (edgeVisual is not null)
        {
            rimTrack ??= new BackdropCompositionTrack(edgeVisual, animateOpacity: false);
            rimTrack.Bind();
            rimTrack.Start(frames, duration, units);
        }
    }

    public void StopPresentationAnimation()
    {
        bodyTrack?.Stop();
        rimTrack?.Stop();
    }

    public void SetPresentationTransform(Matrix4x4 transform, double opacity)
    {
        presentationTransform = transform;
        presentationOpacity = Math.Clamp(opacity, 0, 1);
        ApplyPresentation();
    }

    private void ApplyPresentation()
    {
        if (visual is null)
            return;

        var units = (float)(lastScale * (UseInnerEdge || UseSolidSurface ? 2 : 1));
        var matrix = Matrix4x4.CreateScale(1 / units, 1 / units, 1) * presentationTransform *
            Matrix4x4.CreateScale(units, units, 1);

        clearSpecular?.SetTransform(matrix);
        visual.TransformMatrix = matrix;
        visual.Opacity = liquidActive ? 0 : (float)(presentationOpacity * lastOpacity * (VisualMaterial?.SurfaceOpacity ?? 1));

        if (edgeVisual is not null)
            edgeVisual.TransformMatrix = matrix;
    }
    private W.CompositionEffectFactory? edgeFactory;
    private W.CompositionEffectBrush? edgeEffect;
    private W.CompositionSpriteShape? edgeShape;
    private W.ShapeVisual? edgeVisual;
    private W.ContainerVisual? edgeCaptureRoot;
    private W.CompositionVisualSurface? edgeSurface;
    private W.CompositionSurfaceBrush? edgeMask;
    private W.CompositionColorBrush? edgeFill;

    private W.CompositionPathGeometry? specularLeftTopGeometry;
    private W.CompositionPathGeometry? specularRightTopGeometry;
    private W.CompositionPathGeometry? specularLeftBottomGeometry;
    private W.CompositionSpriteShape? specularLeftTopShape;
    private W.CompositionSpriteShape? specularRightTopShape;
    private W.CompositionSpriteShape? specularLeftBottomShape;
    private W.CompositionColorBrush? specularFill;
    private CanvasGeometry? specularLeftTopCanvas;
    private CanvasGeometry? specularRightTopCanvas;
    private CanvasGeometry? specularLeftBottomCanvas;

    private W.Compositor? compositor;
    private W.CompositionEffectFactory? factory;
    private W.CompositionEffectBrush? effect;
    private W.CompositionBackdropBrush? source;
    private W.CompositionColorBrush? solidSurface;
    private W.CompositionPathGeometry? geometry;
    private W.CompositionSpriteShape? shape;
    private CanvasDevice? canvasDevice;
    private CanvasGeometry? canvasGeometry;
    internal CanvasGeometry? DockGeometry => surfaceRegions is null ? canvasGeometry : null;
    private bool liquidActive;
    internal void SetLiquidActive(bool active)
    {
        if (liquidActive == active) return;
        liquidActive = active;
        ApplyPresentation();
    }
    private readonly record struct MaskState(double WindowWidth, double WindowHeight, double Width,
        double Height, double Bottom, double Scale, double Radius, bool Wave, double Center,
        double HalfWidth, double Rise, double Strength);
    private MaskState? renderedMask;
    private W.CompositionColorBrush? fill;
    private W.ShapeVisual? visual;
    private W.ContainerVisual? maskCaptureRoot;
    private W.CompositionVisualSurface? maskSurface;
    private W.CompositionSurfaceBrush? mask;
    private W.CompositionMaskBrush? output;
    private W.CompositionBrush? fallback;
    private GlassMaterial material = new();
    private DockAppearanceMode solidAppearance = DockAppearanceMode.Dark;
    private double solidOpacity = 1;
    private double solidCornerRadius = 28;

    private bool hasBounds;
    private double lastWindowWidth;
    private double lastWindowHeight;
    private double lastWidth;
    private double lastHeight;
    private double lastBottom;
    private double lastScale = 1;
    private double lastOpacity = 1;

    private bool waveEnabled;
    private double waveCenterX;
    private double waveHalfWidth = 68;
    private double waveRise = 18;
    private double waveStrength;

    public string RenderingMode { get; private set; } = "Desktop backdrop connecting";
    public event EventHandler? RenderingModeChanged;
    private int connectionVersion;
    private FrameworkElement? loadingRoot;
    private RoutedEventHandler? loadedHandler;
    private ICompositionSupportsSystemBackdrop? connectedTarget;
    private FrameworkElement? connectedRoot;

    public void RebuildConnectedSurface()
    {
        var target = connectedTarget;
        if (target is null || compositor is null)
        {
            return;
        }

        try
        {
            ReleaseDesktop(target);
            ConnectDesktop(target);
            if (connectedRoot is not null)
                SetSurfaceFallback(connectedRoot, false);
        }
        catch (Exception error) when (OptionalComposition.IsRenderingFailure(error))
        {
            ReleaseDesktop(target);
            if (Application.Current is App app)
                app.DisableDesktopComposition(error);
            RenderingMode = "Basic XAML surface · desktop composition unavailable";
            if (connectedRoot is not null)
                SetSurfaceFallback(connectedRoot, true);
            RenderingModeChanged?.Invoke(this, EventArgs.Empty);
        }
    }

    protected override void OnTargetConnected(ICompositionSupportsSystemBackdrop target, XamlRoot xamlRoot)
    {
        base.OnTargetConnected(target, xamlRoot);
        connectedTarget = target;
        connectedRoot = xamlRoot.Content as FrameworkElement;
        var version = ++connectionVersion;
        StartupDiagnostics.Write($"Backdrop target connected: root={xamlRoot.Content?.GetType().Name ?? "missing"}");
        if (xamlRoot.Content is not FrameworkElement root) return;
        void QueueConnection()
        {
            SetSurfaceFallback(root, true);
            root.DispatcherQueue.TryEnqueue(Microsoft.UI.Dispatching.DispatcherQueuePriority.Low, () =>
            {
                if (version != connectionVersion) return;
                RenderingMode = "Basic XAML surface";
                if ((Application.Current as App)?.TryEnableDesktopComposition() == true)
                {
                    try
                    {
                        StartupDiagnostics.Write("Loaded window: Win2D/backdrop initializing");
                        ConnectDesktop(target);
                        SetSurfaceFallback(root, false);
                        StartupDiagnostics.Write("Desktop backdrop ready");
                    }
                    catch (Exception error) when (OptionalComposition.IsRenderingFailure(error))
                    {
                        ReleaseDesktop(target);
                        ((App)Application.Current).DisableDesktopComposition(error);
                        RenderingMode = "Basic XAML surface · desktop composition unavailable";
                        SetSurfaceFallback(root, true);
                    }
                }
                RenderingModeChanged?.Invoke(this, EventArgs.Empty);
            });
        }
        if (root.IsLoaded) QueueConnection();
        else
        {
            loadingRoot = root;
            loadedHandler = (_, _) =>
            {
                root.Loaded -= loadedHandler;
                loadedHandler = null;
                loadingRoot = null;
                if (version == connectionVersion) QueueConnection();
            };
            root.Loaded += loadedHandler;
        }
    }

    private static void SetSurfaceFallback(DependencyObject element, bool enabled)
    {
        if (element is Controls.GlassSurface surface && surface.UseDesktopBackdrop)
            surface.SetDesktopFallback(enabled);
        for (var i = 0; i < VisualTreeHelper.GetChildrenCount(element); i++)
            SetSurfaceFallback(VisualTreeHelper.GetChild(element, i), enabled);
    }

    private void ConnectDesktop(ICompositionSupportsSystemBackdrop target)
    {
        compositor = new W.Compositor();
        canvasDevice = CanvasDevice.GetSharedDevice();
        geometry = compositor.CreatePathGeometry();
        shape = compositor.CreateSpriteShape(geometry);
        fill = compositor.CreateColorBrush(global::Windows.UI.Color.FromArgb(255, 255, 255, 255));
        shape.FillBrush = fill;
        visual = compositor.CreateShapeVisual();
        visual.BorderMode = W.CompositionBorderMode.Soft;
        visual.Shapes.Add(shape);
        maskCaptureRoot = compositor.CreateContainerVisual();
        maskCaptureRoot.Children.InsertAtTop(visual);
        utilityMaskRoot = compositor.CreateContainerVisual();
        maskCaptureRoot.Children.InsertAtTop(utilityMaskRoot);
        maskSurface = compositor.CreateVisualSurface();
        maskSurface.SourceVisual = maskCaptureRoot;
        mask = compositor.CreateSurfaceBrush(maskSurface);
        mask.Stretch = W.CompositionStretch.Fill;
        mask.BitmapInterpolationMode = W.CompositionBitmapInterpolationMode.Linear;
        output = compositor.CreateMaskBrush();
        output.Mask = mask;

        if (UseSolidSurface)
        {
            solidSurface = compositor.CreateColorBrush(SolidColor(solidAppearance, solidOpacity));
            output.Source = solidSurface;
            material = material with
            {
                CornerRadius = solidCornerRadius,
                BorderOpacity = 0,
                BorderThickness = 0,
                EdgeHighlight = 0
            };
            RenderingMode = "Solid dock surface";
            Apply(material);
            if (hasBounds)
                ApplyBounds(
                    lastWindowWidth,
                    lastWindowHeight,
                    lastWidth,
                    lastHeight,
                    lastBottom,
                    lastScale,
                    lastOpacity);

            target.SystemBackdrop = output;
            RenderingModeChanged?.Invoke(this, EventArgs.Empty);
            return;
        }

        var stage = "backdrop source";
        try
        {
            source = compositor.CreateBackdropBrush();
            stage = "effect factory";
            factory = compositor.CreateEffectFactory(
                GlassEffectGraph.Create(new W.CompositionEffectSourceParameter("Backdrop"), new W.CompositionEffectSourceParameter("BaseBackdrop"), material.BlurQuality),
                GlassEffectGraph.Properties.Concat(new[] { "BaseBlur.BlurAmount" }));
            stage = "effect brush";
            effect = factory.CreateBrush();
            effect.SetSourceParameter("Backdrop", source);
            effect.SetSourceParameter("BaseBackdrop", source);
            output.Source = effect;
            if (UseInnerEdge)
            {
                edgeShape = compositor.CreateSpriteShape(geometry);
                edgeFill = compositor.CreateColorBrush(global::Windows.UI.Color.FromArgb(30, 255, 255, 255));
                edgeShape.StrokeBrush = edgeFill;

                specularLeftTopGeometry = compositor.CreatePathGeometry();
                specularRightTopGeometry = compositor.CreatePathGeometry();
                specularLeftBottomGeometry = compositor.CreatePathGeometry();
                specularFill = compositor.CreateColorBrush(
                    global::Windows.UI.Color.FromArgb(90, 255, 255, 255));

                specularLeftTopShape = compositor.CreateSpriteShape(specularLeftTopGeometry);
                specularRightTopShape = compositor.CreateSpriteShape(specularRightTopGeometry);
                specularLeftBottomShape = compositor.CreateSpriteShape(specularLeftBottomGeometry);
                specularLeftTopShape.StrokeBrush = specularFill;
                specularRightTopShape.StrokeBrush = specularFill;
                specularLeftBottomShape.StrokeBrush = specularFill;

                edgeVisual = compositor.CreateShapeVisual();
                edgeVisual.BorderMode = W.CompositionBorderMode.Soft;
                edgeVisual.Shapes.Add(edgeShape);
                edgeVisual.Shapes.Add(specularLeftTopShape);
                edgeVisual.Shapes.Add(specularRightTopShape);
                edgeVisual.Shapes.Add(specularLeftBottomShape);
                edgeCaptureRoot = compositor.CreateContainerVisual();
                edgeCaptureRoot.Children.InsertAtTop(edgeVisual);
                edgeSurface = compositor.CreateVisualSurface();
                edgeSurface.SourceVisual = edgeCaptureRoot;
                edgeMask = compositor.CreateSurfaceBrush(edgeSurface);
                edgeMask.Stretch = W.CompositionStretch.Fill;
                edgeMask.BitmapInterpolationMode = W.CompositionBitmapInterpolationMode.Linear;
                edgeFactory = compositor.CreateEffectFactory(new CompositeEffect
                {
                    Mode = CanvasComposite.SourceOver,
                    Sources =
                    {
                        new W.CompositionEffectSourceParameter("Body"),
                        new AlphaMaskEffect
                        {
                            Source = new ExposureEffect { Exposure = .35f,
                                Source = new SaturationEffect { Saturation = 1.12f,
                                    Source = new W.CompositionEffectSourceParameter("BodyEdge") } },
                            AlphaMask = new W.CompositionEffectSourceParameter("EdgeMask")
                        }
                    }
                });
                edgeEffect = edgeFactory.CreateBrush();
                edgeEffect.SetSourceParameter("Body", effect);
                edgeEffect.SetSourceParameter("BodyEdge", effect);
                edgeEffect.SetSourceParameter("EdgeMask", edgeMask);
                output.Source = edgeEffect;
            }
            RenderingMode = "Native system backdrop · shared glass graph";
            stage = "material parameters";
            Apply(material);

            if (hasBounds)
                ApplyBounds(
                    lastWindowWidth,
                    lastWindowHeight,
                    lastWidth,
                    lastHeight,
                    lastBottom,
                    lastScale,
                    lastOpacity);
        }
        catch (Exception exception) when (exception is COMException or ArgumentException)
        {
            fallback = compositor.CreateColorBrush(global::Windows.UI.Color.FromArgb(230, 35, 45, 62));
            output.Source = fallback;
            RenderingMode = $"Desktop solid fallback: {stage} (0x{exception.HResult:X8})";
            StartupDiagnostics.Write($"{RenderingMode}: {exception}");
        }
        target.SystemBackdrop = output;
        RenderingModeChanged?.Invoke(this, EventArgs.Empty);
    }

    private bool boundsDirty = true;

    public void Apply(GlassMaterial value)
    {
        boundsDirty = true;
        material = RefractionLayer.ForNativeBackend(value);
        if (edgeShape is not null)
        {
            edgeShape.StrokeThickness = (float)(material.BorderThickness * 6 * lastScale);

            edgeFill!.Color = global::Windows.UI.Color.FromArgb(
                (byte)Math.Clamp(material.BorderOpacity * 72, 0, 92),
                255, 255, 255);

            if (specularFill is not null)
            {
                specularFill.Color = global::Windows.UI.Color.FromArgb(
                    (byte)Math.Clamp(38 + material.BorderOpacity * 170, 38, 142),
                    255, 255, 255);
            }

            var glintThickness = (float)(material.BorderThickness * 4.2 * lastScale);
            if (specularLeftTopShape is not null) specularLeftTopShape.StrokeThickness = glintThickness;
            if (specularRightTopShape is not null) specularRightTopShape.StrokeThickness = glintThickness;
            if (specularLeftBottomShape is not null) specularLeftBottomShape.StrokeThickness = glintThickness;
        }

        if (effect is not null)
        {
            foreach (var (name, scalar) in GlassEffectGraph.Scalars(material))
                effect.Properties.InsertScalar(name, scalar);

            var baseBlur = DockMaterialRendering.BaseBlur(dockStyle, material.BlurAmount);
            effect.Properties.InsertScalar("BaseBlur.BlurAmount", (float)baseBlur);

            effect.Properties.InsertColor(
                "Tint.Color",
                GlassEffectGraph.Tint(material));
        }

        W.CompositionBrush? specularBody = UseSolidSurface ? solidSurface :
            VisualMaterial is { EdgeOpacity: > 0 } ? edgeEffect ?? effect : effect;
        if ((UseInnerEdge || UseDockSpecular) && specularBody is not null && fallback is null && output is not null)
        {
            if (CircularHighlightsEnabled && (UseDockSpecular || dockStyle == GlassMaterialMode.Clear) && surfaceRegions is null && !clearSpecularUnavailable)
            {
                try
                {
                    clearSpecular ??= new ClearDockSpecular(compositor!, geometry!, specularBody);
                    clearSpecular.Brush.SetSourceParameter("Body", specularBody);
                    clearSpecular.Apply(UseDockSpecular
                        ? material with { BorderThickness = .35 * DockLayoutScale, BorderOpacity = UseSolidSurface
                            ? (solidAppearance == DockAppearanceMode.Light ? .45 : .24) : .28 }
                        : material, diagonalCatches: UseDockSpecular, optics: VisualMaterial);
                    clearSpecular.SetVisible(true);
                    UpdateClearBounds();
                    ApplyPresentation();
                    output.Source = clearSpecular.Brush;
                }
                catch (Exception error) when (OptionalComposition.IsRenderingFailure(error))
                {
                    clearSpecularUnavailable = true;
                    StartupDiagnostics.Write("Clear specular unavailable; using existing edge", error);
                    try { clearSpecular?.Dispose(); }
                    catch (Exception disposeError) when (OptionalComposition.IsRenderingFailure(disposeError))
                    {
                        StartupDiagnostics.Write("Clear specular cleanup failed", disposeError);
                    }
                    clearSpecular = null;
                    output.Source = UseDockSpecular && dockStyle == GlassMaterialMode.Clear ? specularBody : edgeEffect ?? specularBody;
                }
            }
            else
            {
                clearSpecular?.SetVisible(false);
                output.Source = UseDockSpecular && dockStyle == GlassMaterialMode.Clear ? specularBody : edgeEffect ?? specularBody;
            }
        }
        UpdateMaskPath();
        UpdateUtilityMasks();
    }

    private void UpdateClearBounds()
    {
        if (!hasBounds || clearSpecular is null) return;
        clearSpecular.SetBounds(lastWindowWidth, lastWindowHeight,
            lastWindowHeight - lastBottom - lastHeight, lastHeight, lastScale, lastWidth, SpecularHighlightAngle);
    }

    public void SetSolidAppearance(
        DockAppearanceMode appearance,
        double opacity,
        double cornerRadius)
    {
        dockStyle = null;
        solidAppearance = Enum.IsDefined(appearance)
            ? appearance
            : DockAppearanceMode.Dark;
        solidOpacity = double.IsFinite(opacity) ? Math.Clamp(opacity, 0, 1) : 1;
        solidCornerRadius = double.IsFinite(cornerRadius) ? Math.Clamp(cornerRadius, 0, 100) : 28;
        material = material with
        {
            CornerRadius = solidCornerRadius,
            BorderOpacity = 0,
            BorderThickness = 0,
            EdgeHighlight = 0
        };

        if (solidSurface is not null)
            solidSurface.Color = SolidColor(solidAppearance, solidOpacity);

        Apply(material);
    }

    private static global::Windows.UI.Color SolidColor(DockAppearanceMode appearance, double opacity)
    {
        var alpha = (byte)Math.Round(Math.Clamp(opacity, 0, 1) * 255);
        return Desktop.DockControlPalette.SolidSurface(appearance, alpha);
    }

    public void SetBounds(
        double windowWidth,
        double windowHeight,
        double width,
        double height,
        double bottom,
        double scale,
        double opacity = 1)
    {
        if (hasBounds && !boundsDirty &&
            Math.Abs(lastWindowWidth - windowWidth) < 0.001 &&
            Math.Abs(lastWindowHeight - windowHeight) < 0.001 &&
            Math.Abs(lastWidth - width) < 0.001 &&
            Math.Abs(lastHeight - height) < 0.001 &&
            Math.Abs(lastBottom - bottom) < 0.001 &&
            Math.Abs(lastScale - scale) < 0.0001 &&
            Math.Abs(lastOpacity - opacity) < 0.0001)
        {
            GlassDock.Core.Desktop.DockPerformanceDiagnostics.RecordBackdropUpdate(updated: false);
            return;
        }

        var startTicks = GlassDock.Core.Desktop.DockPerformanceDiagnostics.Enabled
            ? System.Diagnostics.Stopwatch.GetTimestamp()
            : 0;

        hasBounds = true;
        boundsDirty = false;
        lastWindowWidth = windowWidth;
        lastWindowHeight = windowHeight;
        lastWidth = width;
        lastHeight = height;
        lastBottom = bottom;
        lastScale = scale;
        lastOpacity = opacity;

        ApplyBounds(
            windowWidth,
            windowHeight,
            width,
            height,
            bottom,
            scale,
            opacity);
        PopupSurfaceChanged?.Invoke(this, EventArgs.Empty);

        if (startTicks != 0)
            GlassDock.Core.Desktop.DockPerformanceDiagnostics.RecordBackdropUpdate(
                updated: true,
                System.Diagnostics.Stopwatch.GetTimestamp() - startTicks);
    }

    private void ApplyBounds(
        double windowWidth,
        double windowHeight,
        double width,
        double height,
        double bottom,
        double scale,
        double opacity)
    {
        if (geometry is null ||
            visual is null ||
            maskSurface is null)
        {
            return;
        }

        ApplyPresentation();

        var size =
            new Vector2(
                (float)(windowWidth * scale),
                (float)(windowHeight * scale));

        var sampling = UseInnerEdge || UseSolidSurface ? 2f : 1f;
        shape!.Scale = new Vector2(sampling);
        visual.Size = size * sampling;
        maskCaptureRoot!.Size = size * sampling;
        maskSurface.SourceSize = size * sampling;
        if (edgeVisual is not null)
        {
            edgeShape!.Scale = new Vector2(sampling);
            edgeShape.StrokeThickness = (float)(material.BorderThickness * 6 * scale);

            var glintScale = new Vector2(sampling);
            var glintThickness = (float)(material.BorderThickness * 4.2 * scale);
            if (specularLeftTopShape is not null)
            {
                specularLeftTopShape.Scale = glintScale;
                specularLeftTopShape.StrokeThickness = glintThickness;
            }
            if (specularRightTopShape is not null)
            {
                specularRightTopShape.Scale = glintScale;
                specularRightTopShape.StrokeThickness = glintThickness;
            }
            if (specularLeftBottomShape is not null)
            {
                specularLeftBottomShape.Scale = glintScale;
                specularLeftBottomShape.StrokeThickness = glintThickness;
            }

            edgeVisual.Size = size * sampling;
            edgeCaptureRoot!.Size = size * sampling;
            edgeSurface!.SourceSize = size * sampling;
        }

        UpdateClearBounds();
        UpdateMaskPath();
        UpdateUtilityMasks();
    }

    public void SetDockWave(
        double centerX,
        double halfWidth,
        double rise,
        double strength)
    {
        if (!double.IsFinite(centerX) ||
            !double.IsFinite(halfWidth) ||
            !double.IsFinite(rise) ||
            !double.IsFinite(strength))
        {
            return;
        }

        var clampedHalfWidth = Math.Max(24, halfWidth);
        var clampedRise = Math.Max(0, rise);
        var clampedStrength = Math.Clamp(strength, 0, 1);

        if (waveEnabled &&
            Math.Abs(waveCenterX - centerX) < 0.001 &&
            Math.Abs(waveHalfWidth - clampedHalfWidth) < 0.001 &&
            Math.Abs(waveRise - clampedRise) < 0.001 &&
            Math.Abs(waveStrength - clampedStrength) < 0.0001)
        {
            return;
        }

        waveEnabled = true;
        waveCenterX = centerX;
        waveHalfWidth = clampedHalfWidth;
        waveRise = clampedRise;
        waveStrength = clampedStrength;

        UpdateMaskPath();
    }

    public void ClearDockWave()
    {
        if (!waveEnabled && waveStrength <= 0)
            return;

        waveEnabled = false;
        waveStrength = 0;
        UpdateMaskPath();
    }

    private CanvasGeometry CreateOpenPath(params (Vector2 Point, Vector2? Control1, Vector2? Control2)[] nodes)
    {
        using var builder = new CanvasPathBuilder(canvasDevice!);

        if (nodes.Length == 0)
            return CanvasGeometry.CreatePath(builder);

        builder.BeginFigure(nodes[0].Point);
        for (var i = 1; i < nodes.Length; i++)
        {
            var node = nodes[i];
            if (node.Control1 is { } c1 && node.Control2 is { } c2)
                builder.AddCubicBezier(c1, c2, node.Point);
            else
                builder.AddLine(node.Point);
        }
        builder.EndFigure(CanvasFigureLoop.Open);
        return CanvasGeometry.CreatePath(builder);
    }

    private CanvasGeometry CreateUpperRim(GlassDock.Core.Desktop.DockWaveGeometry.Outline outline, double left, double right)
    {
        var part = GlassDock.Core.Desktop.DockEdgeSlice.Upper(outline, left, right);
        Vector2 Px(GlassDock.Core.Desktop.DockWaveGeometry.Point p) => new((float)(p.X * lastScale), (float)(p.Y * lastScale));
        using var builder = new CanvasPathBuilder(canvasDevice!);
        builder.BeginFigure(Px(part.Start));
        foreach (var segment in part.Segments)
            builder.AddCubicBezier(Px(segment.Control1), Px(segment.Control2), Px(segment.End));
        builder.EndFigure(CanvasFigureLoop.Open);
        return CanvasGeometry.CreatePath(builder);
    }

    private void UpdateSpecularPaths(GlassDock.Core.Desktop.DockWaveGeometry.Outline outline)
    {
        if (canvasDevice is null ||
            specularLeftTopGeometry is null ||
            specularRightTopGeometry is null ||
            specularLeftBottomGeometry is null ||
            !hasBounds)
        {
            return;
        }

        var left = SurfaceLeft;
        var top = lastWindowHeight - lastBottom - lastHeight;
        var right = left + lastWidth;
        var bottom = top + lastHeight;
        var radius = Math.Max(2,
            Math.Min(material.CornerRadius, Math.Min(lastWidth / 2, lastHeight / 2)));

        var topLeftStart = left + radius * .78;
        var topLeftEnd = Math.Min(
            right - radius - 18,
            left + Math.Max(radius + 28, lastWidth * .27));

        var topRightStart = Math.Max(
            left + radius + 18,
            right - Math.Max(radius + 56, lastWidth * .23));

        var bottomLeftEnd = Math.Min(
            right - radius - 20,
            left + Math.Max(radius + 22, lastWidth * .16));

        Vector2 Px(double x, double y) =>
            new((float)(x * lastScale), (float)(y * lastScale));

        var leftTop = CreateUpperRim(outline, topLeftStart, topLeftEnd);
        var r = radius;
        var rightTop = CreateUpperRim(outline, topRightStart, right);

        var leftBottom = CreateOpenPath(
            (Px(left + r, bottom), null, null),
            (Px(bottomLeftEnd, bottom), null, null));

        specularLeftTopGeometry.Path = new W.CompositionPath(leftTop);
        specularRightTopGeometry.Path = new W.CompositionPath(rightTop);
        specularLeftBottomGeometry.Path = new W.CompositionPath(leftBottom);

        var previousLeftTop = specularLeftTopCanvas;
        var previousRightTop = specularRightTopCanvas;
        var previousLeftBottom = specularLeftBottomCanvas;

        specularLeftTopCanvas = leftTop;
        specularRightTopCanvas = rightTop;
        specularLeftBottomCanvas = leftBottom;

        previousLeftTop?.Dispose();
        previousRightTop?.Dispose();
        previousLeftBottom?.Dispose();
    }

    private void UpdateMaskPath()
    {
        if (geometry is null ||
            canvasDevice is null ||
            visual is null ||
            maskSurface is null ||
            !hasBounds)
        {
            return;
        }

        var state = new MaskState(lastWindowWidth, lastWindowHeight, lastWidth, lastHeight,
            lastBottom, lastScale, material.CornerRadius, waveEnabled, waveCenterX,
            waveHalfWidth, waveRise, waveStrength);
        if (renderedMask == state) return;

        if (surfaceRegions is not null)
        {
            UpdateRegionPaths();
            renderedMask = state;
            return;
        }

        var outline = GlassDock.Core.Desktop.DockWaveGeometry.Create(
            SurfaceLeft,
            lastWindowHeight - lastBottom - lastHeight, lastWidth, lastHeight,
            material.CornerRadius, waveCenterX, waveHalfWidth, waveRise,
            waveEnabled ? waveStrength : 0);
        Vector2 Pixel(GlassDock.Core.Desktop.DockWaveGeometry.Point point) =>
            new((float)(point.X * lastScale), (float)(point.Y * lastScale));
        using var builder = new CanvasPathBuilder(canvasDevice);
        builder.BeginFigure(Pixel(outline.Start));
        foreach (var segment in outline.Segments)
        {
            if (segment.IsLine) builder.AddLine(Pixel(segment.End));
            else builder.AddCubicBezier(Pixel(segment.Control1), Pixel(segment.Control2), Pixel(segment.End));
        }
        builder.EndFigure(CanvasFigureLoop.Closed);
        var nextGeometry =
            CanvasGeometry.CreatePath(
                builder);

        geometry.Path = new W.CompositionPath(nextGeometry);
        UpdateSpecularPaths(outline);
        renderedMask = state;

        var previousGeometry =
            canvasGeometry;

        canvasGeometry =
            nextGeometry;

        previousGeometry?.Dispose();
    }

    private void UpdateRegionPaths()
    {
        using var body = new CanvasPathBuilder(canvasDevice!);
        using var upper = new CanvasPathBuilder(canvasDevice!);
        Vector2 Pixel(GlassDock.Core.Desktop.DockWaveGeometry.Point p) =>
            new((float)(p.X * lastScale), (float)(p.Y * lastScale));
        foreach (var rect in surfaceRegions!)
        {
            var outline = GlassDock.Core.Desktop.DockWaveGeometry.Create(rect.X, rect.Y,
                rect.Width, rect.Height, material.CornerRadius * surfaceRegionScale, 0, 24, 0, 0);
            body.BeginFigure(Pixel(outline.Start));
            foreach (var s in outline.Segments)
                if (s.IsLine) body.AddLine(Pixel(s.End));
                else body.AddCubicBezier(Pixel(s.Control1), Pixel(s.Control2), Pixel(s.End));
            body.EndFigure(CanvasFigureLoop.Closed);
            var slice = GlassDock.Core.Desktop.DockEdgeSlice.Upper(outline,
                rect.X + Math.Min(28, rect.Width / 4), rect.X + rect.Width * .72);
            upper.BeginFigure(Pixel(slice.Start));
            foreach (var s in slice.Segments)
                upper.AddCubicBezier(Pixel(s.Control1), Pixel(s.Control2), Pixel(s.End));
            upper.EndFigure(CanvasFigureLoop.Open);
        }
        var next = CanvasGeometry.CreatePath(body);
        geometry!.Path = new W.CompositionPath(next);
        var previous = canvasGeometry; canvasGeometry = next; previous?.Dispose();
        if (specularLeftTopGeometry is not null)
        {
            var top = CanvasGeometry.CreatePath(upper);
            specularLeftTopGeometry.Path = new W.CompositionPath(top);
            var old = specularLeftTopCanvas; specularLeftTopCanvas = top; old?.Dispose();
        }
    }

    protected override void OnTargetDisconnected(ICompositionSupportsSystemBackdrop target)
    {
        connectedTarget = null;
        connectedRoot = null;
        connectionVersion++;
        if (loadingRoot is not null && loadedHandler is not null)
            loadingRoot.Loaded -= loadedHandler;
        loadingRoot = null;
        loadedHandler = null;
        ReleaseDesktop(target);
        base.OnTargetDisconnected(target);
    }

    private void ReleaseDesktop(ICompositionSupportsSystemBackdrop target)
    {
        StopPresentationAnimation();
        bodyTrack?.Dispose(); bodyTrack = null;
        rimTrack?.Dispose(); rimTrack = null;
        target.SystemBackdrop = null;
        clearSpecular?.Dispose(); clearSpecular = null;
        edgeEffect?.Dispose(); edgeFactory?.Dispose(); edgeMask?.Dispose();
        edgeSurface?.Dispose(); edgeVisual?.Dispose(); edgeShape?.Dispose(); edgeFill?.Dispose();

        specularLeftTopShape?.Dispose();
        specularRightTopShape?.Dispose();
        specularLeftBottomShape?.Dispose();
        specularLeftTopGeometry?.Dispose();
        specularRightTopGeometry?.Dispose();
        specularLeftBottomGeometry?.Dispose();
        specularFill?.Dispose();
        specularLeftTopCanvas?.Dispose();
        specularRightTopCanvas?.Dispose();
        specularLeftBottomCanvas?.Dispose();

        edgeCaptureRoot?.Dispose();
        edgeCaptureRoot = null;
        edgeEffect = null; edgeFactory = null; edgeMask = null; edgeSurface = null;
        edgeVisual = null; edgeShape = null; edgeFill = null;

        specularLeftTopShape = null;
        specularRightTopShape = null;
        specularLeftBottomShape = null;
        specularLeftTopGeometry = null;
        specularRightTopGeometry = null;
        specularLeftBottomGeometry = null;
        specularFill = null;
        specularLeftTopCanvas = null;
        specularRightTopCanvas = null;
        specularLeftBottomCanvas = null;
        output?.Dispose();
        mask?.Dispose();
        maskSurface?.Dispose();
        foreach (var utility in utilityMasks) utility.Dispose();
        utilityMasks.Clear();
        utilityMaskRoot?.Dispose(); utilityMaskRoot = null;
        visual?.Dispose();
        maskCaptureRoot?.Dispose();
        maskCaptureRoot = null;
        shape?.Dispose();
        fill?.Dispose();
        geometry?.Dispose();
        canvasGeometry?.Dispose();
        fallback?.Dispose();
        effect?.Dispose();
        factory?.Dispose();
        source?.Dispose();
        solidSurface?.Dispose();
        compositor?.Dispose();
        output = null;
        mask = null;
        maskSurface = null;
        visual = null;
        shape = null;
        fill = null;
        geometry = null;
        renderedMask = null;
        canvasGeometry = null;
        canvasDevice = null;
        fallback = null;
        effect = null;
        factory = null;
        source = null;
        solidSurface = null;
        compositor = null;
    }
}

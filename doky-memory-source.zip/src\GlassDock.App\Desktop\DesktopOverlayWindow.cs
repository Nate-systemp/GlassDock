using System.Numerics;
using System.Collections.ObjectModel;
using System.Runtime.InteropServices;
using GlassDock.App.ViewModels;
using GlassDock.Core.Applications;
using GlassDock.Windows.Applications;
using GlassDock.App.Controls;
using GlassDock.App.Rendering;
using GlassDock.Core.Desktop;
using GlassDock.Core.Materials;
using GlassDock.Core.Settings;
using GlassDock.Windows.Desktop;
using GlassDock.Windows.Settings;
using Microsoft.UI;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Automation;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Hosting;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using XamlPath = Microsoft.UI.Xaml.Shapes.Path;
using global::Windows.UI.ViewManagement;
using global::Windows.ApplicationModel.DataTransfer;

namespace GlassDock.App.Desktop;

public sealed partial class DesktopOverlayWindow : Window
{
    private readonly DockRelocationGuard relocationGuard = new();
    private DateTime lastRelocationFailure;
    private DockDisplayMode appliedDisplayMode;
    private readonly Grid root = new() { Background = new SolidColorBrush(global::Windows.UI.Color.FromArgb(1, 0, 0, 0)) };
    private readonly GlassSurface surface = new()
    {
        UseDesktopBackdrop = true, UsePlainSurface = true, Width = 120, Height = 5, Opacity = 0,
        HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Bottom,
        Margin = new Thickness(0, 0, 0, 16)
    };
    private readonly Border indicator = new()
    {
        Width = 120, Height = 5, CornerRadius = new CornerRadius(2.5),
        Background = new SolidColorBrush(global::Windows.UI.Color.FromArgb(220, 225, 225, 230)),
        HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Bottom,
        Margin = new Thickness(0, 0, 0, 16), IsHitTestVisible = false
    };
    private readonly StackPanel icons = new()
    {
        Orientation = Orientation.Horizontal, Spacing = 6, Height = 68, Opacity = 0,
        HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Bottom,
        Margin = new Thickness(0, 0, 0, 16), IsHitTestVisible = false
    };

    private readonly Canvas hoverArtworkForeground = new()
    {
        HorizontalAlignment = HorizontalAlignment.Stretch,
        VerticalAlignment = VerticalAlignment.Stretch,
        IsHitTestVisible = false
    };

    private readonly Border externalDropHighlight = new()
    {
        HorizontalAlignment = HorizontalAlignment.Center,
        VerticalAlignment = VerticalAlignment.Bottom,
        CornerRadius = new CornerRadius(22),
        BorderThickness = new Thickness(1.5),
        BorderBrush = new SolidColorBrush(
            global::Windows.UI.Color.FromArgb(190, 225, 245, 255)),
        Background = new SolidColorBrush(
            global::Windows.UI.Color.FromArgb(34, 150, 210, 255)),
        Opacity = 0,
        IsHitTestVisible = false
    };

    private readonly XamlPath dockWaveGlow = new()
    {
        IsHitTestVisible = false,
        StrokeThickness = 0,
        Stroke = new SolidColorBrush(Colors.Transparent),
        Opacity = 0
    };

    private readonly XamlPath dockWaveRim = new()
    {
        IsHitTestVisible = false,
        StrokeThickness = 0,
        Stroke = new SolidColorBrush(Colors.Transparent),
        Opacity = 0
    };
    private readonly DockStateMachine state = new();
    private readonly WindowsApplicationService applicationService;
    private readonly BadgeCoordinator badges;
    private readonly bool ownsApplicationService;
    private readonly bool ownsBadges;
    private readonly bool ownsKeyboard;
    private readonly bool ownsGlobalServices;
    private readonly Action? requestApplicationShutdown;
    private readonly Action<DesktopOverlayWindow>? unexpectedClosed;
    private readonly Action? showSettingsOverride;
    private readonly Action? restoreTaskbarOverride;
    private readonly Action? resumeTaskbarOverride;
    private int notificationRefreshQueued;
    private readonly WindowsApplicationLauncher dropLauncher = new();
    private readonly DockApplicationsViewModel applications;
    private readonly WindowPreviewCoordinator previews;
    private readonly Dictionary<string, Button> applicationButtons = new(StringComparer.Ordinal);
    private int keyboardDockIndex = -1;
    private bool keyboardDockNavigation;
    private nint keyboardPreviousForegroundWindow;

    [DllImport("user32.dll", EntryPoint = "GetForegroundWindow")]
    private static extern nint GetForegroundWindowForDockKeyboard();

    [DllImport("user32.dll", EntryPoint = "SetForegroundWindow")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetForegroundWindowForDockKeyboard(nint hwnd);

    public ObservableCollection<DockApplicationItem> VisibleDockApplications => applications.VisibleDockApplications;
    private readonly DesktopGlassBackdrop desktopBackdrop = new()
    {
        UseInnerEdge = false,
        UseDockSpecular = true,
        UseSolidSurface = true
    };
    private readonly WindowsOverlayManager windowManager;
    private readonly DokyLiquidGlassSurface liquidGlass;
    private readonly WindowsKeyboardService keyboard;
    private readonly DockAnimationController animation;
    private readonly GlassDockSettingsSession settingsSession;
    private readonly GlassDockSettingsStore settingsStore;
    private readonly ApplicationShutdownState shutdown;
    private readonly Action shutdownCompleted;
    private readonly bool safeMode;
    private readonly Action<bool>? prepareRestart;
    private bool taskbarSuppressionPaused;
    private readonly RetainedWindowSlot<SettingsWindow> settingsWindow = new();
    private readonly Microsoft.UI.Dispatching.DispatcherQueueTimer heartbeat;
    private readonly Microsoft.UI.Dispatching.DispatcherQueueTimer displayTimer;
    private long dockWaveLastFrame;
    private CancellationTokenSource? collapseDelay;
    private CancellationTokenSource? pinDockTransition;

    private CancellationTokenSource? pillHideDelay;
    private TaskbarDevelopmentSession? taskbarSession;
    private DevelopmentWindow? controls;
    private GlassHomeWindow? home;
    private Window? lab;
    private bool pointerInsideDock;
    private bool heldTransition;
    private bool closing;
    private bool startingTest;
    private bool desktopStartupQueued;
    private bool desktopStarted;
    private bool pinDockRequested;
    private bool notificationBadgesRequested;
    private bool pinnedPlacementActive;
    private bool pinDockTransitionActive;
    private Task? taskbarOperation;
    private Task? taskbarRestoreOperation;
    private Task? shutdownOperation;
    private int taskbarRevision;

    private bool dockWaveTimerRunning;
    private double dockWaveTargetX;
    private double dockWaveCurrentX;
    private double dockWaveTargetStrength;
    private double dockWaveCurrentStrength;

    private DockApplicationItem? reorderCandidate;
    private Button? reorderButton;
    private double reorderStartX;
    private Vector2 reorderGrabOffset;
    private Vector2 reorderSourceCenterRoot;
    private bool reorderDragging;
    private bool reorderCommitting;
    private int reorderSourceIndex = -1;
    private int reorderTargetIndex = -1;
    private List<Button> reorderPinnedButtons = [];
    private double[] reorderSlotCenters = [];
    private readonly Dictionary<string, DateTime> suppressClickUntil = new(StringComparer.Ordinal);

    private bool externalDragActive;
    private Button? externalDropTargetButton;

    private bool StackPopupOpen => stackWindow?.IsOpen == true;

    private double DockWaveHalfWidth => 92 * DockScale;
    private double DockWaveRise => 12 * DockScale;
    private double ExpandedDockCornerRadius => Sizing.Radius;
    private double PinnedDockClipDepth => Sizing.ClipDepth;
    private const int PinnedDockTransitionDurationMilliseconds = 280;
    private const double PillHideDurationMilliseconds = 210;

    public double BottomMargin { get; private set; }
    private double DockScale => settingsSession.Current.DockSize;
    private DockSizing appliedSizing;
    private DockSizing Sizing => new(DockScale, settingsSession.Current.IconSize, settingsSession.Current.PinnedPlacement, settingsSession.Current.FloatingDockGap);
    private double AvailableDockWidth => Math.Max(120d, (root.ActualWidth > 0 ? root.ActualWidth : windowManager.CurrentHostWidthDips) - (GridUtilities ? 128d : 32d));
    private DockAppearanceSettings Appearance => settingsSession.Appearance.ForDock(DockScale)
        .FitAppRow(VisibleDockApplications.Count, AvailableDockWidth, 36d * DockScale);
    private bool HoverWaveEnabled => !safeMode && settingsSession.Current.HoverWaveEnabled;
    private double ExpandedDockHeight => Sizing.Height;
    private double ExpandedContentTop => root.ActualHeight - icons.Margin.Bottom - ExpandedDockHeight;
    private bool DockPinLock => pinDockRequested || pinnedPlacementActive || pinDockTransitionActive;
    private const double PeekRestBottom = -2;
    public string Status { get; private set; } = "Starting desktop recovery protection.";
    public string RenderingMode => settingsSession.Current.DockAppearanceMode == DockAppearanceMode.Clear
        ? liquidGlass.Status : desktopBackdrop.RenderingMode;
    public bool HotkeysAvailable => keyboard.IsRegistered;
    public bool IsShuttingDown => shutdown.IsRequested;
    public event EventHandler? StatusChanged;

    internal nint MonitorTarget => windowManager.FixedMonitor;
    internal WindowsKeyboardService KeyboardService => keyboard;
    private bool snippingPending;
    internal Action? ScreenshotRequested { get; init; }
    internal bool BeginSnippingCapture()
    {
        if (closing || snippingPending) return false;
        snippingPending = true;
        collapseDelay?.Cancel();
        CancelPillHide();
        if (!heldTransition && state.State is DockState.Expanding or DockState.Collapsing)
        {
            heldTransition = state.HoldTransition();
            animation.FreezeCurrentTransitions();
        }
        previews.BeginSnippingCapture();
        var frozen = liquidGlass.BeginScreenshotMode();
        if (frozen || (Application.Current as App)?.BasicRendering == true)
        { wifiWindow?.BeginSnippingCapture(); bluetoothWindow?.BeginSnippingCapture(); quickSettingsWindow?.BeginSnippingCapture(); }
        return frozen;
    }
    internal void EndSnippingCapture()
    {
        wifiWindow?.EndSnippingCapture();
        bluetoothWindow?.EndSnippingCapture();
        quickSettingsWindow?.EndSnippingCapture();
        liquidGlass.EndScreenshotMode();
        previews.EndSnippingCapture();
        snippingPending = false;
        if (closing) return;
        windowManager.RefreshFullscreenPolicy();
        UpdateBackdropBounds();
        if (heldTransition) { ResumeAfterHold(); return; }
        if (!windowManager.IsPointerInsideInput())
        {
            if (state.State is DockState.Expanded or DockState.Expanding) ScheduleCollapse();
            else if (state.State is DockState.Idle or DockState.Hovering) SchedulePillHide();
        }
    }
    internal bool OwnsGlobalServices => ownsGlobalServices;

    internal void RetargetMonitor(nint monitor)
    {
        if (closing) return;
        CancelReorder();
        AbortDragLens();
        var oldMonitor = windowManager.CurrentMonitor;
        windowManager.SetFixedMonitor(monitor);
        if (monitor == 0)
        {
            windowManager.InvalidateMonitorMetrics();
            applications.RefreshFilter();
            return;
        }
        if (oldMonitor != 0 && oldMonitor != monitor)
            liquidGlass.DeactivateCapture();
        windowManager.Position(0, settingsSession.DisplayMode);
        applications.RefreshFilter();
        UpdateBackdropBounds();
        if (state.State is DockState.Idle or DockState.Hovering)
            UpdatePeekInput();
        else
            UpdateDockWaveOutline();
        pointerInsideDock = windowManager.IsPointerInsideInput();
        previews.Reposition();
        RepositionStackPopup();
    }

    public DesktopOverlayWindow(
        GlassDockSettingsSession settingsSession,
        GlassDockSettingsStore settingsStore,
        ApplicationShutdownState shutdown,
        Action shutdownCompleted,
        bool inspection = false,
        bool safeMode = false,
        Action<bool>? prepareRestart = null,
        WindowsApplicationService? sharedApplicationService = null,
        BadgeCoordinator? sharedBadges = null,
        nint monitorTarget = 0,
        bool ownsGlobalServices = true,
        WindowsKeyboardService? sharedKeyboard = null,
        Action? requestApplicationShutdown = null,
        Action<DesktopOverlayWindow>? unexpectedClosed = null,
        Action? showSettingsOverride = null,
        Action? restoreTaskbarOverride = null,
        Action? resumeTaskbarOverride = null,
        WifiUtilityService? sharedWifi = null, BluetoothUtilityService? sharedBluetooth = null,
        AirplaneModeUtilityService? sharedAirplaneMode = null, NightLightUtilityService? sharedNightLight = null,
        EnergySaverUtilityService? sharedEnergySaver = null, DndUtilityService? sharedDnd = null,
        MasterVolumeService? sharedVolume = null)
    {
        this.settingsSession = settingsSession;
        this.settingsStore = settingsStore;
        this.shutdown = shutdown;
        this.shutdownCompleted = shutdownCompleted;
        this.safeMode = safeMode;
        this.prepareRestart = prepareRestart;
        this.ownsGlobalServices = ownsGlobalServices;
        this.requestApplicationShutdown = requestApplicationShutdown;
        this.unexpectedClosed = unexpectedClosed;
        this.showSettingsOverride = showSettingsOverride;
        this.restoreTaskbarOverride = restoreTaskbarOverride;
        this.resumeTaskbarOverride = resumeTaskbarOverride;
        ownsApplicationService = sharedApplicationService is null;
        applicationService = sharedApplicationService ?? new WindowsApplicationService();
        ownsBadges = sharedBadges is null;
        badges = sharedBadges ?? new BadgeCoordinator(new[] { new WindowsToastBadgeProvider() });
        BottomMargin = settingsSession.DockBehavior.BottomMargin * DockScale;
        appliedDisplayMode = settingsSession.DisplayMode;
        pinDockRequested = settingsSession.Current.PinDock;
        notificationBadgesRequested = settingsSession.Current.NotificationBadgesEnabled;
        settingsSession.Changed += SettingsChanged;

        Title = "Doky — Floating Dock";
        WindowBranding.Apply(this);
        root.Loaded += (_, _) => QueueDesktopStartup();
        Content = root;
        surface.Margin = indicator.Margin = icons.Margin = new Thickness(0, 0, 0, BottomMargin);
        SystemBackdrop = desktopBackdrop;
        AppWindow.IsShownInSwitchers = inspection;
        var presenter = (OverlappedPresenter)AppWindow.Presenter;
        presenter.SetBorderAndTitleBar(false, false);
        presenter.IsResizable = false;
        presenter.IsMaximizable = false;
        presenter.IsMinimizable = false;
        presenter.IsAlwaysOnTop = true;
        var hwnd = WinRT.Interop.WindowNative.GetWindowHandle(this);
        windowManager = new WindowsOverlayManager(hwnd, monitorTarget);
        windowManager.Configure(inspection);
        root.Children.Add(surface);
        liquidGlass = new(hwnd, DispatcherQueue, () => desktopBackdrop.DockGeometry, desktopBackdrop.SetLiquidActive);
        liquidGlass.StatusChanged += (_, _) => StatusChanged?.Invoke(this, EventArgs.Empty);
        root.Children.Add(liquidGlass.Panel);
        root.Children.Add(indicator);
        root.Children.Add(icons);
        root.Children.Add(externalDropHighlight);
        root.Children.Add(hoverArtworkForeground);
        Canvas.SetZIndex(surface, 0);
        Canvas.SetZIndex(liquidGlass.Panel, 1);
        Canvas.SetZIndex(indicator, 2);
        Canvas.SetZIndex(icons, 20);
        Canvas.SetZIndex(externalDropHighlight, 30);
        Canvas.SetZIndex(hoverArtworkForeground, 1000);

        root.AddHandler(UIElement.PointerPressedEvent, new PointerEventHandler((_, _) =>
        {
            if (!reorderDragging) suppressDragContext = false;
            EndDockKeyboardNavigation(restorePreviousFocus: false);
            if (!StackSourceOwnsPointer()) stackWindow?.Hide();
        }), true);
        root.ContextRequested += (_, e) => { if (reorderDragging || suppressDragContext) e.Handled = true; };
        Activated += (_, args) =>
        {
            if (args.WindowActivationState != WindowActivationState.Deactivated) return;
            if (reorderDragging) CancelReorder();
            EndDockKeyboardNavigation(restorePreviousFocus: false);
        };
        root.AllowDrop = true;
        root.DragEnter += ExternalDragEnter;
        root.DragOver += ExternalDragOver;
        root.DragLeave += ExternalDragLeave;
        root.Drop += ExternalDrop;
        root.AddHandler(UIElement.KeyDownEvent, new Microsoft.UI.Xaml.Input.KeyEventHandler((_, e) =>
        {
            if (e.Key == global::Windows.System.VirtualKey.Escape && reorderDragging)
            { CancelReorder(); e.Handled = true; return; }
            if (!keyboardDockNavigation) return;
            if (e.Key == global::Windows.System.VirtualKey.Escape)
            {
                EndDockKeyboardNavigation(restorePreviousFocus: true);
                if (!DockPinLock && !windowManager.IsPointerInsideInput()) ScheduleCollapse();
                e.Handled = true;
                return;
            }
            if (e.Key is global::Windows.System.VirtualKey.Left or global::Windows.System.VirtualKey.Right)
            {
                FocusDockIcon(keyboardDockIndex +
                    (e.Key == global::Windows.System.VirtualKey.Right ? 1 : -1));
                e.Handled = true;
                return;
            }
            if (e.Key == global::Windows.System.VirtualKey.F10 &&
                Microsoft.UI.Input.InputKeyboardSource.GetKeyStateForCurrentThread(
                    global::Windows.System.VirtualKey.Shift).HasFlag(
                    global::Windows.UI.Core.CoreVirtualKeyStates.Down))
            {
                ShowKeyboardDockMenu();
                e.Handled = true;
            }
        }), true);

        surface.RegisterPropertyChangedCallback(UIElement.OpacityProperty, (_, _) => UpdateBackdropBounds());
        surface.SizeChanged += (_, _) =>
        {
            UpdateBackdropBounds();
            UpdateDockWaveOutline();
            UpdateExternalDropHighlight();
        };

        root.SizeChanged += (_, _) =>
        {
            if (animation is not null)
            {
                UpdateApplicationSizing();
                if (state.State == DockState.Expanded)
                    animation.ResizeExpanded(CalculateTargetDockWidth(), ExpandedDockHeight + (pinnedPlacementActive ? PinnedDockClipDepth : 0));
                else if (state.State == DockState.Expanding)
                    animation.RetargetExpandedSize(CalculateTargetDockWidth(), ExpandedDockHeight + (pinnedPlacementActive ? PinnedDockClipDepth : 0));
            }
            UpdateBackdropBounds();
            UpdateDockWaveOutline();
            UpdateExternalDropHighlight();
            RepositionStackPopup();
        };
        desktopBackdrop.RenderingModeChanged += (_, _) => { UpdateBackdropBounds(); StatusChanged?.Invoke(this, EventArgs.Empty); };
        applications = new DockApplicationsViewModel(
            applicationService,
            DispatcherQueue,
            ownsService: ownsApplicationService,
            snapshotTransform: snapshot => WindowsMonitorService.FilterSnapshotForMonitor(snapshot, windowManager.FixedMonitor));
        badges.Changed += BadgesChanged;
        if (ownsGlobalServices)
            badges.RefreshRequested += BadgesRefreshRequested;
        applications.SnapshotApplied += (_, _) => QueueNotificationBadgeRefresh();
        previews = new(applications, root, hwnd, () => ExpandedContentTop, settingsSession,
            () => !closing && state.State == DockState.Expanded && reorderButton is null &&
                !externalDragActive && !StackPopupOpen,
            window => keyboard?.RestoreElevatedWindowAsync(window) ?? Task.FromResult(false), dropLauncher.OpenWithAsync);
        previews.HoldChanged += (_, _) => OnInteractionHoldChanged();
        previews.ActionFailed += (_, message) => SetStatus(message);
        AppWindow.Changed += (_, _) =>
        {
            if (!presenter.IsAlwaysOnTop) presenter.IsAlwaysOnTop = true;
            previews.Reposition();
            RepositionStackPopup();
        };
        applications.VisibleDockApplications.CollectionChanged += (_, _) => SynchronizeItems();
        applications.WarningChanged += (_, _) => { if (applications.Warning is { } warning) SetStatus(warning); };
        animation = new DockAnimationController(surface, icons, indicator, hoverArtworkForeground);
        animation.HoverPresentationChanged += (_, _) => UpdateDockWaveOutline();
        InitializeUtilities(sharedWifi, sharedBluetooth, sharedAirplaneMode, sharedNightLight, sharedEnergySaver, sharedDnd, sharedVolume);

        ApplyAppearance(settingsSession.Appearance);
        animation.PlacementChanged += (_, _) =>
        {
            UpdateBackdropBounds();
            if (state.State is DockState.Idle or DockState.Hovering) UpdatePeekInput();
            else UpdateDockWaveOutline();
            if (!animation.IsPlacementAnimating && state.State == DockState.Hovering &&
                !previews.HoldsDock && !windowManager.IsPointerInsideInput())
                SchedulePillHide();
        };
        windowManager.PointerMovedOutsideInput += (_, _) => PointerDeparted();
        windowManager.ScreenshotRequested += (_, _) => ScreenshotRequested?.Invoke();
        windowManager.PointerMovedInsideInput += (_, _) =>
        {
            if (snippingPending) return;
            pointerInsideDock = true;
            collapseDelay?.Cancel();
            CancelPillHide();
            if (previews.ContextMenuOpen) return;
            if (state.State == DockState.Idle)
            {
                RaisePeek();
                if (settingsSession.Current.HoverToExpandOnly)
                    _ = ExpandDockAsync();
            }
            if (state.State == DockState.Expanded && reorderButton is null)
                RefreshHoverVisuals();
        };
        displayTimer = DispatcherQueue.CreateTimer();
        displayTimer.Interval = MonitorTrackingInterval(settingsSession.DisplayMode);
        var fullscreenWasHidden = false;
        displayTimer.Tick += (_, _) =>
        {
            if (closing) { relocationGuard.Stop(); return; }
            if (snippingPending) return;
            var diagStart = DockPerformanceDiagnostics.Enabled ? System.Diagnostics.Stopwatch.GetTimestamp() : 0;
            var relocationStage = "fullscreen policy";
            relocationGuard.Run(() =>
            {
            if (!closing && !snippingPending) windowManager.RefreshFullscreenPolicy();
            if (windowManager.FullscreenSuppressed)
            {
                if (!fullscreenWasHidden)
                {
                    previews.DismissForFullscreen();
                    stackWindow?.Hide();
                    liquidGlass.DeactivateCapture();
                }
                fullscreenWasHidden = true;
                return;
            }
            if (fullscreenWasHidden) { fullscreenWasHidden = false; UpdateBackdropBounds(); }
            if (closing || previews.HoldsDock)
                return;

            relocationStage = "native monitor placement";
            if (!windowManager.RepositionIfMonitorChanged(0, settingsSession.DisplayMode, () =>
                {
                    relocationStage = "dismiss dock-anchored popups";
                    stackWindow?.Hide();
                    relocationStage = "native monitor placement";
                }, () =>
                {
                    relocationStage = "invalidate old monitor capture";
                    liquidGlass.DeactivateCapture();
                    relocationStage = "native monitor placement";
                }))
                return;

            relocationStage = "backdrop and capture bounds";
            UpdateBackdropBounds();

            relocationStage = "input geometry";
            if (state.State is DockState.Idle or DockState.Hovering)
                UpdatePeekInput();
            else
                UpdateDockWaveOutline();

            pointerInsideDock = windowManager.IsPointerInsideInput();
            relocationStage = "preview placement";
            previews.Reposition();
            }, error => error is COMException or System.ComponentModel.Win32Exception or InvalidOperationException,
            error =>
            {
                windowManager.InvalidateMonitorMetrics();
                if (DateTime.UtcNow - lastRelocationFailure >= TimeSpan.FromSeconds(5))
                {
                    lastRelocationFailure = DateTime.UtcNow;
                    StartupDiagnostics.Write($"Dock monitor reconciliation failed; stage={relocationStage}; mode={settingsSession.DisplayMode}; monitor={windowManager.CurrentMonitor}; retry pending", error);
                }
            });
            if (diagStart != 0)
                DockPerformanceDiagnostics.RecordDisplayTimer(System.Diagnostics.Stopwatch.GetTimestamp() - diagStart);
            if (DockPerformanceDiagnostics.ReportDue())
                StartupDiagnostics.WritePerformance(DockPerformanceDiagnostics.FormatSummary());
        };



        if (sharedKeyboard is null)
        {
            ownsKeyboard = true;
            keyboard = new WindowsKeyboardService(
                hwnd,
                enableDockShortcuts: !safeMode,
                elevatedHelperPath: safeMode
                    ? null
                    : Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                        "Doky",
                        "InputHelper",
                        "GlassDock.InputHelper.exe"));

            keyboard.BareWindowsRequested += (_, _) => RequestDockToggle();
            keyboard.HomeRequested += (_, _) =>
            {
                if (home is { IsVisible: true })
                    home.HideHome();

                RequestDockToggle();
            };
            keyboard.LauncherRequested += (_, _) => ShowHome();
            keyboard.DockShortcutRequested += OnDockShortcut;
            keyboard.RecoveryRequested += (_, _) => RestoreTaskbar();
        }
        else
        {
            ownsKeyboard = false;
            keyboard = sharedKeyboard;
        }

        root.PointerEntered += Entered;
        root.PointerMoved += Moved;
        root.PointerExited += Exited;
        root.Tapped += async (_, e) =>
        {
            if (state.State is not (DockState.Idle or DockState.Hovering)) return;
            if (settingsSession.Current.HoverToExpandOnly) return;
            e.Handled = true;
            await ExpandDockAsync();
        };
        surface.RenderingModeChanged += (_, _) => StatusChanged?.Invoke(this, EventArgs.Empty);
        var menu = new MenuFlyout();
        MenuItem(menu, "Dock Settings", ShowSettings);
        MenuItem(menu, "Enable notification badges", async () => await EnableNotificationBadgesAsync());
        MenuItem(menu, "Open Glass Home", ShowHome);
        menu.Items.Add(new MenuFlyoutSeparator());
        MenuItem(menu, "Restore Windows taskbar", RestoreTaskbar);
        MenuItem(menu, "Glass Material Laboratory", ShowLab);
        menu.Items.Add(new MenuFlyoutSeparator());
        MenuItem(menu, "Exit Doky", RequestShutdown);
        menu.Opening += (_, _) =>
        {
            previews.BeginContextMenu(menu);
        };
        menu.Closed += (_, _) => previews.EndContextMenu(menu);
        root.ContextFlyout = menu;
        heartbeat = DispatcherQueue.CreateTimer();
        heartbeat.Interval = TimeSpan.FromSeconds(1);
        heartbeat.Tick += async (_, _) =>
        {
            if (closing) return;
            if (taskbarSession is { IsActive: true } session) await session.HeartbeatAsync();
        };
        Closed += OnClosed;
        windowManager.Position(0, settingsSession.DisplayMode);
        surface.Margin = indicator.Margin = new Thickness(0, 0, 0, PeekRestBottom);
        indicator.Opacity = 1;
        windowManager.SetPeekInteraction(PeekRestBottom);
        QueueDesktopStartup();
    }

    private async Task EnableNotificationBadgesAsync()
    {
        if (closing || shutdown.IsRequested) return;

        try
        {
            var edited = settingsSession.CreateNotificationBadgesUpdate(true);
            await settingsStore.SaveAsync(edited, shutdown.CancellationToken);
            if (closing || shutdown.IsRequested) return;

            await badges.StartAsync(requestPermission: true);
            settingsSession.Replace(edited);
            if (!closing) SetStatus(badges.Status);
        }
        catch (OperationCanceledException) when (shutdown.IsRequested)
        {
        }
        catch (Exception error)
        {
            if (!closing) SetStatus($"Notification badges could not be enabled: {error.Message}");
        }
    }

    private void QueueDesktopStartup()
    {
        if (desktopStartupQueued || desktopStarted || closing) return;
        desktopStartupQueued = true;
        if (!DispatcherQueue.TryEnqueue(async () => await StartDesktopAsync()))
            desktopStartupQueued = false;
    }

    private async Task StartDesktopAsync()
    {
        desktopStartupQueued = false;
        if (desktopStarted || closing) return;
        desktopStarted = true;
        ((OverlappedPresenter)AppWindow.Presenter).IsAlwaysOnTop = true;
        windowManager.Position(0, settingsSession.DisplayMode);
        displayTimer.Start();
        state.Show();
        animation.SetBottom(PeekRestBottom);
        indicator.Opacity = 1;
        ApplyMaterial(false);
        if (ownsApplicationService)
            applicationService.Start();
        if (ownsGlobalServices)
        {
            if (notificationBadgesRequested)
                _ = badges.StartAsync();
            else
                badges.Stop();
        }

        if (pinDockRequested)
            await ApplyPinDockModeAsync(pin: true, animate: true);

        if (ownsGlobalServices)
        {
            if (safeMode)
            {
                taskbarSuppressionPaused = true;
                TaskbarRecovery.RestoreNow();
                SetStatus("Safe Mode · Windows taskbar is restored · Win-key interception and Hover Wave are disabled.");
            }
            else if (settingsSession.Current.SuppressWindowsTaskbar)
            {
                await StartTaskbarTestAsync(whileAppActive: true);
            }
            else
            {
                taskbarSuppressionPaused = true;
                TaskbarRecovery.RestoreNow();
                SetStatus("Windows taskbar suppression is disabled.");
            }
        }
        else
        {
            SetStatus("Doky · per-monitor dock");
        }
    }

    private static void MenuItem(MenuFlyout menu, string text, Action action)
    {
        var item = new MenuFlyoutItem { Text = text };
        item.Click += (_, _) => action();
        menu.Items.Add(item);
    }

    private void SynchronizeItems()
    {
        if (previews.ContextMenuOpen || reorderDragging || reorderCommitting || externalDragActive || dragLensButton is not null) return;
        if (stackWindow?.IsOpen == true)
        {
            var openStack = VisibleDockApplications.FirstOrDefault(app => app.Id == stackWindow.StackId);
            if (openStack?.Application.Stack is not null) { stackWindow.Update(openStack.Application); RepositionStackPopup(); } else stackWindow.Hide();
        }
        var present = VisibleDockApplications.Select(item => item.Id).ToHashSet(StringComparer.Ordinal);
        foreach (var id in applicationButtons.Keys.Where(id => !present.Contains(id)).ToArray())
        {
            previews.Detach(id);
            icons.Children.Remove(applicationButtons[id]);
            applicationButtons.Remove(id);
        }
        for (var index = 0; index < VisibleDockApplications.Count; index++)
        {
            var item = VisibleDockApplications[index];
            if (!applicationButtons.TryGetValue(item.Id, out var button))
            {
                button = CreateApplicationButton(item);
                applicationButtons.Add(item.Id, button);
            }
            var previous = icons.Children.IndexOf(button);
            if (previous == index) continue;
            if (previous >= 0) icons.Children.RemoveAt(previous);
            icons.Children.Insert(index, button);
        }
        if (keyboardDockNavigation && keyboardDockIndex >= VisibleDockApplications.Count)
            keyboardDockIndex = VisibleDockApplications.Count - 1;
        UpdateApplicationSizing();
        if (state.State == DockState.Expanded)
        {
            var targetWidth = CalculateTargetDockWidth();
            animation.ResizeExpanded(targetWidth, ExpandedDockHeight + (pinnedPlacementActive ? PinnedDockClipDepth : 0));
            UpdateBackdropBounds();
        }
        else if (state.State == DockState.Expanding)
            animation.RetargetExpandedSize(CalculateTargetDockWidth(), ExpandedDockHeight + (pinnedPlacementActive ? PinnedDockClipDepth : 0));
    }
    private double CalculateTargetDockWidth()
    {
        var count = VisibleDockApplications.Count;

        var applicationWidth = count <= 0
            ? 100d
            : count * Appearance.ButtonWidth +
              Math.Max(0, count - 1) * Appearance.IconSpacing +
              36d * DockScale;

        var maximumWidth = AvailableDockWidth;

        return Math.Min(maximumWidth, applicationWidth);
    }

    private void UpdateApplicationSizing()
    {
        var appearance = Appearance;
        icons.Spacing = appearance.IconSpacing;
        foreach (var button in applicationButtons.Values)
            if (button.Content is Grid content && content.Children.FirstOrDefault() is AdaptiveAppIcon icon)
                ApplyIconLayout(button, content, icon, appearance);
    }

    private void BadgesChanged(object? sender, EventArgs e) => QueueNotificationBadgeRefresh();

    private void BadgesRefreshRequested(object? sender, EventArgs e)
    {
        if (Interlocked.Exchange(ref notificationRefreshQueued, 1) != 0) return;
        if (!DispatcherQueue.TryEnqueue(async () =>
        {
            Interlocked.Exchange(ref notificationRefreshQueued, 0);
            if (!closing) await badges.RefreshAsync();
        })) Interlocked.Exchange(ref notificationRefreshQueued, 0);
    }

    private void QueueNotificationBadgeRefresh()
    {
        if (closing) return;
        if (DispatcherQueue.HasThreadAccess)
            RefreshNotificationBadges();
        else
            DispatcherQueue.TryEnqueue(RefreshNotificationBadges);
    }

    private void RefreshNotificationBadges()
    {
        stackWindow?.RefreshBadges();
        if (closing) return;
        foreach (var item in applications.VisibleDockApplications)
        {
            if (applicationButtons.TryGetValue(item.Id, out var button) &&
                (ReferenceEquals(button, dragLensButton) ? dragLensContent : button.Content) is Grid content &&
                content.Children.FirstOrDefault() is AdaptiveAppIcon icon)
            {
                var badge = item.Application.Stack is null ? badges.ForApplication(item.Application.Identity) : StackBadge(item.Application);
                icon.SetNotificationBadge(badge);
                AutomationProperties.SetHelpText(button, badge.AccessibilityText);
            }
        }
        dragLensScene?.Rebase(root);
    }

    private Button CreateApplicationButton(DockApplicationItem item)
    {
    var image = new AdaptiveAppIcon(Appearance.IconSize, DockHoverMagnification<FrameworkElement>.HoverScale, showTile: false);
    image.Background = new SolidColorBrush(Colors.Transparent);
    image.SetDockAppearance(settingsSession.Current.DockAppearanceMode);

    var running = new Border
    {
        Width = 4,
        Height = 3,
        CornerRadius = new CornerRadius(1.5),
        Background = DockForegroundBrush(),
        HorizontalAlignment = HorizontalAlignment.Center,
        VerticalAlignment = VerticalAlignment.Bottom,
        Margin = new Thickness(0, 0, 0, 1)
    };

    var content = new Grid();

    content.Children.Add(image);
    content.Children.Add(running);

    var button = new Button
    {
        Padding = new Thickness(0),
        Margin = new Thickness(0),
        VerticalAlignment = VerticalAlignment.Center,
        HorizontalAlignment = HorizontalAlignment.Center,
        CornerRadius = new CornerRadius(10),
        Background = new SolidColorBrush(Colors.Transparent),
        BorderBrush = new SolidColorBrush(Colors.Transparent),
        BorderThickness = new Thickness(0),
        Content = content
    };
        ApplyIconLayout(button, content, image, Appearance);
        ApplyButtonVisual(item.Id, button);
        button.Resources["ButtonBackgroundPointerOver"] = new SolidColorBrush(Colors.Transparent);
        button.Resources["ButtonBackgroundPressed"] = new SolidColorBrush(Colors.Transparent);
        button.Resources["ButtonBorderBrushPointerOver"] = new SolidColorBrush(Colors.Transparent);
        button.Resources["ButtonBorderBrushPressed"] = new SolidColorBrush(Colors.Transparent);

        ApplicationIcon? renderedIcon = null;
        void Update()
        {
            var badge = item.Application.Stack is null ? badges.ForApplication(item.Application.Identity) : StackBadge(item.Application);
            image.SetNotificationBadge(badge);
            AutomationProperties.SetName(button, item.Name);
            AutomationProperties.SetHelpText(button, badge.AccessibilityText);
            AutomationProperties.SetItemStatus(button, item.IsActive ? "Active" : item.IsRunning ? "Running" : "Pinned");
            var pinUnavailable = item.Application.PinAvailability == PinTargetAvailability.Unavailable && !item.IsRunning;
            ToolTipService.SetToolTip(button, WindowPreviewCoordinator.CreateTooltip(pinUnavailable
                ? $"{item.Name} — target unavailable. Restore the target or right-click to unpin."
                : item.Name));
            running.Visibility = item.IsRunning ? Visibility.Visible : Visibility.Collapsed;
            running.Tag = item.IsActive;
            StyleRunningIndicator(running, settingsSession.Current.DockAppearanceMode);
            if (item.Application.Stack is not null) image.SetStack(item.Application.StackApps);
            if (ReferenceEquals(renderedIcon, item.Application.Icon)) return;
            renderedIcon = item.Application.Icon;
            if (item.Application.Stack is null) image.SetIcon(renderedIcon);
        }
        Update();
        item.PropertyChanged += (_, _) => Update();

        button.AllowDrop = true;
        button.DragEnter += (_, e) => ApplicationDragEnter(button, item, e);
        button.DragOver += (_, e) => ApplicationDragOver(button, item, e);
        button.DragLeave += (_, e) => ApplicationDragLeave(button, e);
        button.Drop += async (_, e) => await ApplicationDropAsync(button, item, e);

        button.AddHandler(
            UIElement.PointerPressedEvent,
            new PointerEventHandler((_, e) => BeginReorderCandidate(button, item, e)),
            true);

        button.AddHandler(
            UIElement.PointerMovedEvent,
            new PointerEventHandler((_, e) => UpdateReorder(button, item, e)),
            true);

        button.AddHandler(
            UIElement.PointerReleasedEvent,
            new PointerEventHandler((_, e) => FinishReorder(button, item, e)),
            true);

        button.AddHandler(
            UIElement.PointerCaptureLostEvent,
            new PointerEventHandler((_, e) =>
            {
                var properties = e.GetCurrentPoint(root).Properties;
                if (reorderDragging && properties.IsLeftButtonPressed &&
                    properties.PointerUpdateKind == Microsoft.UI.Input.PointerUpdateKind.RightButtonReleased &&
                    button.CapturePointer(e.Pointer)) return;
                DispatcherQueue.TryEnqueue(() =>
                {
                    if (ReferenceEquals(reorderButton, button))
                        CancelReorder();
                });
            }),
            true);

        button.AddHandler(UIElement.PointerCanceledEvent, new PointerEventHandler((_, _) =>
        { if (ReferenceEquals(reorderButton, button)) CancelReorder(); }), true);

        button.Click += async (_, _) => await ActivateDockItemAsync(button, item);

        if (item.Application.Stack is null) previews.Attach(button, item, () => reorderDragging || suppressDragContext);
        else button.ContextRequested += (_, e) => { e.Handled = true; if (!reorderDragging && !suppressDragContext) StackContext(button, item); };
        return button;
    }


    private async Task ActivateDockItemAsync(Button button, DockApplicationItem item)
    {

            if ((ReferenceEquals(reorderButton, button) && reorderDragging) ||
                (suppressClickUntil.Remove(item.Id, out var until) &&
                 DateTime.UtcNow <= until))
            {
                return;
            }

            if (item.Application.Stack is not null) { ToggleStack(item); return; }
            var windows = item.Application.Windows;
            var target = DockWindowClick.SelectWindow(windows,
                applicationService.CanInteractWithWindow, applicationService.IsForeground);
            if (target is not null)
            {
                var action = DockWindowClick.Resolve(windows.Count,
                    applicationService.IsForeground(target), applicationService.IsMinimized(target));
                var succeeded = action == DockWindowClickAction.Minimize
                    ? applicationService.MinimizeWindow(target)
                    : applicationService.ActivateWindow(target) || await keyboard.RestoreElevatedWindowAsync(target);
                if (!succeeded && !closing) SetStatus($"Windows could not {action.ToString().ToLowerInvariant()} {item.Name}.");
                return;
            }
            if (windows.Count > 0)
            {
                SetStatus($"Windows could not access a running {item.Name} window.");
                return;
            }
            if (!applications.Activate(item, WinRT.Interop.WindowNative.GetWindowHandle(this)))
                SetStatus($"Windows could not launch or focus {item.Name}.");
    }

    private async void OnDockShortcut(int index)
    {
        if (closing || shutdown.IsRequested || windowManager.FullscreenSuppressed ||
            reorderDragging || reorderCommitting || externalDragActive || previews.ContextMenuOpen)
            return;
        try
        {
            if (index == DockKeyboardShortcut.Navigate)
            {
                if (!keyboardDockNavigation)
                {
                    var foreground = GetForegroundWindowForDockKeyboard();
                    var dockHwnd = WinRT.Interop.WindowNative.GetWindowHandle(this);
                    keyboardPreviousForegroundWindow = foreground != dockHwnd ? foreground : 0;
                }
                keyboardDockNavigation = true;
                await ExpandDockAsync();
                if (!closing && keyboardDockNavigation)
                {
                    var dockHwnd = WinRT.Interop.WindowNative.GetWindowHandle(this);
                    if (GetForegroundWindowForDockKeyboard() != dockHwnd)
                        SetForegroundWindowForDockKeyboard(dockHwnd);
                    if (GetForegroundWindowForDockKeyboard() != dockHwnd)
                    {
                        EndDockKeyboardNavigation(restorePreviousFocus: false);
                        SetStatus("Win+T could not focus Doky. Try again after closing any fullscreen app.");
                        return;
                    }
                    FocusDockIcon(keyboardDockIndex < 0 ? 0 : keyboardDockIndex);
                }
                return;
            }
            var target = index - 1;
            if (target < 0 || target >= VisibleDockApplications.Count) return;
            var item = VisibleDockApplications[target];
            if (applicationButtons.TryGetValue(item.Id, out var button))
                await ActivateDockItemAsync(button, item);
        }
        catch (Exception error) when (error is not OutOfMemoryException)
        {
            System.Diagnostics.Debug.WriteLine($"Doky keyboard shortcut failed: {error}");
            if (!closing) SetStatus("Dock shortcut failed: " + error.Message);
        }
    }

    private void EndDockKeyboardNavigation(bool restorePreviousFocus)
    {
        if (!keyboardDockNavigation) return;
        keyboardDockNavigation = false;
        keyboardDockIndex = -1;
        var previousHwnd = keyboardPreviousForegroundWindow;
        keyboardPreviousForegroundWindow = 0;
        if (!restorePreviousFocus || previousHwnd == 0) return;
        var dockHwnd = WinRT.Interop.WindowNative.GetWindowHandle(this);
        if (previousHwnd != dockHwnd && GetForegroundWindowForDockKeyboard() == dockHwnd)
            SetForegroundWindowForDockKeyboard(previousHwnd);
    }

    private void FocusDockIcon(int index)
    {
        var count = VisibleDockApplications.Count;
        if (count == 0) { keyboardDockIndex = -1; return; }
        keyboardDockIndex = ((index % count) + count) % count;
        var selected = VisibleDockApplications[keyboardDockIndex];
        if (applicationButtons.TryGetValue(selected.Id, out var button))
            button.Focus(FocusState.Keyboard);
    }

    private void ShowKeyboardDockMenu()
    {
        if (previews.ContextMenuOpen || stackWindow?.IsOpen == true) return;
        if (keyboardDockIndex < 0 || keyboardDockIndex >= VisibleDockApplications.Count) return;
        var item = VisibleDockApplications[keyboardDockIndex];
        if (!applicationButtons.TryGetValue(item.Id, out var button)) return;
        if (item.Application.Stack is not null)
            StackContext(button, item);
        else
            previews.ShowAppActions(item, button.TransformToVisual(root)
                .TransformPoint(new global::Windows.Foundation.Point(button.ActualWidth / 2, 0)).X);
    }

    private SolidColorBrush DockForegroundBrush() => new(
        DockControlPalette.Foreground(settingsSession.Current.DockAppearanceMode));

    private void BeginReorderCandidate(
        Button button,
        DockApplicationItem item,
        PointerRoutedEventArgs e)
    {
        if (reorderDragging && ReferenceEquals(reorderButton, button))
        { UpdateReorder(button, item, e); e.Handled = true; return; }
        suppressDragContext = false;
        if (state.State != DockState.Expanded ||
            previews.ContextMenuOpen || externalDragActive ||
            reorderButton is not null)
        {
            return;
        }

        var point = e.GetCurrentPoint(icons);
        if (!point.Properties.IsLeftButtonPressed)
            return;

        AbortDragLens();
        dragLensHoverDeferred = false;
        var pressOnButton = e.GetCurrentPoint(button).Position;
        reorderGrabOffset = DragLensMotion.GrabOffset(
            new((float)button.ActualWidth, (float)button.ActualHeight),
            new((float)pressOnButton.X, (float)pressOnButton.Y));
        reorderCandidate = item;
        reorderButton = button;
        reorderStartX = point.Position.X;
        reorderDragging = false;
        reorderSourceIndex = -1;
        reorderTargetIndex = -1;
        reorderPinnedButtons.Clear();
        reorderSlotCenters = [];

        button.CapturePointer(e.Pointer);
    }

    private void UpdateReorder(
        Button button,
        DockApplicationItem item,
        PointerRoutedEventArgs e)
    {
        if (!ReferenceEquals(reorderButton, button) ||
            !ReferenceEquals(reorderCandidate, item))
        {
            return;
        }

        var point = e.GetCurrentPoint(icons);
        if (reorderDragging && point.Properties.PointerUpdateKind == Microsoft.UI.Input.PointerUpdateKind.LeftButtonReleased)
        { FinishReorder(button, item, e); return; }
        if (!point.Properties.IsLeftButtonPressed)
            return;

        if (reorderDragging && dragIntent.Observe(true, point.Properties.IsRightButtonPressed))
        {
            suppressDragContext = true;
            SetStatus(dragIntent.StackMode ? "Stack mode · release over an app to stack · right-click to reorder" : "Reorder mode · right-click to stack");
        }

        var pressDeltaX = point.Position.X - reorderStartX;

        if (!reorderDragging)
        {
            if (Math.Abs(pressDeltaX) < 6)
                return;

            var pinnedItems = VisibleDockApplications
                .ToArray();

            reorderSourceIndex = Array.FindIndex(
                pinnedItems,
                candidate => candidate.Id == item.Id);

            if (reorderSourceIndex < 0)
            {
                CancelReorder();
                return;
            }

            collapseDelay?.Cancel();
            CancelPillHide();
            previews.Hide();

            animation.ResetMagnification(immediate: true);

            dockWaveCurrentStrength = 0;
            dockWaveTargetStrength = 0;
            desktopBackdrop.ClearDockWave();
            UpdateDockWaveOutline();
            dockWaveGlow.Opacity = 0.22;
            dockWaveRim.Opacity = Appearance.BorderOpacity;
            StopDockWaveTimer(clear: false);

            icons.UpdateLayout();

            reorderPinnedButtons = pinnedItems
                .Select(candidate => applicationButtons.GetValueOrDefault(candidate.Id))
                .Where(candidate => candidate is not null)
                .Cast<Button>()
                .ToList();

            if (reorderPinnedButtons.Count != pinnedItems.Length)
            {
                CancelReorder();
                return;
            }

            reorderSlotCenters = reorderPinnedButtons
                .Select(candidate =>
                {
                    var origin = candidate
                        .TransformToVisual(icons)
                        .TransformPoint(new global::Windows.Foundation.Point(0, 0));

                    return origin.X + candidate.ActualWidth / 2;
                })
                .ToArray();

            reorderHitBounds = reorderPinnedButtons.Select(candidate =>
            {
                var bounds = candidate.TransformToVisual(icons).TransformBounds(
                    new global::Windows.Foundation.Rect(0, 0, candidate.ActualWidth, candidate.ActualHeight));
                return new DockDragBounds(bounds.Left, bounds.Top, bounds.Right, bounds.Bottom);
            }).ToArray();

            point = e.GetCurrentPoint(icons);
            var sourceCenter = button.TransformToVisual(root).TransformPoint(
                new(button.ActualWidth / 2, button.ActualHeight / 2));
            reorderSourceCenterRoot = new((float)sourceCenter.X, (float)sourceCenter.Y);
            reorderTargetIndex = reorderSourceIndex;
            dragIntent.Begin(point.Properties.IsRightButtonPressed);
            reorderDragging = true;

            suppressClickUntil[item.Id] = DateTime.UtcNow.AddMilliseconds(750);

            button.Opacity = 0.96;
            Canvas.SetZIndex(button, 100);
            var rootPointer = e.GetCurrentPoint(root).Position;
            BeginDragLens(button, DragLensMotion.PointerTarget(
                new((float)rootPointer.X, (float)rootPointer.Y), reorderGrabOffset));
        }

        if (reorderSlotCenters.Length == 0)
            return;

        var rootPoint = e.GetCurrentPoint(root).Position;
        var draggedCenter = DragLensMotion.PointerTarget(
            new((float)rootPoint.X, (float)rootPoint.Y), reorderGrabOffset);

        UpdateStackCandidate(point.Position.X, point.Position.Y);
        if (holdStackTarget || stackDrag.Mode is DockDragMode.StackCandidate or DockDragMode.StackMerge) reorderTargetIndex = reorderSourceIndex;
        ApplyReorderVisuals(draggedCenter);
        e.Handled = true;
    }


    private void ApplyReorderVisuals(Vector2 draggedCenter)
    {
        if (!reorderDragging ||
            reorderButton is null ||
            reorderPinnedButtons.Count == 0)
        {
            return;
        }

        var slot = Appearance.ButtonWidth + Appearance.IconSpacing;

        for (var index = 0; index < reorderPinnedButtons.Count; index++)
        {
            var candidate = reorderPinnedButtons[index];

            if (ReferenceEquals(candidate, reorderButton))
            {
                if (dragLensButton is not null) dragLensTarget = draggedCenter;
                else
                {
                    var dragTransform = candidate.RenderTransform as TranslateTransform ?? new TranslateTransform();
                    dragTransform.X = draggedCenter.X - reorderSourceCenterRoot.X;
                    dragTransform.Y = draggedCenter.Y - reorderSourceCenterRoot.Y;
                    candidate.RenderTransform = dragTransform;
                }
                continue;
            }

            double shift = 0;

            if (reorderTargetIndex > reorderSourceIndex &&
                index > reorderSourceIndex &&
                index <= reorderTargetIndex)
            {
                shift = -slot;
            }
            else if (reorderTargetIndex < reorderSourceIndex &&
                     index >= reorderTargetIndex &&
                     index < reorderSourceIndex)
            {
                shift = slot;
            }

            AnimateReorderShift(candidate, shift);
        }
    }

    private void FinishReorder(
        Button button,
        DockApplicationItem item,
        PointerRoutedEventArgs e)
    {
        if (!ReferenceEquals(reorderButton, button) ||
            !ReferenceEquals(reorderCandidate, item))
        {
            return;
        }

        var release = e.GetCurrentPoint(icons).Properties;
        if (release.IsLeftButtonPressed || release.PointerUpdateKind == Microsoft.UI.Input.PointerUpdateKind.RightButtonReleased)
        {
            if (reorderDragging) { dragIntent.Observe(release.IsLeftButtonPressed, release.IsRightButtonPressed); e.Handled = true; }
            return;
        }

        if (!reorderDragging)
        {
            ClearReorderState();
            button.ReleasePointerCapture(e.Pointer);
            return;
        }

        if (FinishStackMerge(button, item, e)) return;
        if (dragPointerTarget.Mode != DockPointerMode.Reorder)
        {
            CancelReorder(); e.Handled = true; return;
        }

        var orderedIds = VisibleDockApplications
            .Select(candidate => candidate.Id)
            .ToList();

        var committedWithAnimation = false;

        if (reorderSourceIndex >= 0 &&
            reorderSourceIndex < orderedIds.Count &&
            reorderTargetIndex >= 0 &&
            reorderTargetIndex < orderedIds.Count &&
            reorderSourceIndex != reorderTargetIndex)
        {
            var draggedId = orderedIds[reorderSourceIndex];
            orderedIds.RemoveAt(reorderSourceIndex);
            orderedIds.Insert(reorderTargetIndex, draggedId);

            if (applicationService.ReorderApplications(orderedIds))
            {
                reorderCommitting = true;
                try
                {
                    ApplyPinnedCollectionOrder(orderedIds);
                    ApplyPinnedVisualOrderSmooth(orderedIds);
                    CaptureDragLensReleaseSlot();
                    committedWithAnimation = true;
                }
                finally
                {
                    reorderCommitting = false;
                }

                SetStatus("App order saved.");
            }
            else
            {
                SetStatus("Doky could not save the app order.");
                SynchronizeItems();
            }
        }

        suppressClickUntil[item.Id] = DateTime.UtcNow.AddMilliseconds(750);

        if (!committedWithAnimation)
            ResetReorderVisuals();

        ClearReorderState();

        button.ReleasePointerCapture(e.Pointer);

        pointerInsideDock = windowManager.IsPointerInsideInput();
        RefreshHoverVisuals();
        e.Handled = true;
    }

    private void ApplyPinnedCollectionOrder(IReadOnlyList<string> orderedIds)
    {
        for (var targetIndex = 0; targetIndex < orderedIds.Count; targetIndex++)
        {
            var item = VisibleDockApplications
                .FirstOrDefault(candidate => candidate.Id == orderedIds[targetIndex]);

            if (item is null)
                continue;

            var currentIndex = VisibleDockApplications.IndexOf(item);
            if (currentIndex >= 0 && currentIndex != targetIndex)
                VisibleDockApplications.Move(currentIndex, targetIndex);
        }
    }

    private void ApplyPinnedVisualOrderSmooth(IReadOnlyList<string> orderedIds)
    {
        StopReorderShifts();
        var orderedButtons = orderedIds
            .Select(id => applicationButtons.GetValueOrDefault(id))
            .Where(button => button is not null)
            .Cast<Button>()
            .ToArray();

        var oldPositions = orderedButtons.ToDictionary(
            button => button,
            button => button
                .TransformToVisual(icons)
                .TransformPoint(new global::Windows.Foundation.Point(0, 0)));

        foreach (var candidate in orderedButtons)
        {
            candidate.RenderTransform = null;
            candidate.Opacity = 1;
            Canvas.SetZIndex(candidate, 0);
        }

        for (var index = 0; index < orderedIds.Count; index++)
        {
            if (!applicationButtons.TryGetValue(orderedIds[index], out var candidate))
                continue;

            var currentIndex = icons.Children.IndexOf(candidate);
            if (currentIndex == index)
                continue;

            if (currentIndex >= 0)
                icons.Children.RemoveAt(currentIndex);

            icons.Children.Insert(index, candidate);
        }

        icons.UpdateLayout();

        foreach (var candidate in orderedButtons)
        {
            if (ReferenceEquals(candidate, dragLensButton)) continue;
            var newPosition = candidate
                .TransformToVisual(icons)
                .TransformPoint(new global::Windows.Foundation.Point(0, 0));

            var oldPosition = oldPositions[candidate];
            var deltaX = oldPosition.X - newPosition.X;
            var deltaY = oldPosition.Y - newPosition.Y;

            if (Math.Abs(deltaX) < 0.5 && Math.Abs(deltaY) < 0.5)
                continue;

            var transform = new TranslateTransform
            {
                X = deltaX,
                Y = deltaY
            };

            candidate.RenderTransform = transform;

            var storyboard = new Microsoft.UI.Xaml.Media.Animation.Storyboard();
            var easing = new Microsoft.UI.Xaml.Media.Animation.CubicEase
            {
                EasingMode = Microsoft.UI.Xaml.Media.Animation.EasingMode.EaseOut
            };

            var xAnimation = new Microsoft.UI.Xaml.Media.Animation.DoubleAnimation
            {
                From = deltaX,
                To = 0,
                Duration = new Duration(TimeSpan.FromMilliseconds(150)),
                EasingFunction = easing,
                EnableDependentAnimation = true
            };

            var yAnimation = new Microsoft.UI.Xaml.Media.Animation.DoubleAnimation
            {
                From = deltaY,
                To = 0,
                Duration = new Duration(TimeSpan.FromMilliseconds(150)),
                EasingFunction = easing,
                EnableDependentAnimation = true
            };

            Microsoft.UI.Xaml.Media.Animation.Storyboard.SetTarget(
                xAnimation,
                transform);

            Microsoft.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(
                xAnimation,
                nameof(TranslateTransform.X));

            Microsoft.UI.Xaml.Media.Animation.Storyboard.SetTarget(
                yAnimation,
                transform);

            Microsoft.UI.Xaml.Media.Animation.Storyboard.SetTargetProperty(
                yAnimation,
                nameof(TranslateTransform.Y));

            storyboard.Children.Add(xAnimation);
            storyboard.Children.Add(yAnimation);

            storyboard.Completed += (_, _) =>
            {
                if (ReferenceEquals(candidate.RenderTransform, transform))
                    candidate.RenderTransform = null;
            };

            storyboard.Begin();
        }
    }

    private void CancelReorder()
    {
        if (reorderButton is null)
            return;

        var captured = reorderButton;
        if (reorderDragging && reorderCandidate is not null)
            suppressClickUntil[reorderCandidate.Id] = DateTime.UtcNow.AddMilliseconds(750);
        ResetReorderVisuals();
        ClearReorderState();
        captured.ReleasePointerCaptures();
    }

    private void ResetReorderVisuals()
    {
        StopReorderShifts();
        foreach (var button in reorderPinnedButtons)
        {
            button.RenderTransform = null;
            button.Opacity = 1;
            Canvas.SetZIndex(button, 0);
        }

        if (reorderButton is not null &&
            !reorderPinnedButtons.Contains(reorderButton))
        {
            reorderButton.RenderTransform = null;
            reorderButton.Opacity = 1;
            Canvas.SetZIndex(reorderButton, 0);
        }
    }

    private void ClearReorderState()
    {
        StopReorderShifts();
        EndDragLens();
        ClearStackDrag();
        reorderCandidate = null;
        reorderButton = null;
        reorderStartX = 0;
        reorderGrabOffset = default;
        reorderSourceCenterRoot = default;
        reorderDragging = false;
        reorderSourceIndex = -1;
        reorderTargetIndex = -1;
        reorderPinnedButtons.Clear();
        reorderSlotCenters = [];
    }

    private void ApplicationDragEnter(Button button, DockApplicationItem item, DragEventArgs e)
    {
        if (StackItemDragOver(e)) return;
        if (closing || shutdown.IsRequested || !HasStorageItems(e))
        {
            e.AcceptedOperation = DataPackageOperation.None;
            e.Handled = true;
            return;
        }

        if (!WindowsApplicationLauncher.CanOpenWith(item.Application))
        {
            if (ReferenceEquals(externalDropTargetButton, button))
                SetApplicationDropTarget(button, false);

            e.AcceptedOperation = DataPackageOperation.Copy;
            e.Handled = false;
            return;
        }

        e.AcceptedOperation = DataPackageOperation.Copy;
        e.DragUIOverride.Caption = $"Open with {item.Name}";
        e.DragUIOverride.IsCaptionVisible = true;
        SetApplicationDropTarget(button, true);
        e.Handled = true;
    }

    private void ApplicationDragOver(Button button, DockApplicationItem item, DragEventArgs e)
    {
        if (StackItemDragOver(e)) return;
        if (closing || shutdown.IsRequested || !HasStorageItems(e))
        {
            e.AcceptedOperation = DataPackageOperation.None;
            e.Handled = true;
            return;
        }

        if (!WindowsApplicationLauncher.CanOpenWith(item.Application))
        {
            if (ReferenceEquals(externalDropTargetButton, button))
                SetApplicationDropTarget(button, false);

            e.AcceptedOperation = DataPackageOperation.Copy;
            e.Handled = false;
            return;
        }

        e.AcceptedOperation = DataPackageOperation.Copy;
        e.DragUIOverride.Caption = $"Open with {item.Name}";
        e.DragUIOverride.IsCaptionVisible = true;
        collapseDelay?.Cancel();
        CancelPillHide();
        if (!ReferenceEquals(externalDropTargetButton, button))
            SetApplicationDropTarget(button, true);
        e.Handled = true;
    }

    private void ApplicationDragLeave(Button button, DragEventArgs e)
    {
        if (!ReferenceEquals(externalDropTargetButton, button))
            return;

        SetApplicationDropTarget(button, false);
        e.Handled = true;
    }

    private async Task ApplicationDropAsync(Button button, DockApplicationItem item, DragEventArgs e)
    {
        if (await StackItemDrop(e, item.Id)) return;
        if (closing || shutdown.IsRequested || !HasStorageItems(e))
        {
            e.AcceptedOperation = DataPackageOperation.None;
            SetApplicationDropTarget(button, false);
            e.Handled = true;
            return;
        }

        e.AcceptedOperation = DataPackageOperation.Copy;
        e.Handled = true;

        var deferral = e.GetDeferral();
        try
        {
            var storageItems = await e.DataView.GetStorageItemsAsync();
            var paths = storageItems
                .Select(storageItem => storageItem.Path)
                .Where(path => !string.IsNullOrWhiteSpace(path))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();

            if (paths.Length == 0)
            {
                SetStatus("No usable file path was dropped.");
                return;
            }

            if (paths.All(IsDockPinTarget))
            {
                var added = 0;

                foreach (var path in paths)
                {
                    if (applicationService.PinExternalTarget(path))
                        added++;
                }

                SetStatus(added switch
                {
                    0 => "Nothing was pinned.",
                    1 => "Pinned 1 item to Doky.",
                    _ => $"Pinned {added} items to Doky."
                });
                return;
            }

            if (!WindowsApplicationLauncher.CanOpenWith(item.Application))
            {
                e.AcceptedOperation = DataPackageOperation.None;
                SetStatus($"{item.Name} does not expose a supported file-drop launch target.");
                return;
            }

            if (dropLauncher.OpenWith(item.Application, paths))
                SetStatus(paths.Length == 1 ? $"Opened dropped item with {item.Name}." : $"Opened {paths.Length} dropped items with {item.Name}.");
            else
                SetStatus($"{item.Name} could not open the dropped item.");
        }
        catch (Exception error) when (error is UnauthorizedAccessException or IOException or InvalidOperationException or ArgumentException or System.Runtime.InteropServices.COMException)
        {
            SetStatus($"{item.Name} could not open the dropped item: {error.Message}");
        }
        finally
        {
            SetApplicationDropTarget(button, false);
            deferral.Complete();
        }
    }

    private void SetApplicationDropTarget(Button button, bool active)
    {
        if (active)
        {
            if (externalDropTargetButton is not null && !ReferenceEquals(externalDropTargetButton, button))
                RestoreApplicationDropTarget(externalDropTargetButton);

            externalDropTargetButton = button;
            externalDropHighlight.Opacity = 0;
            externalDragActive = true; stackDrag.Begin(external: true);
            collapseDelay?.Cancel();
            CancelPillHide();
            previews.Hide();
            animation.ResetMagnification();
            HideDockWave();
            button.BorderThickness = new Thickness(1.5);
            button.BorderBrush = new SolidColorBrush(global::Windows.UI.Color.FromArgb(220, 225, 245, 255));
            button.Background = new SolidColorBrush(global::Windows.UI.Color.FromArgb(54, 150, 210, 255));
            button.Opacity = 1;
            Canvas.SetZIndex(button, 120);
            return;
        }

        if (!ReferenceEquals(externalDropTargetButton, button)) return;
        RestoreApplicationDropTarget(button);
        externalDropTargetButton = null;
        externalDragActive = false; if (stackDrag.Mode == DockDragMode.ExternalFiles) stackDrag.Reset();

        if (!closing)
        {
            pointerInsideDock = windowManager.IsPointerInsideInput();
            RefreshHoverVisuals();
        }
    }

    private static bool IsDockPinTarget(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || Directory.Exists(path))
            return false;

        var extension = Path.GetExtension(path);
        return extension.Equals(".exe", StringComparison.OrdinalIgnoreCase) ||
               extension.Equals(".lnk", StringComparison.OrdinalIgnoreCase) ||
               extension.Equals(".appref-ms", StringComparison.OrdinalIgnoreCase) ||
               extension.Equals(".url", StringComparison.OrdinalIgnoreCase) ||
               extension.Equals(".com", StringComparison.OrdinalIgnoreCase) ||
               extension.Equals(".cmd", StringComparison.OrdinalIgnoreCase) ||
               extension.Equals(".bat", StringComparison.OrdinalIgnoreCase);
    }

    private static void RestoreApplicationDropTarget(Button button)
    {
        button.BorderThickness = new Thickness(0);
        button.BorderBrush = new SolidColorBrush(Colors.Transparent);
        button.Background = new SolidColorBrush(Colors.Transparent);
        button.Opacity = 1;
        Canvas.SetZIndex(button, 0);
    }

    private void UpdateExternalDropHighlight()
    {
        externalDropHighlight.Width = Math.Max(0, surface.ActualWidth > 0 ? surface.ActualWidth : surface.Width);
        externalDropHighlight.Height = Math.Max(
            0,
            surface.ActualHeight > 0 ? surface.ActualHeight : ExpandedDockHeight);
        externalDropHighlight.Margin = surface.Margin;
    }

    private void SetExternalDropVisual(bool active)
    {
        externalDragActive = active;
        if (active && stackDrag.Mode == DockDragMode.None) stackDrag.Begin(external: true);
        else if (!active && stackDrag.Mode == DockDragMode.ExternalFiles) stackDrag.Reset();
        UpdateExternalDropHighlight();

        if (!active && externalDropTargetButton is not null)
        {
            RestoreApplicationDropTarget(externalDropTargetButton);
            externalDropTargetButton = null;
        }

        externalDropHighlight.Opacity = active && externalDropTargetButton is null ? 1 : 0;

        if (active)
        {
            collapseDelay?.Cancel();
            CancelPillHide();
            previews.Hide();
            animation.ResetMagnification();
            HideDockWave();
        }
        else if (!closing)
        {
            pointerInsideDock = windowManager.IsPointerInsideInput();
            RefreshHoverVisuals();
        }
    }

    private static bool HasStorageItems(DragEventArgs e) =>
        e.DataView.Contains(StandardDataFormats.StorageItems);

    private async void ExternalDragEnter(object sender, DragEventArgs e)
    {
        if (StackItemDragOver(e)) return;
        if (closing || shutdown.IsRequested || !HasStorageItems(e))
        {
            e.AcceptedOperation = DataPackageOperation.None;
            return;
        }

        e.AcceptedOperation = DataPackageOperation.Copy;

        if (externalDropTargetButton is null)
        {
            e.DragUIOverride.Caption = "Pin to Doky";
            e.DragUIOverride.IsCaptionVisible = true;
            SetExternalDropVisual(true);
        }

        if (state.State is DockState.Idle or DockState.Hovering)
            await ExpandDockAsync();
    }

    private async void ExternalDragOver(object sender, DragEventArgs e)
    {
        if (StackItemDragOver(e)) return;
        if (closing || shutdown.IsRequested || !HasStorageItems(e))
        {
            e.AcceptedOperation = DataPackageOperation.None;
            return;
        }

        e.AcceptedOperation = DataPackageOperation.Copy;

        collapseDelay?.Cancel();
        CancelPillHide();

        if (externalDropTargetButton is null)
        {
            e.DragUIOverride.Caption = "Pin to Doky";
            e.DragUIOverride.IsCaptionVisible = true;
            SetExternalDropVisual(true);
        }

        if (state.State is DockState.Idle or DockState.Hovering)
            await ExpandDockAsync();
    }

    private void ExternalDragLeave(object sender, DragEventArgs e)
    {
        SetExternalDropVisual(false);

        if (!previews.HoldsDock &&
            state.State is DockState.Expanded or DockState.Expanding &&
            !windowManager.IsPointerInsideInput())
        {
            ScheduleCollapse();
        }
    }

    private async void ExternalDrop(object sender, DragEventArgs e)
    {
        if (await StackItemDrop(e)) return;
        if (closing || shutdown.IsRequested || !HasStorageItems(e))
        {
            e.AcceptedOperation = DataPackageOperation.None;
            SetExternalDropVisual(false);
            return;
        }

        e.AcceptedOperation = DataPackageOperation.Copy;

        if (externalDropTargetButton is not null)
        {
            e.Handled = true;
            return;
        }

        e.Handled = true;
        var deferral = e.GetDeferral();
        try
        {
            var items = await e.DataView.GetStorageItemsAsync();
            var paths = items
                .Select(item => item.Path)
                .Where(path => !string.IsNullOrWhiteSpace(path))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();

            var added = 0;

            foreach (var path in paths.Where(IsDockPinTarget))
            {
                if (applicationService.PinExternalTarget(path))
                    added++;
            }

            SetStatus(added switch
            {
                0 => "Nothing was pinned.",
                1 => "Pinned 1 item to Doky.",
                _ => $"Pinned {added} items to Doky."
            });
        }
        catch (Exception error) when (
            error is UnauthorizedAccessException or
            IOException or
            InvalidOperationException)
        {
            SetStatus($"Doky could not pin the dropped item: {error.Message}");
        }
        finally
        {
            SetExternalDropVisual(false);
            deferral.Complete();
        }
    }

    private void Entered(object sender, PointerRoutedEventArgs e)
    {
        if (snippingPending) return;
        if (animation.IsPlacementAnimating || pinDockTransitionActive) return;
        if (!windowManager.IsPointerInsideInput()) return;
        pointerInsideDock = true;
        collapseDelay?.Cancel();
        CancelPillHide();
        if (previews.ContextMenuOpen) return;
        if (state.State == DockState.Expanded) RefreshHoverVisuals();
    }

    private void RaisePeek()
    {
        if (DockPinLock) return;
        state.Enter();
        indicator.Opacity = 1;
        animation.AnimateBottom(BottomMargin, 180);
        UpdatePeekInput();
    }

    private void UpdatePeekInput() => windowManager.SetPeekInteraction(surface.Margin.Bottom);

    private void OnInteractionHoldChanged()
    {
        if (closing) return;
        pointerInsideDock = windowManager.IsPointerInsideInput();
        keyboard.SuppressDockToggle = previews.ContextMenuOpen;
        animation.HoldMagnification(previews.ContextMenuOpen);
        if (!previews.ContextMenuOpen)
        {
            RefreshHoverVisuals();
            DispatcherQueue.TryEnqueue(() =>
            {
                if (closing || previews.ContextMenuOpen) return;
                SynchronizeItems();
                pointerInsideDock = windowManager.IsPointerInsideInput();
                RefreshHoverVisuals();
            });
        }
        if (previews.HoldsDock)
        {
            collapseDelay?.Cancel();
            CancelPillHide();
            if (previews.ContextMenuOpen)
            {
                StopDockWaveTimer(clear: false);
                dockWaveCurrentStrength = 0;
                dockWaveTargetStrength = 0;
                desktopBackdrop.ClearDockWave();
                UpdateDockWaveOutline();
                UpdateLiquidGlass();
                if (!heldTransition && state.State is DockState.Expanding or DockState.Collapsing)
                {
                    heldTransition = state.HoldTransition();
                    animation.FreezeCurrentTransitions();
                }
                if (state.State is DockState.Idle or DockState.Hovering) RaisePeek();
            }
            return;
        }
        ResumeAfterHold();
    }

    private void RefreshHoverVisuals()
    {
        if (pinDockTransitionActive ||
            dragLensHoverDeferred ||
            dragLensButton is not null ||
            previews.ContextMenuOpen ||
            externalDragActive ||
            reorderButton is not null ||
            StackPopupOpen ||
            state.State != DockState.Expanded)
            return;
        if (pointerInsideDock && windowManager.TryGetPointerPosition(out var x, out var y) &&
            !IsPointerOverUtility(x, y))
        {
            var pointer = root.TransformToVisual(icons).TransformPoint(new(x, y));
            animation.UpdateMagnification(pointer.X, pointer.Y);
            ShowDockWave(x);
        }
        else
        {
            animation.ResetMagnification();
            HideDockWave();
        }
    }

    private void ResumeAfterHold()
    {
        if (closing || snippingPending || previews.HoldsDock) return;
        pointerInsideDock = windowManager.IsPointerInsideInput();
        if (heldTransition)
        {
            heldTransition = false;
            if (pointerInsideDock || DockPinLock) _ = ExpandDockAsync(resume: true);
            else _ = CollapseDockAsync(resume: true);
            return;
        }
        RefreshHoverVisuals();
        if (pointerInsideDock) return;
        if (state.State is DockState.Expanded or DockState.Expanding) ScheduleCollapse();
        else if (state.State is DockState.Idle or DockState.Hovering) SchedulePillHide();
    }

    private void PointerDeparted()
    {
        if (snippingPending) return;
        dragLensHoverDeferred = false;
        pointerInsideDock = false;
        if (previews.ContextMenuOpen ||
            externalDragActive ||
            reorderButton is not null ||
            StackPopupOpen)
            return;
        RefreshHoverVisuals();
        if (previews.HoldsDock) return;
        if (state.State is DockState.Idle or DockState.Hovering) SchedulePillHide();
        else if (state.State is DockState.Expanded or DockState.Expanding) ScheduleCollapse();
    }
    private void Moved(object sender, PointerRoutedEventArgs e)
    {
        if (snippingPending) return;
        if (utilityButtons.Values.Any(button => button.IsDragging))
        { collapseDelay?.Cancel(); HideDockWave(); return; }
        if (dragLensHoverDeferred && dragLensButton is null && reorderButton is null)
        {
            var pointer = e.GetCurrentPoint(root).Position;
            var delta = Vector2.Distance(new((float)pointer.X, (float)pointer.Y), dragLensHoverReleasePointer);
            if (delta > 3f) dragLensHoverDeferred = false;
        }
        if (!windowManager.IsPointerInsideInput()) { PointerDeparted(); return; }
        pointerInsideDock = true;
        collapseDelay?.Cancel();
        CancelPillHide();
        if (dragLensHoverDeferred) return;

        if (previews.ContextMenuOpen ||
            dragLensButton is not null ||
            StackPopupOpen ||
            reorderButton is not null ||
            state.State != DockState.Expanded)
            return;

        var hoverPointer = e.GetCurrentPoint(icons).Position;

        var rootPointer = e.GetCurrentPoint(root).Position;
        if (IsPointerOverUtility(rootPointer.X, rootPointer.Y))
        {
            animation.ResetMagnification();
            HideDockWave();
            return;
        }

        animation.UpdateMagnification(hoverPointer.X, hoverPointer.Y);
        ShowDockWave(e.GetCurrentPoint(root).Position.X);
    }

    private void ShowDockWave(
        double rootX)
    {
        if (!HoverWaveEnabled ||
            !double.IsFinite(rootX) ||
            state.State != DockState.Expanded)
        {
            return;
        }

        dockWaveTargetX =
            ClampDockWaveCenter(
                rootX);

        dockWaveTargetStrength = 1;

        if (dockWaveCurrentX <= 0)
            dockWaveCurrentX = dockWaveTargetX;

        StartDockWaveTimer();
    }

    private void HideDockWave()
    {
        if (!HoverWaveEnabled)
        {
            if (dockWaveCurrentStrength > 0 || dockWaveTargetStrength > 0 || dockWaveTimerRunning)
                ApplyHoverWaveSetting(false);
            return;
        }

        dockWaveTargetStrength = 0;
        if (dockWaveCurrentStrength <= 0.00001 && !dockWaveTimerRunning)
        {
            dockWaveCurrentStrength = 0;
            return;
        }
        StartDockWaveTimer();
    }

    private void TickDockWave(
        object? sender,
        object args)
    {
        if (!HoverWaveEnabled)
        {
            ApplyHoverWaveSetting(false);
            return;
        }

        if (previews.ContextMenuOpen || StackPopupOpen)
        {
            StopDockWaveTimer(clear: false);
            return;
        }

        if (reorderButton is not null)
        {
            dockWaveCurrentStrength = 0;
            dockWaveTargetStrength = 0;
            desktopBackdrop.ClearDockWave();
            UpdateDockWaveOutline();
            dockWaveGlow.Opacity = 0.22;
            dockWaveRim.Opacity = Appearance.BorderOpacity;
            StopDockWaveTimer(clear: false);
            return;
        }
        if (closing)
        {
            StopDockWaveTimer(
                clear: true);

            return;
        }

        dockWaveTargetX =
            ClampDockWaveCenter(
                dockWaveTargetX);

        var now = System.Diagnostics.Stopwatch.GetTimestamp();
        var elapsed = System.Diagnostics.Stopwatch.GetElapsedTime(dockWaveLastFrame, now).TotalSeconds;
        dockWaveLastFrame = now;
        dockWaveCurrentX = GlassDock.Core.Desktop.DockWaveGeometry.Follow(
            dockWaveCurrentX, dockWaveTargetX, elapsed, .0385);
        dockWaveCurrentStrength = GlassDock.Core.Desktop.DockWaveGeometry.Follow(
            dockWaveCurrentStrength, dockWaveTargetStrength, elapsed, .0644);
        desktopBackdrop.SetDockWave(
            dockWaveCurrentX,
            DockWaveHalfWidth,
            DockWaveRise,
            dockWaveCurrentStrength);

        UpdateDockWaveOutline();

        UpdateLiquidGlass();
        var xSettled =
            Math.Abs(
                dockWaveCurrentX -
                dockWaveTargetX) <
            0.001;

        var strengthSettled =
            Math.Abs(
                dockWaveCurrentStrength -
                dockWaveTargetStrength) <
            0.00001;

        if (!xSettled ||
            !strengthSettled)
        {
            return;
        }

        if (dockWaveTargetStrength <= 0)
        {
            dockWaveCurrentStrength = 0;
            desktopBackdrop.ClearDockWave();
            UpdateDockWaveOutline();
        }

        StopDockWaveTimer(
            clear: false);
    }

    private (double Left, double Top, double Width, double Height, double Radius, double CenterX, double HalfWidth, double Rise, double Strength)? cachedWaveOutlineKey;
    private readonly List<(double X, double Y)> cachedWaveOutline = new(128);
    private readonly List<(double Left, double Top, double Right, double Bottom)> reusableIconBounds = new(24);

    private void UpdateDockWaveOutline()
    {
        if (state.State != DockState.Expanded &&
            state.State != DockState.Expanding && state.State != DockState.Collapsing)
        {
            return;
        }

        if (root.ActualWidth <= 0 ||
            root.ActualHeight <= 0 ||
            surface.ActualWidth <= 0 ||
            surface.ActualHeight <= 0)
        {
            return;
        }

        var diagStart = DockPerformanceDiagnostics.Enabled ? System.Diagnostics.Stopwatch.GetTimestamp() : 0;

        var centerX =
            dockWaveCurrentX > 0
                ? dockWaveCurrentX
                : root.ActualWidth / 2;

        var left = (root.ActualWidth - surface.ActualWidth) / 2;
        var top = root.ActualHeight - surface.Margin.Bottom - surface.ActualHeight;
        var width = surface.ActualWidth;
        var height = surface.ActualHeight;
        var radius = ExpandedDockCornerRadius;
        var halfWidth = DockWaveHalfWidth;
        var rise = DockWaveRise;
        var strength = dockWaveCurrentStrength;

        var outlineSame = cachedWaveOutlineKey is { } prev &&
            Math.Abs(prev.Left - left) < 0.001 &&
            Math.Abs(prev.Top - top) < 0.001 &&
            Math.Abs(prev.Width - width) < 0.001 &&
            Math.Abs(prev.Height - height) < 0.001 &&
            Math.Abs(prev.Radius - radius) < 0.001 &&
            Math.Abs(prev.CenterX - centerX) < 0.001 &&
            Math.Abs(prev.HalfWidth - halfWidth) < 0.001 &&
            Math.Abs(prev.Rise - rise) < 0.001 &&
            Math.Abs(prev.Strength - strength) < 0.0001;

        if (!outlineSame)
        {
            cachedWaveOutlineKey = (left, top, width, height, radius, centerX, halfWidth, rise, strength);
            cachedWaveOutline.Clear();
            var waveOutline = GlassDock.Core.Desktop.DockWaveGeometry.Create(
                left, top, width, height, radius, centerX, halfWidth, rise, strength);
            var point = waveOutline.Start;
            cachedWaveOutline.Add((point.X, point.Y));
            foreach (var segment in waveOutline.Segments)
            {
                if (segment.IsLine)
                {
                    point = segment.End;
                    cachedWaveOutline.Add((point.X, point.Y));
                }
                else
                {
                    var start = point;
                    var c1 = segment.Control1;
                    var c2 = segment.Control2;
                    var end = segment.End;
                    for (var i = 1; i <= 24; i++)
                    {
                        var t = i / 24d;
                        var u = 1 - t;
                        cachedWaveOutline.Add((
                            u * u * u * start.X + 3 * u * u * t * c1.X + 3 * u * t * t * c2.X + t * t * t * end.X,
                            u * u * u * start.Y + 3 * u * u * t * c1.Y + 3 * u * t * t * c2.Y + t * t * t * end.Y));
                    }
                    point = end;
                }
            }
        }

        reusableIconBounds.Clear();
        foreach (var button in applicationButtons.Values)
        {
            if (!button.IsLoaded || button.Content is not Grid content ||
                content.Children.OfType<AdaptiveAppIcon>().FirstOrDefault() is not { } icon) continue;
            var bounds = icon.TransformToVisual(root).TransformBounds(new(0, 0, icon.ActualWidth, icon.ActualHeight));
            reusableIconBounds.Add((bounds.Left, bounds.Top, bounds.Right, bounds.Bottom));
        }

        DockPerformanceDiagnostics.RecordGeometry(
            rebuilt: !outlineSame,
            diagStart != 0 ? System.Diagnostics.Stopwatch.GetTimestamp() - diagStart : 0);

        PositionUtilities();
        foreach (var button in utilityButtons.Values)
        {
            var bounds = button.Glass.Bounds;
            if (!button.FloatingPresentation && button.Visibility == Visibility.Visible && button.IsHitTestVisible && utilityArea.Visibility == Visibility.Visible)
                reusableIconBounds.Add((bounds.X - 2, bounds.Y - 2, bounds.X + bounds.Z + 2, bounds.Y + bounds.W + 2));
        }
        if (GridUtilities && quickSettingsButton is { IsHitTestVisible: true } gridButton && utilityArea.Visibility == Visibility.Visible)
        {
            var bounds = gridButton.Glass.Bounds;
            reusableIconBounds.Add((bounds.X - 2, bounds.Y - 2, bounds.X + bounds.Z + 2, bounds.Y + bounds.W + 2));
        }
        windowManager.SetInteractionPolygon(cachedWaveOutline, reusableIconBounds);
    }
    private double ClampDockWaveCenter(
        double value)
    {
        var dockWidth =
            surface.ActualWidth > 0
                ? surface.ActualWidth
                : surface.Width;

        if (!double.IsFinite(dockWidth) ||
            dockWidth <= 0 ||
            root.ActualWidth <= 0)
        {
            return value;
        }

        var dockHeight =
            surface.ActualHeight > 0
                ? surface.ActualHeight
                : 68;

        var radius =
            Math.Max(
                0,
                Math.Min(
                    ExpandedDockCornerRadius,
                    Math.Min(
                        dockHeight / 2,
                        dockWidth / 2)));

        var left =
            (root.ActualWidth -
             dockWidth) /
            2;

        var topStart =
            left +
            radius;

        var topEnd =
            left +
            dockWidth -
            radius;

        const double crestInset = 4;

        var minimum =
            topStart +
            crestInset;

        var maximum =
            topEnd -
            crestInset;

        return minimum <= maximum
            ? Math.Clamp(
                value,
                minimum,
                maximum)
            : left +
              dockWidth / 2;
    }

    private static double Lerp(
        double current,
        double target,
        double amount) =>
        current +
        (target - current) *
        Math.Clamp(
            amount,
            0,
            1);

    private void StartDockWaveTimer()
    {
        if (!HoverWaveEnabled || dockWaveTimerRunning)
            return;

        dockWaveTimerRunning = true;
        dockWaveLastFrame = System.Diagnostics.Stopwatch.GetTimestamp();
        CompositionTarget.Rendering += TickDockWave;
    }

    private void StopDockWaveTimer(
        bool clear)
    {
        if (dockWaveTimerRunning)
        {
            dockWaveTimerRunning = false;
            CompositionTarget.Rendering -= TickDockWave;
        }

        if (!clear)
            return;

        dockWaveCurrentStrength = 0;
        dockWaveTargetStrength = 0;
        dockWaveGlow.Opacity = 0;
        dockWaveRim.Opacity = 0;
        desktopBackdrop.ClearDockWave();
    }

    private void ApplyHoverWaveSetting(bool enabled)
    {
        if (enabled)
        {
            dockWaveCurrentStrength = 0;
            dockWaveTargetStrength = 0;
            desktopBackdrop.ClearDockWave();
            UpdateDockWaveOutline();
            return;
        }

        StopDockWaveTimer(clear: false);
        dockWaveCurrentStrength = 0;
        dockWaveTargetStrength = 0;
        desktopBackdrop.ClearDockWave();

        UpdateDockWaveOutline();
    }

    private void RequestDockToggle()
    {
        if (!DispatcherQueue.HasThreadAccess)
        {
            DispatcherQueue.TryEnqueue(RequestDockToggle);
            return;
        }
        if (closing || shutdown.IsRequested) return;
        _ = ObserveDockToggleAsync();
    }

    private async Task ObserveDockToggleAsync()
    {
        try
        {
            await ToggleDockAsync();
        }
        catch (Exception error) when (error is not OutOfMemoryException)
        {
            System.Diagnostics.Debug.WriteLine($"Doky dock toggle failed: {error}");
            StartupDiagnostics.Write("Dock transition failed", error);
            if (!closing) SetStatus($"Dock transition failed: {error.Message}");
        }
    }

    private Task ToggleDockAsync()
    {
        if (windowManager.FullscreenSuppressed) return Task.CompletedTask;
        if (previews.ContextMenuOpen)
            return Task.CompletedTask;

        if (StackPopupOpen)
        {
            stackWindow?.Hide();
            return Task.CompletedTask;
        }

        if (DockPinLock)
            return state.State is DockState.Expanded or DockState.Expanding
                ? Task.CompletedTask
                : ExpandDockAsync();

        if (settingsSession.Current.HoverToExpandOnly &&
            state.State is DockState.Idle or DockState.Hovering)
            return Task.CompletedTask;

        return state.State is DockState.Expanded or DockState.Expanding
            ? CollapseDockAsync()
            : ExpandDockAsync();
    }

    private async Task ExpandDockAsync(bool resume = false)
    {
        if (closing || shutdown.IsRequested || state.State == DockState.Hidden || previews.ContextMenuOpen) return;
        collapseDelay?.Cancel();

        CancelPillHide();
        if (state.State == DockState.Expanded || (!resume && state.State == DockState.Expanding)) return;
        var reversing = state.State == DockState.Collapsing;
        var revision = state.Expand();
        UpdateDockWaveOutline();
        if (!reversing) ApplyMaterial(true);
        var targetWidth = CalculateTargetDockWidth();
        if (await animation.AnimateAsync(true, targetWidth, ExpandedDockHeight, BottomMargin) &&
            !closing && !shutdown.IsRequested && revision == state.Revision)
        {
            state.Complete(revision);
            icons.IsHitTestVisible = state.State == DockState.Expanded;

            if (state.State == DockState.Expanded)
            {
                dockWaveGlow.Opacity = 0.22;
                dockWaveRim.Opacity = Appearance.BorderOpacity;
                UpdateDockWaveOutline();
                if (!previews.ContextMenuOpen) ResumeAfterHold();
            }
        }
    }

    private void Exited(object sender, PointerRoutedEventArgs e)
    {
        if (animation.IsPlacementAnimating || pinDockTransitionActive) return;
        if (!windowManager.IsPointerInsideInput()) PointerDeparted();
    }
    private async Task CollapseDockAsync(bool resume = false)
    {
        if (closing || shutdown.IsRequested || snippingPending || state.State is DockState.Hidden or DockState.Idle ||
            (!resume && state.State == DockState.Collapsing)) return;
        if (DockPinLock || previews.HoldsDock || StackPopupOpen) return;
        if (keyboardDockNavigation) return;
        if (externalDragActive) return;
        if (reorderButton is not null) CancelReorder();
        if (dragLensButton is not null) AbortDragLens();
        previews.Hide();

        CancelPillHide();
        animation.ResetMagnification();
        HideDockWave();

        dockWaveGlow.Opacity = 0;
        dockWaveRim.Opacity = 0;

        collapseDelay?.Cancel();
        var revision = state.Collapse();
        icons.IsHitTestVisible = false;
        if (await animation.AnimateAsync(false, CalculateTargetDockWidth(), ExpandedDockHeight, BottomMargin) &&
            !closing && !shutdown.IsRequested && revision == state.Revision)
        {
            state.Complete(revision);
            if (state.State == DockState.Idle)
            {
                ApplyMaterial(false);
                liquidGlass.DeactivateCapture();
                indicator.Opacity = 1;
                UpdatePeekInput();
                SchedulePillHide();
            }
        }
    }

    private void CancelPillHide()
    {
        pillHideDelay?.Cancel();
        pillHideDelay = null;
        animation.StopIndicatorOpacityAnimation();
    }

    private async void SchedulePillHide()
    {
        if (DockPinLock || pillHideDelay is not null || closing || snippingPending || previews.HoldsDock ||
            state.State is not (DockState.Idle or DockState.Hovering) ||
            surface.Margin.Bottom <= PeekRestBottom + 0.01) return;
        var delay = new CancellationTokenSource();
        pillHideDelay = delay;
        try
        {
            await Task.Delay(settingsSession.DockBehavior.PeekDelay, delay.Token);
            if (delay.IsCancellationRequested || closing || snippingPending || previews.HoldsDock ||
                state.State is not (DockState.Idle or DockState.Hovering)) return;
            pointerInsideDock = windowManager.IsPointerInsideInput();
            if (pointerInsideDock) return;
            state.LeavePeek();
            animation.AnimateBottom(PeekRestBottom, PillHideDurationMilliseconds);
        }
        catch (OperationCanceledException) { }
        finally
        {
            if (ReferenceEquals(pillHideDelay, delay)) pillHideDelay = null;
            delay.Dispose();
        }
    }
    private async void ScheduleCollapse()
    {
        if (DockPinLock || collapseDelay is { IsCancellationRequested: false } || closing || snippingPending || previews.HoldsDock || keyboardDockNavigation) return;
        var delay = new CancellationTokenSource();
        collapseDelay = delay;
        try
        {
            await Task.Delay(settingsSession.DockBehavior.AutoHideDelay, delay.Token);
            if (delay.IsCancellationRequested || closing || snippingPending || keyboardDockNavigation || previews.HoldsDock || windowManager.IsPointerInsideInput()) return;
            DockAnimationController.Trace($"Collapse delay elapsed state={state.State}");
            await CollapseDockAsync();
        }
        catch (OperationCanceledException) { }
        finally { if (ReferenceEquals(collapseDelay, delay)) collapseDelay = null; delay.Dispose(); }
    }

    private async Task ApplyPinDockModeAsync(bool pin, bool animate)
    {
        pinDockTransition?.Cancel();

        var transition = new CancellationTokenSource();
        pinDockTransition = transition;
        pinDockTransitionActive = true;
        collapseDelay?.Cancel();
        CancelPillHide();
        animation.ResetMagnification();
        HideDockWave();

        try
        {
            if (state.State is DockState.Expanding or DockState.Collapsing)
                await WaitForDockTransitionAsync(transition.Token);

            if (pin)
            {
                if (state.State != DockState.Expanded)
                    await ExpandDockAsync();

                if (state.State == DockState.Expanding)
                    await WaitForDockTransitionAsync(transition.Token);

                if (transition.IsCancellationRequested || closing || state.State != DockState.Expanded)
                    return;

                var workAreaReserved = windowManager.SetReservedBottomSpace(Sizing.ReservedHeight);

                await AnimatePinnedPlacementAsync(true, animate, transition.Token);
                transition.Token.ThrowIfCancellationRequested();
                pinnedPlacementActive = true;
                SetStatus(workAreaReserved
                    ? "Dock pinned. Windows work area is reserved above Doky."
                    : "Dock pinned, but Windows could not reserve screen space for maximized windows.");
            }
            else
            {
                if (state.State == DockState.Expanded)
                    await AnimatePinnedPlacementAsync(false, animate, transition.Token);
                else
                    SetPinnedPlacementInstant(pin: false);

                transition.Token.ThrowIfCancellationRequested();
                pinnedPlacementActive = false;
                windowManager.ClearBottomWorkAreaReservation();
                SetStatus($"Dock unpinned · full Windows work area restored · bottom spacing {BottomMargin:0} DIP.");
            }
        }
        catch (OperationCanceledException) when (transition.IsCancellationRequested)
        {
        }
        finally
        {
            if (ReferenceEquals(pinDockTransition, transition))
            {
                pinDockTransition = null;
                pinDockTransitionActive = false;

                if (!closing && !shutdown.IsRequested)
                {
                    pointerInsideDock = windowManager.IsPointerInsideInput();
                    RefreshHoverVisuals();
                    if (!pinDockRequested && !pinnedPlacementActive && !pointerInsideDock &&
                        state.State is DockState.Expanded or DockState.Expanding)
                    {
                        ScheduleCollapse();
                    }
                }
            }

            transition.Dispose();
        }
    }

    private async Task WaitForDockTransitionAsync(CancellationToken cancellationToken)
    {
        var started = System.Diagnostics.Stopwatch.GetTimestamp();
        while (state.State is DockState.Expanding or DockState.Collapsing)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (System.Diagnostics.Stopwatch.GetElapsedTime(started).TotalMilliseconds > 1200)
                break;
            await Task.Delay(16, cancellationToken);
        }
    }

    private async Task AnimatePinnedPlacementAsync(bool pin, bool animate, CancellationToken cancellationToken)
    {
        var startSurfaceBottom = surface.Margin.Bottom;
        var startContentBottom = icons.Margin.Bottom;
        var startIndicatorBottom = indicator.Margin.Bottom;
        var startSurfaceHeight = surface.ActualHeight > 0 ? surface.ActualHeight : surface.Height;

        var targetSurfaceBottom = pin ? Sizing.SurfaceBottom : BottomMargin;
        var targetContentBottom = pin ? Sizing.Gap : BottomMargin;
        var targetSurfaceHeight = ExpandedDockHeight + (pin ? PinnedDockClipDepth : 0);

        if (!animate || !new global::Windows.UI.ViewManagement.UISettings().AnimationsEnabled)
        {
            SetPinnedPlacementFrame(
                targetSurfaceBottom,
                targetContentBottom,
                targetContentBottom,
                targetSurfaceHeight);
            return;
        }

        var started = System.Diagnostics.Stopwatch.GetTimestamp();
        while (true)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var elapsed = System.Diagnostics.Stopwatch.GetElapsedTime(started).TotalMilliseconds;
            var progress = Math.Clamp(elapsed / PinnedDockTransitionDurationMilliseconds, 0, 1);
            var eased = progress * progress * (3 - 2 * progress);

            SetPinnedPlacementFrame(
                Lerp(startSurfaceBottom, targetSurfaceBottom, eased),
                Lerp(startContentBottom, targetContentBottom, eased),
                Lerp(startIndicatorBottom, targetContentBottom, eased),
                Lerp(startSurfaceHeight, targetSurfaceHeight, eased));

            if (progress >= 1)
                break;

            await Task.Delay(16, cancellationToken);
        }
    }

    private void SetPinnedPlacementInstant(bool pin)
    {
        SetPinnedPlacementFrame(
            pin ? Sizing.SurfaceBottom : BottomMargin,
            pin ? Sizing.Gap : BottomMargin,
            pin ? Sizing.Gap : BottomMargin,
            ExpandedDockHeight + (pin ? PinnedDockClipDepth : 0));
    }

    private void SetPinnedPlacementFrame(
        double surfaceBottom,
        double contentBottom,
        double indicatorBottom,
        double surfaceHeight)
    {
        animation.SetPlacementHeight(Math.Max(ExpandedDockHeight, surfaceHeight));
        surface.Height = Math.Max(ExpandedDockHeight, surfaceHeight);
        surface.Margin = new Thickness(0, 0, 0, surfaceBottom);
        icons.Margin = new Thickness(0, 0, 0, contentBottom);
        indicator.Margin = new Thickness(0, 0, 0, indicatorBottom);

        UpdateBackdropBounds();
        UpdateDockWaveOutline();
        UpdateExternalDropHighlight();
        if (StackPopupOpen) RepositionStackPopup();
        previews.Reposition();
    }

    private void ApplyMaterial(bool expanded, DockAppearanceMode? dockAppearance = null)
    {
        var mode = dockAppearance ?? settingsSession.Current.DockAppearanceMode;
        var visuals = settingsSession.Current.GlassVisuals?.DockMaterial;
        desktopBackdrop.VisualMaterial = visuals;
        desktopBackdrop.SpecularHighlightAngle = visuals?.SpecularAngleDegrees ?? settingsSession.Current.SpecularHighlightAngle;
        desktopBackdrop.DockLayoutScale = DockScale;
        liquidGlass.DockLayoutScale = (float)DockScale;
        desktopBackdrop.CircularHighlightsEnabled = mode == DockAppearanceMode.Clear
            ? settingsSession.Current.ClearCircularHighlightsEnabled : settingsSession.Current.CircularHighlightsEnabled;
        liquidGlass.CircularHighlightsEnabled = settingsSession.Current.ClearCircularHighlightsEnabled;
        liquidGlass.Material = (visuals ?? new LiquidGlassMaterial()) with
        {
            RefractionStrength = (float)((visuals?.RefractionStrength ?? settingsSession.Current.ClearRefractionStrength) * DockScale),
            EdgeThickness = (float)((visuals?.EdgeThickness ?? 13) * DockScale),
            SpecularAngleDegrees = (float)(visuals?.SpecularAngleDegrees ?? settingsSession.Current.SpecularHighlightAngle)
        };
        var cornerRadius = expanded ? VisualDockCornerRadius : 2.5;
        const double opacity = 1;

        surface.ApplyPlain(mode, opacity, cornerRadius);
        var glassStyle = mode.GlassStyle();
        var solid = glassStyle is null;
        var reconnect = desktopBackdrop.UseSolidSurface != solid;
        desktopBackdrop.UseSolidSurface = solid;
        desktopBackdrop.UseInnerEdge = !solid;
        if (glassStyle is { } style)
        {
            liquidGlass.SetAppearance(mode, Appearance.ApplyTo(DockMaterialStylePresets.Create(style), true));
            desktopBackdrop.ApplyMainDock(style, Appearance.ApplyTo(DockMaterialStylePresets.Create(style), true) with
            {
                CornerRadius = cornerRadius,
                BorderThickness = visuals?.EdgeWidth * DockScale ?? Appearance.BorderThickness,
                BorderOpacity = expanded ? visuals?.EdgeOpacity ?? Appearance.BorderOpacity : 0
            });
        }
        else
        {
            liquidGlass.SetAppearance(mode, new GlassMaterial());
            desktopBackdrop.SetSolidAppearance(mode, opacity, cornerRadius);
        }
        if (reconnect) desktopBackdrop.RebuildConnectedSurface();
        ApplyIndicatorAppearance(mode);
        UpdateBackdropBounds();
    }

    private void ApplyIndicatorAppearance(DockAppearanceMode mode)
    {
        indicator.Background = new SolidColorBrush(
            mode is DockAppearanceMode.Light or DockAppearanceMode.Dark
                ? DockControlPalette.SolidSurface(mode)
                : global::Windows.UI.Color.FromArgb(255, 243, 243, 243));
    }

    private void UpdateBackdropBounds()
    {
        desktopBackdrop.SetBounds(
            root.ActualWidth,
            root.ActualHeight,
            surface.ActualWidth,
            surface.ActualHeight,
            surface.Margin.Bottom,
            root.XamlRoot?.RasterizationScale ?? 1,
            surface.Opacity);

        if (state.State is DockState.Expanded or DockState.Expanding)
        {
            if (HoverWaveEnabled)
            {
                desktopBackdrop.SetDockWave(
                    dockWaveCurrentX > 0
                        ? dockWaveCurrentX
                        : root.ActualWidth / 2,
                    DockWaveHalfWidth,
                    DockWaveRise,
                    dockWaveCurrentStrength);
            }
            else
            {
                desktopBackdrop.ClearDockWave();
            }

            UpdateDockWaveOutline();
        }
        UpdateLiquidGlass();
    }

    private void UpdateLiquidGlass()
    {
        if (liquidGlass is null || !root.IsLoaded) return;
        PositionUtilities();
        var scale = (float)(root.XamlRoot?.RasterizationScale ?? 1);
        var strength = HoverWaveEnabled ? dockWaveCurrentStrength : 0;
        var amplitude = DockWaveRise * strength * strength * (3 - 2 * strength);
        liquidGlass.Update(!closing && !windowManager.FullscreenSuppressed && settingsSession.Current.DockAppearanceMode == DockAppearanceMode.Clear &&
                state.State is (DockState.Expanding or DockState.Expanded or DockState.Collapsing) &&
                (Application.Current as App)?.BasicRendering != true,
            surface.Opacity, scale,
            new Vector4((float)((root.ActualWidth - surface.ActualWidth) / 2),
                (float)(root.ActualHeight - surface.Margin.Bottom - surface.ActualHeight),
                (float)surface.ActualWidth, (float)surface.ActualHeight),
            new Vector4((float)(dockWaveCurrentX > 0 ? dockWaveCurrentX : root.ActualWidth / 2),
                (float)DockWaveHalfWidth, (float)amplitude, (float)Math.Min(VisualDockCornerRadius, surface.ActualHeight / 2)));
    }

    private void SettingsChanged(
        object? sender,
        GlassDockSettingsChangedEventArgs eventArgs)
    {
        if (closing) return;
        CancelReorder();
        AbortDragLens();

        var pinChanged = pinDockRequested != eventArgs.Settings.PinDock;
        var sizingChanged = appliedSizing != Sizing;
        pinDockRequested = eventArgs.Settings.PinDock;
        var notificationBadgesChanged = notificationBadgesRequested != eventArgs.Settings.NotificationBadgesEnabled;
        notificationBadgesRequested = eventArgs.Settings.NotificationBadgesEnabled;

        if (Math.Abs(BottomMargin - eventArgs.Settings.BottomMargin * DockScale) > 0.001)
            ApplyBottomMargin(eventArgs.Settings.BottomMargin, repositionNativeWindow: false);
        ApplyDisplayMode(eventArgs.Settings.DockDisplayMode);
        ApplyHoverWaveSetting(eventArgs.Settings.HoverWaveEnabled);
        ApplyAppearance(settingsSession.Appearance,
            eventArgs.Settings.DockAppearanceMode);

        if (eventArgs.Settings.HoverToExpandOnly &&
            state.State is DockState.Idle or DockState.Hovering &&
            windowManager.IsPointerInsideInput())
            _ = ExpandDockAsync();

        if (ownsGlobalServices && notificationBadgesChanged)
        {
            if (notificationBadgesRequested)
                _ = badges.StartAsync();
            else
                badges.Stop();
        }

        if (pinChanged || (pinDockRequested && (sizingChanged || (!pinnedPlacementActive && !pinDockTransitionActive))))
            _ = ApplyPinDockModeAsync(pinDockRequested, animate: true);
    }

    private void ApplyAppearance(DockAppearanceSettings appearance) =>
        ApplyAppearance(appearance, settingsSession.Current.DockAppearanceMode);

    private void ApplyAppearance(
        DockAppearanceSettings appearance,
        DockAppearanceMode dockAppearance)
    {
        stackWindow?.ApplyAppearance(appearance, dockAppearance);
        appearance = appearance.ForDock(DockScale).FitAppRow(VisibleDockApplications.Count, AvailableDockWidth, 36d * DockScale);
        appliedSizing = Sizing;
        animation.SetLayoutScale(DockScale);
        icons.Spacing = appearance.IconSpacing;
        icons.Height = ExpandedDockHeight;
        if (pinnedPlacementActive)
            windowManager.SetReservedBottomSpace(Sizing.ReservedHeight);
        dockWaveRim.StrokeThickness = 0;
        dockWaveRim.Opacity = 0;
        var foreground = DockForegroundBrush();
        icons.RequestedTheme = dockAppearance == DockAppearanceMode.Light ? ElementTheme.Light : ElementTheme.Dark;
        foreach (var button in applicationButtons.Values)
        {
            if (button.Content is not Grid content ||
                content.Children.FirstOrDefault() is not AdaptiveAppIcon icon)
                continue;

            ApplyIconLayout(button, content, icon, appearance);
            icon.SetDockAppearance(dockAppearance);
            foreach (var running in content.Children.OfType<Border>())
            {
                running.Background = foreground;
                StyleRunningIndicator(running, dockAppearance);
            }
        }

        foreach (var (id, button) in applicationButtons) ApplyButtonVisual(id, button);
        SynchronizeUtilities();

        if (state.State is DockState.Expanded)
        {
            animation.ResizeExpanded(CalculateTargetDockWidth(), ExpandedDockHeight + (pinnedPlacementActive ? PinnedDockClipDepth : 0));
            if (pinnedPlacementActive) SetPinnedPlacementInstant(true);
            ApplyMaterial(expanded: true, dockAppearance: dockAppearance);
        }
        else
        {
            ApplyMaterial(expanded: false, dockAppearance: dockAppearance);
            if (state.State is DockState.Idle or DockState.Hovering)
            {
                surface.Width = 120 * DockScale;
                surface.Height = 5 * DockScale;
            }
        }

        UpdateBackdropBounds();
        previews.Reposition();
    }

    private static void ApplyIconLayout(
        Button button,
        Grid content,
        AdaptiveAppIcon icon,
        DockAppearanceSettings appearance)
    {
        button.Width = content.Width = appearance.ButtonWidth;
        button.Height = content.Height = appearance.ButtonHeight;
        button.MinWidth = button.MinHeight = 0;
        button.CornerRadius = new CornerRadius(10 * appearance.LayoutScale);
        icon.Configure(appearance.IconSize, DockHoverMagnification<FrameworkElement>.HoverScale);
        icon.SetDockScale(appearance.LayoutScale);
    }

    private void StyleRunningIndicator(Border running, DockAppearanceMode mode)
    {
        var active = running.Tag is true;
        if (mode == DockAppearanceMode.Clear)
        {
            running.Height = 4.5 * DockScale;
            running.CornerRadius = new CornerRadius(2.25 * DockScale);
            running.Width = (active ? 11 : 4.5) * DockScale;
            running.Opacity = active ? 1 : .8;
            running.Margin = new Thickness(0, 0, 0, 0);
            ApplyRunningVisual(running);
            return;
        }
        running.Height = 3 * DockScale;
        running.CornerRadius = new CornerRadius(1.5 * DockScale);
        running.Width = (active ? 10 : 4) * DockScale;
        running.Opacity = active ? 1 : 0.55;
        running.Margin = new Thickness(0, 0, 0, DockScale);
        ApplyRunningVisual(running);
    }

    public void SetBottomMargin(double margin)
    {
        settingsSession.Replace(settingsSession.CreateDockBehaviorUpdate(
            margin,
            settingsSession.Current.AutoHideDelayMilliseconds,
            settingsSession.Current.PeekDelayMilliseconds));
    }

    private void ApplyBottomMargin(double margin, bool repositionNativeWindow = true)
    {
        BottomMargin = Math.Clamp(
            double.IsFinite(margin) ? margin : GlassDockSettings.DefaultBottomMargin,
            GlassDockSettings.MinimumBottomMargin,
            GlassDockSettings.MaximumBottomMargin) * DockScale;

        if (!DockPinLock)
        {
            icons.Margin = new Thickness(0, 0, 0, BottomMargin);
            if (state.State == DockState.Expanded) animation.SetBottom(BottomMargin);
            else if (state.State == DockState.Expanding) animation.AnimateBottom(BottomMargin, 180);
        }

        if (repositionNativeWindow)
            windowManager.Position(0, settingsSession.DisplayMode);
        if (state.State is DockState.Idle or DockState.Hovering) UpdatePeekInput();
        else UpdateDockWaveOutline();
        UpdateBackdropBounds();
        SetStatus(DockPinLock
            ? $"Pinned dock active · normal bottom spacing remains {BottomMargin:0} DIP."
            : $"Expanded dock bottom margin: {BottomMargin:0} DIP.");
        previews.Reposition();
    }

    private static TimeSpan MonitorTrackingInterval(DockDisplayMode mode) =>
        TimeSpan.FromMilliseconds(mode == DockDisplayMode.Pointer ? 90 : 200);

    private void ApplyDisplayMode(DockDisplayMode displayMode)
    {
        if (appliedDisplayMode == displayMode) return;
        appliedDisplayMode = displayMode;
        displayTimer.Interval = MonitorTrackingInterval(displayMode);
        windowManager.InvalidateMonitorMetrics();

        var label = displayMode switch
        {
            DockDisplayMode.Pointer => "following the pointer",
            DockDisplayMode.Foreground => "following the active window",
            DockDisplayMode.AllDisplays => "on all displays",
            _ => "on the primary display"
        };
        SetStatus($"Dock display mode: {label}.");
    }

    public void ShowSettings()
    {
        if (showSettingsOverride is not null)
        {
            showSettingsOverride();
            return;
        }

        if (closing || shutdown.IsRequested || settingsWindow.IsShutdown) return;
        var window = settingsWindow.GetOrCreate(() =>
        {
            var created = new SettingsWindow(
                settingsSession,
                settingsStore,
                shutdown,
                safeMode,
                RestoreTaskbar,
                ResumeTaskbarSuppression,
                () => RestartGlassDock(inSafeMode: false),
                () => RestartGlassDock(inSafeMode: true),
                RequestShutdown,
                badges,
                VisibleDockApplications.Take(6).Select(item => item.Application).ToArray(),
                applicationService);
            created.Closed += (_, _) => settingsWindow.Release(created);
            return created;
        });
        window.ShowCentered(WinRT.Interop.WindowNative.GetWindowHandle(this));
    }

    public void ShowControls()
    {
        if (closing || shutdown.IsRequested) return;
        if (controls is null)
        {
            controls = new DevelopmentWindow(this);
            controls.Closed += (_, _) => controls = null;
        }
        controls.Activate();
    }

    internal Action? ShowHomeOverride { get; set; }

    public void ShowHome()
    {
        if (closing || shutdown.IsRequested) return;
        if (ShowHomeOverride is { } showSharedHome) { showSharedHome(); return; }
        if (home is null)
        {
            var window = new GlassHomeWindow(settingsSession, applicationService,
                WinRT.Interop.WindowNative.GetWindowHandle(this),
                async app =>
                {
                    if (app.IsRunning || app.Windows.Count > 0)
                    {
                        var target = DockWindowClick.SelectWindow(app.Windows,
                            applicationService.CanInteractWithWindow, applicationService.IsForeground);
                        return target is not null &&
                            (applicationService.ActivateWindow(target) || await keyboard.RestoreElevatedWindowAsync(target));
                    }
                    return applicationService.LaunchOrActivate(app, WinRT.Interop.WindowNative.GetWindowHandle(this));
                });
            home = window;
            window.HomeVisibilityChanged += (_, _) =>
            {
                if (ReferenceEquals(home, window))
                    keyboard.CaptureBareWindowsKey = window.IsVisible;
            };
            window.Closed += (_, _) =>
            {
                keyboard.CaptureBareWindowsKey = false;
                if (ReferenceEquals(home, window))
                    home = null;
            };
        }

        home.Toggle();
        keyboard.CaptureBareWindowsKey = home.IsVisible;
    }
    public void ShowLab()
    {
        if (closing || shutdown.IsRequested) return;
        if (lab is null)
        {
            lab = new Window { Title = "Doky — Glass Material Laboratory", Content = new Views.GlassLabView() };
            WindowBranding.Apply(lab);
            lab.AppWindow.Resize(new global::Windows.Graphics.SizeInt32(1320, 900));
            lab.Closed += (_, _) => lab = null;
        }
        lab.Activate();
    }

    public Task StartTaskbarTestAsync(bool whileAppActive = false)
    {
        if (!ownsGlobalServices)
            return Task.CompletedTask;

        if (closing ||
            shutdown.IsRequested ||
            safeMode ||
            taskbarSuppressionPaused ||
            !settingsSession.Current.SuppressWindowsTaskbar)
        {
            return Task.CompletedTask;
        }
        if (taskbarOperation is { IsCompleted: false })
            return taskbarOperation;

        taskbarOperation = StartTaskbarTestCoreAsync(whileAppActive);
        return taskbarOperation;
    }

    private async Task StartTaskbarTestCoreAsync(bool whileAppActive)
    {
        if (startingTest || taskbarSession is { IsActive: true }) return;

        startingTest = true;
        var revision = ++taskbarRevision;
        try
        {
            if (taskbarSession is not null) await taskbarSession.DisposeAsync();
            var session = await TaskbarDevelopmentSession.StartAsync(Path.Combine(AppContext.BaseDirectory, "Recovery", "GlassDock.Watchdog.exe"), whileAppActive);
            if (closing || revision != taskbarRevision)
            {
                await session.DisposeAsync();
                return;
            }
            taskbarSession = session;
            session.Ended += (_, message) => DispatcherQueue.TryEnqueue(() =>
            {
                if (!ReferenceEquals(taskbarSession, session) || closing) return;
                heartbeat.Stop();
                SetStatus(message);
            });
            if (session.IsActive)
            {
                windowManager.Position(0, settingsSession.DisplayMode);
                heartbeat.Start();
                SetStatus(whileAppActive
                    ? "Taskbar suppressed while dock is active · Ctrl+Alt+F12 restores immediately."
                    : "Taskbar hidden · maximum 60 seconds · Ctrl+Alt+F12 restores immediately.");
            }
            else SetStatus("Taskbar test ended during initialization; recovery was requested.");
        }
        catch (Exception exception)
        {
            TaskbarRecovery.RestoreNow();
            SetStatus($"Taskbar suppression refused: {exception.Message}");
        }
        finally { startingTest = false; }
    }

    public void RestoreTaskbar()
    {
        if (!ownsGlobalServices && restoreTaskbarOverride is not null)
        {
            restoreTaskbarOverride();
            return;
        }

        if (closing || shutdown.IsRequested || taskbarRestoreOperation is { IsCompleted: false })
            return;

        taskbarSuppressionPaused = true;
        taskbarRestoreOperation = RestoreTaskbarAsync();
    }

    public void ResumeTaskbarSuppression()
    {
        if (!ownsGlobalServices && resumeTaskbarOverride is not null)
        {
            resumeTaskbarOverride();
            return;
        }

        if (closing || shutdown.IsRequested)
            return;

        if (safeMode)
        {
            SetStatus("Safe Mode keeps Windows taskbar suppression disabled.");
            return;
        }

        if (!settingsSession.Current.SuppressWindowsTaskbar)
        {
            SetStatus("Windows taskbar suppression is disabled in settings.");
            return;
        }

        taskbarSuppressionPaused = false;
        _ = StartTaskbarTestAsync(whileAppActive: true);
    }

    private void RestartGlassDock(bool inSafeMode)
    {
        if (closing || shutdown.IsRequested)
            return;

        if (prepareRestart is null)
        {
            SetStatus("Restart is unavailable in this build.");
            return;
        }

        prepareRestart(inSafeMode);
        RequestShutdown();
    }

    private async Task RestoreTaskbarAsync()
    {
        taskbarRevision++;
        heartbeat.Stop();
        var restored = TaskbarRecovery.RestoreNow();
        if (taskbarSession is { } session)
        {
            taskbarSession = null;
            await session.DisposeAsync();
        }
        if (!closing)
            SetStatus(restored ? "Windows taskbar restored." : "Restoration not verified; use the independent recovery command.");
    }

    private void SetStatus(string value) { Status = value; StatusChanged?.Invoke(this, EventArgs.Empty); }

    public void RequestShutdown()
    {
        if (requestApplicationShutdown is not null)
        {
            requestApplicationShutdown();
            return;
        }

        BeginShutdown(closeMainWindow: true);
    }

    private void OnClosed(object sender, WindowEventArgs e)
    {
        if (closing) return;
        if (unexpectedClosed is not null)
        {
            unexpectedClosed(this);
            return;
        }

        BeginShutdown(closeMainWindow: false);
    }

    internal Task ShutdownForCoordinatorAsync(bool closeMainWindow = true)
    {
        if (shutdownOperation is not null)
            return shutdownOperation;

        closing = true;
        shutdownOperation = ShutdownAsync(closeMainWindow, completeApplicationShutdown: false);
        return shutdownOperation;
    }

    internal Task CleanupAfterUnexpectedCloseAsync()
    {
        if (shutdownOperation is not null)
            return shutdownOperation;

        closing = true;
        shutdownOperation = ShutdownAsync(closeMainWindow: false, completeApplicationShutdown: false);
        return shutdownOperation;
    }

    private void BeginShutdown(bool closeMainWindow)
    {
        if (!shutdown.TryBegin()) return;
        closing = true;
        shutdownOperation = ShutdownAsync(closeMainWindow, completeApplicationShutdown: true);
    }

    private async Task ShutdownAsync(bool closeMainWindow, bool completeApplicationShutdown)
    {
        if (closeMainWindow) AppWindow.Hide();
        AbortDragLens();
        DisposeUtilities();
        liquidGlass.Dispose();
        root.ContextFlyout?.Hide();

        ClearStackDrag(); stackWindow?.Close(); stackWindow = null;
        previews.Dispose();
        badges.Changed -= BadgesChanged;
        if (ownsGlobalServices)
            badges.RefreshRequested -= BadgesRefreshRequested;
        if (ownsBadges)
            badges.Dispose();
        applications.Dispose();
        taskbarRevision++;
        state.Hide();
        heldTransition = false;
        collapseDelay?.Cancel();
        pinDockTransition?.Cancel();

        CancelPillHide();
        heartbeat.Stop();
        displayTimer.Stop();
        StopDockWaveTimer(clear: true);
        CompositionTarget.Rendering -= TickDockWave;

        settingsSession.Changed -= SettingsChanged;
        settingsWindow.BeginShutdown()?.ClosePermanently();

        var controlsToClose = controls;
        controls = null;
        controlsToClose?.Close();

        var homeToClose = home;
        home = null;
        homeToClose?.Close();

        var labToClose = lab;
        lab = null;
        labToClose?.Close();

        if (ownsGlobalServices && (taskbarSession is not null || startingTest))
            TaskbarRecovery.RestoreNow();
        animation.Dispose();
        if (ownsKeyboard)
            keyboard.Dispose();
        windowManager.Dispose();

        if (taskbarOperation is { } pendingTaskbar)
            await pendingTaskbar;

        if (taskbarRestoreOperation is { } pendingRestore)
            await pendingRestore;

        if (taskbarSession is { } session)
        {
            taskbarSession = null;
            await session.DisposeAsync();
        }

        if (closeMainWindow) Close();
        if (completeApplicationShutdown)
            shutdownCompleted();
    }
}

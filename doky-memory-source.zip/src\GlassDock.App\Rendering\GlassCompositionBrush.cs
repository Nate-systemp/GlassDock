using System.Runtime.InteropServices;
using GlassDock.Core.Materials;
using Microsoft.Graphics.Canvas.Effects;
using Microsoft.UI.Composition;
using Microsoft.UI.Xaml.Media;
using Windows.UI;
using global::Windows.UI.ViewManagement;

namespace GlassDock.App.Rendering;

internal sealed class GlassCompositionBrush : XamlCompositionBrushBase
{
    private CompositionEffectBrush? effect;
    private CompositionEffectFactory? factory;
    private CompositionBackdropBrush? backdrop;
    private GlassMaterial material = new();
    private readonly UISettings uiSettings = new();
    private Compositor? connectedCompositor;


    public string RenderingMode { get; private set; } = "Connecting native Composition";
    public event EventHandler? RenderingModeChanged;

    public GlassCompositionBrush() => FallbackColor = Color.FromArgb(255, 47, 57, 77);


    public void Connect(Compositor compositor)
    {
        connectedCompositor = compositor;
        if (CompositionBrush is not null) return;
        try
        {
            var source = new CompositionEffectSourceParameter("Backdrop");
            factory = compositor.CreateEffectFactory(GlassEffectGraph.Create(source, quality: material.BlurQuality), GlassEffectGraph.Properties);
            effect = factory.CreateBrush();
            backdrop = compositor.CreateBackdropBrush();
            effect.SetSourceParameter("Backdrop", backdrop);
            CompositionBrush = effect;
            RenderingMode = "Native Composition · live in-app backdrop";
            Apply(material, false);
        }
        catch (Exception exception) when (exception is COMException or ArgumentException)
        {
            Release();
            CompositionBrush = compositor.CreateColorBrush(FallbackColor);
            RenderingMode = $"Solid fallback · effects unavailable (0x{exception.HResult:X8})";
        }
        RenderingModeChanged?.Invoke(this, EventArgs.Empty);
    }

    public void Apply(GlassMaterial value, bool animate)
    {
        var qualityChanged = material.BlurQuality != value.BlurQuality;
        material = RefractionLayer.ForNativeBackend(value);
        if (qualityChanged && effect is not null && connectedCompositor is { } compositor)
        {
            Release();
            Connect(compositor);
        }
        if (effect is null) return;
        animate &= uiSettings.AnimationsEnabled;
        foreach (var (name, scalar) in GlassEffectGraph.Scalars(material)) Scalar(name, scalar, animate);
        effect.Properties.InsertColor("Tint.Color", GlassEffectGraph.Tint(material));
    }

    private void Scalar(string name, float value, bool animate)
    {
        if (effect is null) return;
        effect.Properties.StopAnimation(name);
        if (!animate) { effect.Properties.InsertScalar(name, value); return; }
        using var animation = effect.Compositor.CreateScalarKeyFrameAnimation();
        animation.InsertKeyFrame(1, value);
        animation.Duration = TimeSpan.FromMilliseconds(180);
        effect.Properties.StartAnimation(name, animation);
    }

    protected override void OnDisconnected() => Release();

    private void Release()
    {
        var brush = CompositionBrush;
        CompositionBrush = null;
        brush?.Dispose();
        effect = null;
        backdrop?.Dispose();
        backdrop = null;
        factory?.Dispose();
        factory = null;
    }
}

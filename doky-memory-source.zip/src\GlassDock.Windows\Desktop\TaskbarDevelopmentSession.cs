using System.Diagnostics;

namespace GlassDock.Windows.Desktop;

public sealed class TaskbarDevelopmentSession : IAsyncDisposable
{
    private readonly Process process;
    private readonly SemaphoreSlim writerLock = new(1);
    private Task? monitor;
    private bool stopping;
    private int renewalRequested;
    public bool IsActive { get; private set; }
    public event EventHandler<string>? Ended;

    private TaskbarDevelopmentSession(Process process) => this.process = process;

    public static async Task<TaskbarDevelopmentSession> StartAsync(string helperPath, bool whileAppActive = false)
    {
        if (!File.Exists(helperPath)) throw new FileNotFoundException("Build the solution to deploy the recovery helper.", helperPath);
        using var parent = Process.GetCurrentProcess();
        var info = new ProcessStartInfo(helperPath)
        {
            UseShellExecute = false, CreateNoWindow = true,
            RedirectStandardInput = true, RedirectStandardOutput = true
        };
        info.ArgumentList.Add(whileAppActive ? "--watch-active" : "--watch");
        info.ArgumentList.Add(parent.Id.ToString(System.Globalization.CultureInfo.InvariantCulture));
        info.ArgumentList.Add(parent.StartTime.ToUniversalTime().Ticks.ToString(System.Globalization.CultureInfo.InvariantCulture));
        var child = Process.Start(info) ?? throw new InvalidOperationException("Cannot start recovery helper.");
        var session = new TaskbarDevelopmentSession(child);
        try
        {
            var ready = await child.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(5));
            if (ready != "READY") throw new InvalidOperationException(ready ?? "Recovery helper exited before readiness.");
            await session.SendAsync("HIDE");
            var hidden = await child.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(5));
            if (hidden != "HIDDEN") throw new InvalidOperationException(hidden ?? "Taskbar test was not started.");
            session.IsActive = true;
            session.monitor = session.MonitorAsync();
            return session;
        }
        catch
        {
            try
            {
                child.StandardInput.Close();
                await child.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(7));
            }
            finally
            {
                TaskbarRecovery.RestoreNow();
                child.Dispose();
            }
            throw;
        }
    }

    public async Task HeartbeatAsync()
    {
        if (!IsActive || stopping) return;
        try { await SendAsync(Interlocked.Exchange(ref renewalRequested, 0) == 1 ? "HIDE" : "PING"); }
        catch (Exception ex) when (ex is IOException or InvalidOperationException)
        {
            TaskbarRecovery.RestoreNow();
            IsActive = false;
        }
    }

    private async Task SendAsync(string command)
    {
        await writerLock.WaitAsync();
        try
        {
            await process.StandardInput.WriteLineAsync(command);
            await process.StandardInput.FlushAsync();
        }
        finally { writerLock.Release(); }
    }

    private async Task MonitorAsync()
    {
        var status = "Recovery helper ended.";
        try
        {
            while (await process.StandardOutput.ReadLineAsync() is { } line)
            {
                if (line == "WAITING: heartbeat expired.") Interlocked.Exchange(ref renewalRequested, 1);
                status = line;
            }
            await process.WaitForExitAsync();
        }
        catch (IOException exception)
        {
            status = $"Recovery connection failed: {exception.Message}";
        }
        finally
        {
            IsActive = false;
            if (!status.StartsWith("RESTORED", StringComparison.Ordinal))
                status = TaskbarRecovery.RestoreNow()
                    ? "RESTORED: recovery helper ended unexpectedly."
                    : "RESTORE FAILED: run GlassDock.Watchdog --restore.";
            Ended?.Invoke(this, status);
        }
    }

    public async ValueTask DisposeAsync()
    {
        if (stopping) return;
        stopping = true;
        try
        {
            if (!process.HasExited) await SendAsync("RESTORE");
            if (monitor is not null) await monitor.WaitAsync(TimeSpan.FromSeconds(7));
        }
        catch (Exception ex) when (ex is IOException or InvalidOperationException or TimeoutException)
        {
            TaskbarRecovery.RestoreNow();
        }
        finally
        {
            IsActive = false;
            process.Dispose();
        }
    }
}

using GlassDock.Core.Desktop;
using GlassDock.Windows.Applications;
using GlassDock.Windows.Interop;
using System.Diagnostics;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Threading.Channels;

namespace GlassDock.Windows.Desktop;

public static class WindowsInputHelperHost
{
    public static int Run()
    {
        using var identity = WindowsIdentity.GetCurrent();
        if (!new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator)) return 0;
        using var singleInstance = WindowsInputHelperProtocol.AcquireSingleInstance(Process.GetCurrentProcess().SessionId, out var created);
        if (!created) return 0;
        try
        {
            using var pipe = new NamedPipeClientStream(".", WindowsInputHelperProtocol.GetPipeName(),
                PipeDirection.InOut, PipeOptions.Asynchronous);
            pipe.Connect(3000);
            RunConnected(pipe);
        }
        catch (Exception e) when (e is IOException or TimeoutException or UnauthorizedAccessException)
        { Debug.WriteLine($"Doky input helper unavailable: {e.Message}"); }
        return 0;
    }

    private static void RunConnected(NamedPipeClientStream pipe)
    {
        using var reader = new StreamReader(pipe, leaveOpen: true);
        var writer = new StreamWriter(pipe, leaveOpen: true) { AutoFlush = true };
        try
        {
            writer.WriteLine("HELLO2");
            var initial = reader.ReadLine();
            if (initial is null || reader.ReadLine() != "GO") return;

            using var disconnected = new ManualResetEvent(false);
            using var lifetime = new CancellationTokenSource();
            var events = Channel.CreateUnbounded<(InputSignal Signal, int Kind)>(new UnboundedChannelOptions
            { SingleReader = true, SingleWriter = true });
            var captureVolume = 0;
            using var hook = new WindowsKeyHook((launcher, revision) =>
                events.Writer.TryWrite((new InputSignal(launcher, revision, Environment.TickCount64), 0)),
                revision => events.Writer.TryWrite((new InputSignal(false, revision, Environment.TickCount64), 1)),
                revision => events.Writer.TryWrite((new InputSignal(false, revision, Environment.TickCount64), 2)),
                (index, revision) => events.Writer.TryWrite((new InputSignal(false, revision, Environment.TickCount64), 10 + index)),
                key => Volatile.Read(ref captureVolume) != 0 && events.Writer.TryWrite(
                    (new InputSignal(false, 0, Environment.TickCount64), 20 + (int)key - 0xAD)));
            ApplyState(initial, hook);
            writer.WriteLine("READY");
            writer.WriteLine("CAPS|RESTORE1");
            writer.WriteLine("CAPS|RECOVER1");
            writer.WriteLine("CAPS|SNIP1");
            writer.WriteLine("CAPS|VOLUME1");
            var hookThread = GetCurrentThreadId();
            NativeMethods.PeekMessage(out _, 0, 0, 0, 0);
            TaskCompletionSource? recovery = null;
            using var writeLock = new SemaphoreSlim(1, 1);
            var readTask = ReadStateAsync();
            var writeTask = WriteEventsAsync();
            var handles = Marshal.AllocHGlobal(IntPtr.Size);
            Marshal.WriteIntPtr(handles, disconnected.SafeWaitHandle.DangerousGetHandle());
            try
            {
                while (NativeMethods.MsgWaitForMultipleObjectsEx(1, handles, uint.MaxValue, 0x04FF, 0x0004) == 1)
                    while (NativeMethods.PeekMessage(out var message, 0, 0, 0, 1))
                    {
                        if (message.MessageId == 0x8051)
                        {
                            try { hook.RecoverAfterResume(); Volatile.Read(ref recovery)?.TrySetResult(); }
                            catch (Exception error) { Volatile.Read(ref recovery)?.TrySetException(error); }
                            continue;
                        }
                        NativeMethods.TranslateMessage(ref message);
                        NativeMethods.DispatchMessage(ref message);
                    }
            }
            finally
            {
                hook.Dispose();
                lifetime.Cancel();
                events.Writer.TryComplete();
                pipe.Dispose();
                Marshal.FreeHGlobal(handles);
                Task.WhenAll(readTask, writeTask).GetAwaiter().GetResult();
            }

            async Task ReadStateAsync()
            {
                try
                {
                    while (await reader.ReadLineAsync(lifetime.Token) is { } line)
                    {
                        if (line is "VOLUME|0" or "VOLUME|1")
                            Volatile.Write(ref captureVolume, line == "VOLUME|1" ? 1 : 0);
                        else if (WindowsInputHelperProtocol.ReadRecovery(line) is { } recoveryRequest)
                        {
                            if (recoveryRequest.State is { } recoveryState)
                                ApplyState(recoveryState, hook);
                            var pending = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
                            Volatile.Write(ref recovery, pending);
                            if (!PostThreadMessageW(hookThread, 0x8051, 0, 0)) throw new IOException("Cannot dispatch hook recovery.");
                            await pending.Task.WaitAsync(TimeSpan.FromSeconds(3), lifetime.Token);
                            await WriteLineAsync("RECOVERED|" + recoveryRequest.Id);
                        }
                        else if (line.StartsWith("RECOVER|", StringComparison.Ordinal)) continue;
                        else if (WindowsInputHelperProtocol.ReadRestore(line, Environment.TickCount64) is { } request)
                        {
                            var restored = RestoreWindow(request);
                            await WriteLineAsync($"RESTORED|{request.Id}|{(restored ? 1 : 0)}");
                        }
                        else ApplyState(line, hook);
                    }
                }
                catch (Exception e) when (e is IOException or OperationCanceledException or ObjectDisposedException or TimeoutException or InvalidOperationException)
                { Debug.WriteLine($"Doky helper connection/recovery ended: {e}"); }
                finally { disconnected.Set(); }
            }
            async Task WriteEventsAsync()
            {
                long sequence = 0;
                try
                {
                    await foreach (var value in events.Reader.ReadAllAsync(lifetime.Token))
                    {
                        if (Environment.TickCount64 - value.Signal.Timestamp > 500) continue;
                        var signal = value.Signal;
                        await WriteLineAsync(value.Kind switch
                        {
                            1 => $"SNIP|{++sequence}|{signal.Timestamp}|{signal.Revision}",
                            2 => $"SNIPEND|{++sequence}|{signal.Timestamp}|{signal.Revision}",
                            >= 10 and <= 19 => $"SHORTCUT|{++sequence}|{signal.Timestamp}|{signal.Revision}|{value.Kind - 10}",
                            >= 20 and <= 22 => $"VOLUME|{++sequence}|{signal.Timestamp}|{value.Kind - 20 + 0xAD}",
                            _ => $"EVENT|{++sequence}|{signal.Timestamp}|{signal.Revision}|{(signal.Launcher ? "LAUNCHER" : "HOME")}"
                        });
                    }
                }
                catch (Exception e) when (e is IOException or OperationCanceledException or ObjectDisposedException) { }
                finally { disconnected.Set(); }
            }
            async Task WriteLineAsync(string line)
            {
                await writeLock.WaitAsync(lifetime.Token);
                try { await writer.WriteLineAsync(line.AsMemory(), lifetime.Token); }
                finally { writeLock.Release(); }
            }
        }
        finally
        {
            try { writer.Dispose(); }
            catch (Exception e) when (e is IOException or ObjectDisposedException)
            {
            }
        }
    }

    private static void ApplyState(string line, WindowsKeyHook hook)
    {
        var parts = line.Split('|');
        if (parts.Length != 4 || parts[0] != "STATE" || !uint.TryParse(parts[3], out var revision)) return;
        hook.UpdateState(parts[1] == "1", parts[2] == "1", revision);
    }

    [DllImport("kernel32.dll")] private static extern uint GetCurrentThreadId();
    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool PostThreadMessageW(uint thread, uint message, nuint wParam, nint lParam);

    private static bool RestoreWindow(WindowsInputHelperProtocol.RestoreRequest request)
    {
        try
        {
            using var process = Process.GetProcessById(request.Window.ProcessId);
            if (process.SessionId != Process.GetCurrentProcess().SessionId ||
                !WindowsApplicationService.IsEligible(request.Window)) return false;
            var window = (nint)request.Window.Handle;
            return (!ApplicationNative.IsIconic(window) || ApplicationNative.ShowWindowAsync(window, 9)) &&
                ApplicationNative.SetForegroundWindow(window);
        }
        catch (Exception e) when (e is ArgumentException or InvalidOperationException or System.ComponentModel.Win32Exception)
        { return false; }
    }
}

using System.ComponentModel;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using GlassDock.Core.Applications;
using GlassDock.Windows.Interop;

namespace GlassDock.Windows.Applications;

public sealed record RecoverableDockPin(string Id, string Name, string Target, bool Hidden);

public sealed class WindowsApplicationService : IApplicationService
{
    private readonly AutoResetEvent refresh = new(false);
    private readonly ConcurrentDictionary<nint, long> activationTimes = new();
    private readonly ConcurrentDictionary<string, (DockApplication Application, nint Owner)> pendingActivations = new(StringComparer.Ordinal);
    private readonly WindowsApplicationLauncher launcher = new();
    private readonly ShellApplicationIdentityResolver identityResolver = new();
    private readonly DockPinStore pinStore = new();
    private readonly WindowsApplicationIconService externalIconService =
        new(targetIconSize: 64, cacheCapacity: 64, allowLargerIcons: false);
    private readonly object externalIconGate = new();
    private readonly NativeMethods.WinEventProc callback;
    private readonly List<nint> hooks = [];
    private Thread? worker;
    private volatile bool stopping;
    private IReadOnlyList<PinnedApplication> currentPins = Array.Empty<PinnedApplication>();
    private int pinRevision;
    private IReadOnlyList<DockApplication> currentApplications = Array.Empty<DockApplication>();
    private sealed record CachedWindowMetadata(
        uint HostProcessId,
        uint ResolvedProcessId,
        string Path,
        int SessionId,
        long StartTicks,
        string Name,
        string? AppId,
        ApplicationIdentity Identity);

    private readonly ConcurrentDictionary<nint, byte> trackedWindows = new();
    private readonly Dictionary<nint, CachedWindowMetadata> windowMetadataCache = new();
    private readonly int currentSessionId = Process.GetCurrentProcess().SessionId;
    private ApplicationSnapshot? lastPublishedSnapshot;
    public event EventHandler<ApplicationSnapshot>? SnapshotChanged;

    public WindowsApplicationService() => callback = (_, eventId, window, objectId, childId, _, _) =>
    {
        if (eventId == 3)
        {
            activationTimes[window] = Stopwatch.GetTimestamp();
            RequestRefresh();
            return;
        }

        if (eventId == 0x0020)
        {
            RequestRefresh();
            return;
        }

        if (window == 0 || objectId != 0 || childId != 0)
            return;

        if (eventId == 0x8001)
            activationTimes.TryRemove(window, out _);

        var isTracked = trackedWindows.ContainsKey(window);
        if (eventId is 0x8001 or 0x8003)
        {
            if (isTracked)
                RequestRefresh();
            return;
        }

        if (eventId == 0x800C)
        {
            if (isTracked && ApplicationNative.IsWindowVisible(window))
                RequestRefresh();
            return;
        }

        if (eventId is 0x8000 or 0x8002)
        {
            if (!isTracked)
            {
                if (!ApplicationNative.IsWindowVisible(window))
                    return;
                var style = ApplicationNative.GetWindowLongPtr(window, -16).ToInt64();
                if ((style & 0x40000000L) != 0)
                    return;
            }
            RequestRefresh();
            return;
        }

        RequestRefresh();
    };

    public void Start()
    {
        if (worker is not null || stopping) return;
        foreach (var (first, last) in new (uint, uint)[] { (3, 3), (0x0020, 0x0020), (0x8000, 0x8003), (0x800C, 0x800C), (0x8017, 0x8018) })
        {
            var hook = NativeMethods.SetWinEventHook(first, last, 0, callback, 0, 0, 2);
            if (hook != 0) hooks.Add(hook);
        }
        worker = new Thread(Reconcile) { IsBackground = true, Name = "GlassDock application discovery" };
        worker.SetApartmentState(ApartmentState.STA);
        worker.Start();
    }

    public void RequestRefresh()
    {
        if (stopping) return;
        try { refresh.Set(); } catch (ObjectDisposedException) { }
    }

    private void Reconcile()
    {
        var icons = new WindowsApplicationIconService();
        IReadOnlyList<PinnedApplication> pins = [];
        string? pinWarning = null;
        var lastPins = DateTime.MinValue;
        var lastPinRevision = -1;
        try
        {
            while (!stopping)
            {
                try
                {
                    var revision = Volatile.Read(ref pinRevision);
                    if (revision != lastPinRevision ||
                        DateTime.UtcNow - lastPins > TimeSpan.FromSeconds(3))
                    {
                        try
                        {
                            pins = pinStore.Apply(ShellApplicationMetadata.ReadPinned(icons), icons);
                            Volatile.Write(ref currentPins, pins);
                            lastPinRevision = revision;
                            pinWarning = null;
                        }
                        catch (Exception error) when (error is COMException or InvalidCastException or IOException or UnauthorizedAccessException)
                        {
                            pinWarning = $"Pinned taskbar enumeration unavailable (0x{error.HResult:X8}); preserving the last known pins.";
                        }
                        lastPins = DateTime.UtcNow;
                    }
                    var activationRequests = pendingActivations.ToArray();
                    var windows = ReadWindows(icons);
                    foreach (var request in activationRequests)
                    {
                        if (stopping) break;
                        try { LaunchOrActivateFromSnapshot(request.Value.Application, windows, request.Value.Owner); }
                        finally { pendingActivations.TryRemove(request.Key, out _); }
                    }
                    var visibleWindows = VirtualDesktopPolicy.Filter(windows, WindowsVirtualDesktopQuery.ShowAllWindows());
                    var applications = pinStore.ApplyOrder(DockApplicationCollection.Combine(pins, visibleWindows));
                    Volatile.Write(ref currentApplications, applications);
                    icons.Retain(pins.Select(pin => pin.Identity.Key).Concat(windows.Select(window => window.Identity.Key)));
                    if (!stopping)
                    {
                        var nextSnapshot = new ApplicationSnapshot(pinStore.ApplyStacks(applications), pinWarning);
                        if (!SnapshotEquals(lastPublishedSnapshot, nextSnapshot))
                        {
                            lastPublishedSnapshot = nextSnapshot;
                            SnapshotChanged?.Invoke(this, nextSnapshot);
                        }
                    }
                }
                catch (Exception error) when (error is COMException or Win32Exception or InvalidOperationException)
                {
                    Debug.WriteLine($"Application reconciliation deferred: {error.Message}");
                }
                refresh.WaitOne(TimeSpan.FromSeconds(3));
                if (!stopping) Thread.Sleep(150);
            }
        }
        finally { refresh.Dispose(); }
    }

    private static bool SnapshotEquals(ApplicationSnapshot? previous, ApplicationSnapshot next)
    {
        if (previous is null)
            return false;
        if (!string.Equals(previous.Warning, next.Warning, StringComparison.Ordinal))
            return false;
        var prevApps = previous.Applications;
        var nextApps = next.Applications;
        if (prevApps.Count != nextApps.Count)
            return false;
        for (var i = 0; i < prevApps.Count; i++)
        {
            if (!DockApplicationEquals(prevApps[i], nextApps[i]))
                return false;
        }
        return true;
    }

    private static bool DockApplicationEquals(DockApplication a, DockApplication b)
    {
        if (!string.Equals(a.Id, b.Id, StringComparison.Ordinal) ||
            a.Identity != b.Identity ||
            !string.Equals(a.Name, b.Name, StringComparison.Ordinal) ||
            !string.Equals(a.LaunchTarget, b.LaunchTarget, StringComparison.Ordinal) ||
            a.IsPinned != b.IsPinned ||
            a.PinAvailability != b.PinAvailability ||
            a.Stack != b.Stack ||
            !ReferenceEquals(a.Icon, b.Icon) ||
            a.Windows.Count != b.Windows.Count ||
            a.StackApps.Count != b.StackApps.Count)
        {
            return false;
        }

        for (var j = 0; j < a.Windows.Count; j++)
        {
            if (a.Windows[j] != b.Windows[j])
                return false;
        }

        for (var j = 0; j < a.StackApps.Count; j++)
        {
            if (!DockApplicationEquals(a.StackApps[j], b.StackApps[j]))
                return false;
        }

        return true;
    }

    private IReadOnlyList<ApplicationWindow> ReadWindows(WindowsApplicationIconService? icons)
    {
        using var desktops = new WindowsVirtualDesktopQuery();
        var result = new List<ApplicationWindow>();
        var activeHandles = new HashSet<nint>();
        var sessionId = currentSessionId;
        var foreground = ApplicationNative.GetForegroundWindow();
        ApplicationNative.EnumWindows((window, _) =>
        {
            try
            {
                if (!ApplicationNative.IsWindowVisible(window)) return true;
                if (!HasPreviewBounds(window)) return true;
                var style = ApplicationNative.GetWindowLongPtr(window, -20).ToInt64();
                var appWindow = (style & 0x40000) != 0;
                if (!appWindow && ((style & (0x80 | 0x08000000)) != 0 || ApplicationNative.GetWindow(window, 4) != 0)) return true;
                if (ApplicationNative.DwmGetWindowAttribute(window, 14, out var cloaked, sizeof(int)) < 0) cloaked = 0;
                var onCurrentDesktop = desktops.IsCurrent(window);
                if (!VirtualDesktopPolicy.Track(onCurrentDesktop, cloaked)) return true;
                var title = new StringBuilder(1024);
                if (ApplicationNative.GetWindowText(window, title, title.Capacity) == 0) return true;
                var className = new StringBuilder(256);
                ApplicationNative.GetClassName(window, className, className.Capacity);
                var classNameText = className.ToString();
                if (classNameText is "Progman" or "WorkerW" or "Shell_TrayWnd" or "Shell_SecondaryTrayWnd") return true;
                ApplicationNative.GetWindowThreadProcessId(window, out var pid);
                if (pid == Environment.ProcessId) return true;

                if (!windowMetadataCache.TryGetValue(window, out var metadata) || metadata.HostProcessId != pid)
                {
                    var resolvedPid = pid;
                    var path = ProcessPath(resolvedPid);
                    if (Path.GetFileName(path).Equals("ApplicationFrameHost.exe", StringComparison.OrdinalIgnoreCase))
                    {
                        var hostPid = resolvedPid;
                        ApplicationNative.EnumChildWindows(window, (child, _) =>
                        {
                            ApplicationNative.GetWindowThreadProcessId(child, out var childPid);
                            if (childPid != hostPid && ApplicationNative.IsWindowVisible(child)) { resolvedPid = childPid; return false; }
                            return true;
                        }, 0);
                        path = ProcessPath(resolvedPid);
                    }
                    if (string.IsNullOrEmpty(path) || Path.GetFileName(path).ToUpperInvariant() is
                        "APPLICATIONFRAMEHOST.EXE" or "STARTMENUEXPERIENCEHOST.EXE" or "SHELLEXPERIENCEHOST.EXE" or
                        "SEARCHHOST.EXE" or "TEXTINPUTHOST.EXE" or "GLASSDOCK.APP.EXE" or "GLASSDOCK.WATCHDOG.EXE") return true;
                    using var process = Process.GetProcessById((int)resolvedPid);
                    var procSessionId = process.SessionId;
                    var startTicks = process.StartTime.ToUniversalTime().Ticks;
                    string? appId = null;
                    var iid = typeof(ApplicationNative.IPropertyStore).GUID;
                    if (ApplicationNative.SHGetPropertyStoreForWindow(window, in iid, out var properties) >= 0)
                    {
                        try { appId = ShellApplicationMetadata.Property(properties, "System.AppUserModel.ID"); }
                        finally { Marshal.ReleaseComObject(properties); }
                    }
                    using (var handle = ApplicationNative.OpenProcess(0x1000, false, resolvedPid))
                    {
                        uint length = 0;
                        if (string.IsNullOrWhiteSpace(appId) && !handle.IsInvalid &&
                            ApplicationNative.GetApplicationUserModelId(handle.DangerousGetHandle(), ref length, null) == 122 &&
                            length < 32768)
                        {
                            var text = new StringBuilder((int)length);
                            if (ApplicationNative.GetApplicationUserModelId(handle.DangerousGetHandle(), ref length, text) == 0 &&
                                !string.IsNullOrWhiteSpace(text.ToString()))
                                appId = text.ToString();
                        }
                    }
                    if (string.IsNullOrWhiteSpace(appId) && classNameText == "CabinetWClass" &&
                        Path.GetFileName(path).Equals("explorer.exe", StringComparison.OrdinalIgnoreCase))
                        appId = "Microsoft.Windows.Explorer";

                    if (string.IsNullOrWhiteSpace(appId))
                        appId = identityResolver.Resolve(path);

                    var identity = new ApplicationIdentity(appId, path);
                    var name = FileVersionInfo.GetVersionInfo(path).FileDescription;
                    if (string.IsNullOrWhiteSpace(name)) name = Path.GetFileNameWithoutExtension(path);
                    metadata = new CachedWindowMetadata(pid, resolvedPid, path, procSessionId, startTicks, name, appId, identity);
                    if (icons is not null)
                        windowMetadataCache[window] = metadata;
                }

                if (metadata.SessionId != sessionId) return true;
                activeHandles.Add(window);
                trackedWindows[window] = 1;
                result.Add(new(metadata.Identity, metadata.Name, window, (int)metadata.ResolvedProcessId, metadata.StartTicks, window == foreground,
                    icons?.FromWindow(metadata.Identity.Key, window, metadata.Path, metadata.AppId), title.ToString(), ApplicationNative.IsIconic(window),
                    activationTimes.GetValueOrDefault(window))
                { IsOnCurrentDesktop = VirtualDesktopPolicy.IsCurrent(onCurrentDesktop, cloaked) });
            }
            catch (Exception error) when (error is Win32Exception or InvalidOperationException or ArgumentException or IOException or COMException)
            { Debug.WriteLine($"Skipping unavailable application window: {error.HResult:X8}"); }
            return true;
        }, 0);

        if (icons is not null)
        {
            foreach (var key in windowMetadataCache.Keys.Where(handle => !activeHandles.Contains(handle)).ToArray())
                windowMetadataCache.Remove(key);
            foreach (var key in trackedWindows.Keys.Where(handle => !activeHandles.Contains(handle)).ToArray())
                trackedWindows.TryRemove(key, out _);
        }

        return result;
    }

    private static string ProcessPath(uint pid)
    {
        using var process = ApplicationNative.OpenProcess(0x1000, false, pid);
        if (process.IsInvalid) return "";
        uint length = 32768;
        var path = new StringBuilder((int)length);
        return ApplicationNative.QueryFullProcessImageName(process, 0, path, ref length) ? path.ToString() : "";
    }

    public bool LaunchOrActivate(DockApplication application, nint owner = 0)
    {
        if (stopping || worker is null) return false;
        pendingActivations.TryAdd(application.Id, (application, owner));
        RequestRefresh();
        return true;
    }

    private bool LaunchOrActivateFromSnapshot(DockApplication application, IReadOnlyList<ApplicationWindow> windows, nint owner)
    {
        var current = DockApplicationCollection.Combine(Volatile.Read(ref currentPins), windows)
            .FirstOrDefault(item => item.Id == application.Id);
        if (current is not null) application = current;
        else if (application.IsPinned) { RequestRefresh(); return false; }
        var target = DockWindowClick.SelectWindow(application.Windows, IsEligible,
            window => ApplicationNative.GetForegroundWindow() == (nint)window.Handle);
        if (target is not null)
            return ActivateWindow(target);
        if (application.Windows.Count > 0) { RequestRefresh(); return false; }
        if (!application.IsPinned) return false;
        var launched = launcher.Launch(application, owner);
        RequestRefresh();
        return launched;
    }

    public async Task<bool> LaunchAsync(DockApplication application, nint owner)
    {
        var launched = await launcher.LaunchAsync(application, owner).ConfigureAwait(false);
        RequestRefresh();
        return launched;
    }

    public bool SetPinned(DockApplication application, bool pinned)
    {
        var saved = pinStore.Set(application, pinned);
        if (saved)
            Interlocked.Increment(ref pinRevision);
        RequestRefresh();
        return saved;
    }


    public ApplicationIcon? GetIconForExternalTarget(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
            return null;

        try
        {
            lock (externalIconGate)
            {
                return externalIconService.FromShell(
                    "tray:" + path.ToUpperInvariant(),
                    path);
            }
        }
        catch (Exception error) when (
            error is COMException or
            IOException or
            UnauthorizedAccessException or
            ArgumentException or
            InvalidOperationException)
        {
            return null;
        }
    }

    public IReadOnlyList<RecoverableDockPin> GetRecoverablePins() => pinStore.GetRecoverablePins();

    public bool SetMissingPinVisible(string id, bool visible)
    {
        var saved = pinStore.SetMissingPinVisible(id, visible);
        if (saved) Interlocked.Increment(ref pinRevision);
        if (saved) RequestRefresh();
        return saved;
    }

    public bool RemoveRecoverablePin(string id)
    {
        var saved = pinStore.RemoveRecoverablePin(id);
        if (saved) Interlocked.Increment(ref pinRevision);
        if (saved) RequestRefresh();
        return saved;
    }

    public bool PinExternalTarget(string path)
    {
        var saved = pinStore.AddExternalTarget(path);

        if (saved)
            Interlocked.Increment(ref pinRevision);

        RequestRefresh();
        return saved;
    }

    public bool MergeStack(string source, string target) => StackChanged(pinStore.MergeStack(source, target, Volatile.Read(ref currentApplications)));
    public bool RenameStack(string id, string name) => StackChanged(pinStore.RenameStack(id, name));
    public bool ReorderStack(string id, IReadOnlyList<string> order) => StackChanged(pinStore.ReorderStack(id, order));
    public bool ExtractStack(string id, string? appId = null, string? beforeId = null) => StackChanged(pinStore.ExtractStack(id, appId, beforeId));
    private bool StackChanged(bool saved)
    {
        if (saved) Interlocked.Increment(ref pinRevision);
        RequestRefresh();
        return saved;
    }
    public bool ReorderApplications(IReadOnlyList<string> orderedIds)
    {
        var ids = pinStore.ApplyStacks(Volatile.Read(ref currentApplications)).Select(app => app.Id).ToArray();
        var mergedOrder = MergeRequestedOrder(ids, orderedIds);
        if (mergedOrder is null || !pinStore.Reorder(ids, mergedOrder))
            return false;

        Interlocked.Increment(ref pinRevision);
        RequestRefresh();
        return true;
    }

    internal static IReadOnlyList<string>? MergeRequestedOrder(
        IReadOnlyList<string> currentIds,
        IReadOnlyList<string> orderedIds)
    {
        if (currentIds.Count == 0 || orderedIds.Count == 0)
            return null;

        var currentSet = currentIds.ToHashSet(StringComparer.Ordinal);
        var requested = new List<string>(orderedIds.Count);
        var requestedSet = new HashSet<string>(StringComparer.Ordinal);

        foreach (var id in orderedIds)
        {
            if (string.IsNullOrWhiteSpace(id) ||
                !currentSet.Contains(id) ||
                !requestedSet.Add(id))
            {
                return null;
            }

            requested.Add(id);
        }

        var queue = new Queue<string>(requested);
        var merged = new string[currentIds.Count];

        for (var index = 0; index < currentIds.Count; index++)
        {
            var currentId = currentIds[index];
            merged[index] = requestedSet.Contains(currentId)
                ? queue.Dequeue()
                : currentId;
        }

        return queue.Count == 0 ? merged : null;
    }

    public async Task<bool> RunAsAdministratorAsync(DockApplication application, nint owner)
    {
        var launched = await launcher.RunAsAdministratorAsync(application, owner).ConfigureAwait(false);
        if (launched) RequestRefresh();
        return launched;
    }

    public bool OpenFileLocation(DockApplication application) => launcher.OpenFileLocation(application);

    internal static bool HasPreviewBounds(nint window) => ApplicationNative.IsIconic(window) ||
        (NativeMethods.GetWindowRect(window, out var bounds) && bounds.Right > bounds.Left && bounds.Bottom > bounds.Top);

    internal static bool IsEligible(ApplicationWindow existing)
    {
        var window = (nint)existing.Handle;
        if (!ApplicationNative.IsWindow(window) || !ApplicationNative.IsWindowVisible(window)) return false;
        try
        {
            using var process = Process.GetProcessById(existing.ProcessId);
            if (process.StartTime.ToUniversalTime().Ticks != existing.ProcessStartTicks) return false;
            ApplicationNative.GetWindowThreadProcessId(window, out var owner);
            if (owner != existing.ProcessId && !Path.GetFileName(ProcessPath(owner)).Equals("ApplicationFrameHost.exe", StringComparison.OrdinalIgnoreCase)) return false;
            return ApplicationNative.DwmGetWindowAttribute(window, 14, out var cloaked, sizeof(int)) < 0 || cloaked == 0;
        }
        catch (Exception error) when (error is ArgumentException or InvalidOperationException or Win32Exception) { return false; }
    }

    public bool ActivateWindow(ApplicationWindow existing)
    {
        if (!IsEligible(existing)) { RequestRefresh(); return false; }
        var window = (nint)existing.Handle;
        if (ApplicationNative.IsIconic(window))
        {
            if (!ApplicationNative.ShowWindowAsync(window, 9)) { RequestRefresh(); return false; }
        }
        var focused = ApplicationNative.SetForegroundWindow(window);
        RequestRefresh();
        return focused;
    }

    public bool IsForeground(ApplicationWindow window) =>
        IsEligible(window) && ApplicationNative.GetForegroundWindow() == (nint)window.Handle;

    public bool CanInteractWithWindow(ApplicationWindow window) => IsEligible(window);

    public bool IsMinimized(ApplicationWindow window) =>
        IsEligible(window) && ApplicationNative.IsIconic((nint)window.Handle);

    public bool MinimizeWindow(ApplicationWindow window)
    {
        if (!IsEligible(window)) { RequestRefresh(); return false; }
        var accepted = ApplicationNative.ShowWindowAsync((nint)window.Handle, 6);
        RequestRefresh();
        return accepted;
    }

    public bool CloseWindow(ApplicationWindow existing)
    {
        if (!IsEligible(existing)) { RequestRefresh(); return false; }
        var sent = NativeMethods.PostMessageW((nint)existing.Handle, 0x0010, 0, 0);
        RequestRefresh();
        return sent;
    }
    public void Dispose()
    {
        if (stopping) return;
        stopping = true;
        pendingActivations.Clear();
        foreach (var hook in hooks) NativeMethods.UnhookWinEvent(hook);
        hooks.Clear();
        refresh.Set();
        if (worker is null) refresh.Dispose();
        GC.KeepAlive(callback);
    }
}

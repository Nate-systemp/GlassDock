using GlassDock.Core.Applications;
using GlassDock.Core.Settings;
using GlassDock.Core.Desktop;
using GlassDock.Windows.Settings;
using GlassDock.Windows.Applications;
using GlassDock.Windows.Desktop;
using Microsoft.UI;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using GlassDock.App.Updates;

namespace GlassDock.App.Desktop;

public sealed partial class SettingsWindow : Window
{
    private readonly GlassDockSettingsSession settingsSession;
    private readonly GlassDockSettingsStore settingsStore;
    private readonly ApplicationShutdownState shutdown;
    private readonly WindowsStartupService startupService = new();
    private readonly BadgeCoordinator badges;
    private readonly WindowsApplicationService applicationService;
    private readonly IReadOnlyList<DockApplication> previewApplications;
    private readonly bool safeMode;
    private readonly Action restoreTaskbar;
    private readonly Action resumeTaskbar;
    private readonly Action restartGlassDock;
    private readonly Action restartSafeMode;
    private readonly Action exitGlassDock;
    private bool saveInProgress;
    private bool saving
    {
        get => saveInProgress;
        set { saveInProgress = value; if (PageScroll is not null) PageScroll.IsEnabled = !value; }
    }
    private bool closed;
    private bool permanentlyClosing;
    private bool populating;
    private ManualUpdateService? updates;
    private bool updateBusy;
    private readonly CancellationTokenSource updateLifetime;

    public SettingsWindow(
        GlassDockSettingsSession settingsSession,
        GlassDockSettingsStore settingsStore,
        ApplicationShutdownState shutdown,
        bool safeMode,
        Action restoreTaskbar,
        Action resumeTaskbar,
        Action restartGlassDock,
        Action restartSafeMode,
        Action exitGlassDock,
        BadgeCoordinator badges,
        IReadOnlyList<DockApplication> previewApplications,
        WindowsApplicationService applicationService)
    {
        this.settingsSession = settingsSession;
        this.settingsStore = settingsStore;
        this.shutdown = shutdown;
        this.safeMode = safeMode;
        this.restoreTaskbar = restoreTaskbar;
        this.resumeTaskbar = resumeTaskbar;
        this.restartGlassDock = restartGlassDock;
        this.restartSafeMode = restartSafeMode;
        this.exitGlassDock = exitGlassDock;
        this.badges = badges;
        this.applicationService = applicationService;
        this.previewApplications = previewApplications;
        updateLifetime = CancellationTokenSource.CreateLinkedTokenSource(shutdown.CancellationToken);

        InitializeComponent();
        ConfigureNumberFormatting();
        Title = "Doky Settings";
        WindowBranding.Apply(this);
        AppWindow.Resize(new global::Windows.Graphics.SizeInt32(1080, 800));


        var startupEnabled = startupService.IsEnabled();
        Populate(settingsSession.Current with { LaunchAtStartup = startupEnabled });
        InitializeSettingsShell();
        // Keep one Settings window alive instead of allocating a new WinUI/XAML
        // tree and native composition host for every open/close cycle.
        AppWindow.Closing += (_, args) =>
        {
            if (permanentlyClosing || shutdown.IsRequested) return;
            args.Cancel = true;
            AppWindow.Hide();
        };
        PopulateAbout();
        badges.Changed += NotificationsChanged;
        UpdateNotificationStatus();
        RecoveryModeStatusText.Text = safeMode
            ? "Safe Mode is active. Taskbar suppression, Doky Win-key interception, and Hover Wave are disabled for this session."
            : "Normal mode is active.";
        ResumeTaskbarButton.IsEnabled = !safeMode;
        SetStatus("Settings loaded.", success: true);
        Closed += (_, _) =>
        {
            closed = true;
            badges.Changed -= NotificationsChanged;
            updateLifetime.Cancel();
            updateLifetime.Dispose();
        };
    }

    public void ClosePermanently()
    {
        permanentlyClosing = true;
        Close();
    }

    public void ShowCentered(nint owner)
    {
        var area = WindowsMonitorService.GetWorkAreaForWindow(owner);
        var size = AppWindow.Size;
        AppWindow.Move(new global::Windows.Graphics.PointInt32(
            area.X + (area.Width - size.Width) / 2,
            area.Y + (area.Height - size.Height) / 2));
        AppWindow.Show();
        Activate();
        WindowsMonitorService.BringWindowToFront(WinRT.Interop.WindowNative.GetWindowHandle(this));
    }

    private void ConfigureNumberFormatting()
    {
        SetNumberFormat(IconSizeBox, 0);
        SetNumberFormat(IconSpacingBox, 0);
        SetNumberFormat(BottomMarginBox, 0);
        SetNumberFormat(MagnificationScaleBox, 2);
        SetNumberFormat(AutoHideDelayBox, 2);
        SetNumberFormat(PeekDelayBox, 2);
    }

    private static void SetNumberFormat(NumberBox box, int decimals)
    {
        box.NumberFormatter = new global::Windows.Globalization.NumberFormatting.DecimalFormatter
        {
            IntegerDigits = 1,
            FractionDigits = decimals,
            IsGrouped = false,
            NumberRounder = new global::Windows.Globalization.NumberFormatting.IncrementNumberRounder
            {
                Increment = Math.Pow(10, -decimals),
                RoundingAlgorithm = global::Windows.Globalization.NumberFormatting.RoundingAlgorithm.RoundHalfUp
            }
        };
    }

    private void Populate(GlassDockSettings settings)
    {
        populating = true;

        NativeVolumeOsdToggle.IsOn = settings.SuppressNativeVolumeOsd;

        if (!glassDirty) LoadGlassDraft(settings);
        DockAppearanceModeBox.SelectedIndex = (int)glassDraft.Mode;
        UpdateDockAppearanceDescription(glassDraft.Mode);

        DockDisplayModeBox.SelectedIndex = (int)settings.DockDisplayMode;
        BottomMarginBox.Value = settings.BottomMargin;
        AutoHideDelayBox.Value = settings.AutoHideDelayMilliseconds / 1000d;
        PeekDelayBox.Value = settings.PeekDelayMilliseconds / 1000d;
        IconSizeBox.Value = settings.IconSize;
        MagnificationScaleBox.Value = settings.MagnificationScale;
        IconSpacingBox.Value = settings.IconSpacing;
        CircularHighlightsToggle.IsOn = glassDraft.NativeHighlights;
        ClearCircularHighlightsToggle.IsOn = glassDraft.ClearHighlights;
        DockSizeBox.SelectedIndex = settings.DockSize switch { .8 => 1, 1 => 2, _ => 0 };
        PinnedPlacementBox.SelectedIndex = (int)settings.PinnedPlacement;
        FloatingDockGapBox.Value = settings.FloatingDockGap;
        HoverWaveToggle.IsOn = settings.HoverWaveEnabled;
        HoverToExpandOnlyToggle.IsOn = settings.HoverToExpandOnly;
        PinDockToggle.IsOn = settings.PinDock;
        NotificationBadgesToggle.IsOn = settings.NotificationBadgesEnabled;
        NotificationAccessButton.IsEnabled = settings.NotificationBadgesEnabled;
        LaunchAtStartupToggle.IsOn = settings.LaunchAtStartup;
        UpdateBehaviorControlAvailability();
        populating = false;
    }

    private async void NotificationBadgesToggleToggled(object sender, RoutedEventArgs e)
    {
        if (populating || saving || closed || shutdown.IsRequested)
            return;

        var desired = NotificationBadgesToggle.IsOn;
        var edited = settingsSession.CreateNotificationBadgesUpdate(desired);

        saving = true;
        ApplyButton.IsEnabled = false;
        NotificationBadgesToggle.IsEnabled = false;
        NotificationAccessButton.IsEnabled = false;

        try
        {
            await settingsStore.SaveAsync(edited, shutdown.CancellationToken);
            if (closed || shutdown.IsRequested)
                return;

            if (desired)
                await badges.StartAsync(requestPermission: true);
            else
                badges.Stop();

            settingsSession.Replace(edited);
            UpdateNotificationStatus();
            SetStatus(desired
                ? "Notification badges enabled. Windows notification access was requested."
                : "Notification badges disabled.",
                success: true);
        }
        catch (OperationCanceledException) when (shutdown.IsRequested)
        {
        }
        catch (Exception error)
        {
            if (!closed)
            {
                populating = true;
                NotificationBadgesToggle.IsOn = settingsSession.Current.NotificationBadgesEnabled;
                populating = false;
                UpdateNotificationStatus();
                SetStatus($"Notification badge setting could not be saved: {error.Message}", success: false);
            }
        }
        finally
        {
            saving = false;
            if (!closed && !shutdown.IsRequested)
            {
                ApplyButton.IsEnabled = true;
                NotificationBadgesToggle.IsEnabled = true;
                NotificationAccessButton.IsEnabled = NotificationBadgesToggle.IsOn;
            }
        }
    }

    private async void RequestNotificationAccessClick(object sender, RoutedEventArgs e)
    {
        if (closed || shutdown.IsRequested || saving || !NotificationBadgesToggle.IsOn)
            return;

        NotificationAccessButton.IsEnabled = false;
        NotificationStatusText.Text = "Requesting Windows notification access…";
        try
        {
            await badges.StartAsync(requestPermission: true);
            UpdateNotificationStatus();
            SetStatus(badges.Status, success: badges.Status.Contains("enabled", StringComparison.OrdinalIgnoreCase));
        }
        catch (Exception error)
        {
            if (!closed)
            {
                NotificationStatusText.Text = $"Could not request notification access: {error.Message}";
                SetStatus("Windows notification access could not be requested.", success: false);
            }
        }
        finally
        {
            if (!closed && !shutdown.IsRequested)
                NotificationAccessButton.IsEnabled = NotificationBadgesToggle.IsOn;
        }
    }

    private void NotificationsChanged(object? sender, EventArgs e)
    {
        if (closed) return;
        if (DispatcherQueue.HasThreadAccess)
            UpdateNotificationStatus();
        else
            DispatcherQueue.TryEnqueue(UpdateNotificationStatus);
    }

    private void UpdateNotificationStatus()
    {
        if (closed) return;
        NotificationStatusText.Text = badges.Status;
        NotificationAccessButton.IsEnabled = NotificationBadgesToggle.IsOn && !saving;
    }

    private async void PinDockToggleToggled(object sender, RoutedEventArgs e)
    {
        if (populating || saving || closed || shutdown.IsRequested)
            return;

        UpdateBehaviorControlAvailability();
        var desired = PinDockToggle.IsOn;
        var edited = GlassDockSettings.Normalize(settingsSession.Current with { PinDock = desired });

        saving = true;
        ApplyButton.IsEnabled = false;
        PinDockToggle.IsEnabled = false;

        try
        {
            await settingsStore.SaveAsync(edited, shutdown.CancellationToken);
            if (closed || shutdown.IsRequested)
                return;

            settingsSession.Replace(edited);
            SetStatus(desired
                ? "Pin Dock enabled. Doky is attaching to the bottom edge."
                : "Pin Dock disabled. Doky is returning to its floating position.",
                success: true);
        }
        catch (OperationCanceledException) when (shutdown.IsRequested)
        {
        }
        catch (Exception error)
        {
            if (!closed)
            {
                populating = true;
                PinDockToggle.IsOn = settingsSession.Current.PinDock;
                populating = false;
                UpdateBehaviorControlAvailability();
                SetStatus($"Pin Dock could not be saved: {error.Message}", success: false);
            }
        }
        finally
        {
            saving = false;
            if (!closed && !shutdown.IsRequested)
            {
                ApplyButton.IsEnabled = true;
                PinDockToggle.IsEnabled = true;
            }
        }
    }

    private void UpdateBehaviorControlAvailability()
    {
        var autoHideAvailable = !PinDockToggle.IsOn;
        PinnedPlacementBox.IsEnabled = PinDockToggle.IsOn;
        FloatingDockGapBox.IsEnabled = PinDockToggle.IsOn && PinnedPlacementBox.SelectedIndex == 1;
        AutoHideDelayBox.IsEnabled = autoHideAvailable;
        PeekDelayBox.IsEnabled = autoHideAvailable;
    }

    private void PopulateAbout()
    {
        var version = typeof(SettingsWindow).Assembly.GetName().Version;
        VersionText.Text = version is null
            ? "Version unavailable"
            : $"Version {version.Major}.{version.Minor}.{version.Build}";
        SettingsPathText.Text = settingsStore.SettingsFilePath;
        try
        {
            updates = new ManualUpdateService();
            if (updates.CurrentVersion is { } installedVersion)
                VersionText.Text = $"Version {installedVersion}";
            else
                VersionText.Text += " (development build)";
            CheckUpdatesButton.IsEnabled = updates.CanUpdate;
            if (!updates.CanUpdate)
                UpdateStatusText.Text = "Updates are available in the installed Doky build. Development builds are not updated.";
        }
        catch (Exception)
        {
            CheckUpdatesButton.IsEnabled = false;
            UpdateStatusText.Text = "Update information is unavailable. Reopen Settings to retry.";
        }
    }

    private async void RequestCaptureBorderPermissionClick(object sender, RoutedEventArgs e)
    {
        CaptureBorderPermissionButton.IsEnabled = false;
        CaptureBorderStatusText.Text = "Requesting Windows permission…";
        try
        {
            var result = await CaptureBorderPermission.RequestAsync();
            if (!closed) CaptureBorderStatusText.Text = result;
        }
        finally { if (!closed) CaptureBorderPermissionButton.IsEnabled = true; }
    }

    private async void CheckUpdatesClick(object sender, RoutedEventArgs e)
    {
        if (closed || shutdown.IsRequested || updateBusy || updates is null) return;
        SetUpdateBusy(true, "Checking for updates…");
        InstallUpdateButton.Visibility = Visibility.Collapsed;
        UpdateProgress.IsIndeterminate = true;
        try
        {
            await updates.CheckAsync(updateLifetime.Token);
            if (closed || shutdown.IsRequested) return;
            UpdateStatusText.Text = updates.AvailableVersion is { } version
                ? $"Doky {version} is available."
                : "Doky is up to date.";
            InstallUpdateButton.Visibility = updates.AvailableVersion is null ? Visibility.Collapsed : Visibility.Visible;
        }
        catch (OperationCanceledException) when (closed || shutdown.IsRequested) { }
        catch (TimeoutException)
        {
            if (!closed && !shutdown.IsRequested)
                UpdateStatusText.Text = "GitHub did not respond within 15 seconds. Please try again.";
        }
        catch (Exception)
        {
            if (!closed && !shutdown.IsRequested)
                UpdateStatusText.Text = "Could not check for updates. Check your connection and try again.";
        }
        finally { if (!closed && !shutdown.IsRequested) SetUpdateBusy(false); }
    }

    private async void InstallUpdateClick(object sender, RoutedEventArgs e)
    {
        if (closed || shutdown.IsRequested || updateBusy || updates is null) return;
        SetUpdateBusy(true, "Downloading update…");
        UpdateProgress.IsIndeterminate = false;
        UpdateProgress.Value = 0;
        var progress = new Progress<int>(value =>
        {
            if (closed || shutdown.IsRequested || !updateBusy) return;
            UpdateProgress.Value = Math.Clamp(value, 0, 100);
            UpdateStatusText.Text = $"Downloading update… {Math.Clamp(value, 0, 100)}%";
        });
        try
        {
            await updates.DownloadAsync(value => ((IProgress<int>)progress).Report(value), updateLifetime.Token);
            if (closed || shutdown.IsRequested) return;
            UpdateStatusText.Text = "Installing update… Doky will restart.";
            updates.ApplyAfterExit(safeMode);
            exitGlassDock();
        }
        catch (OperationCanceledException) when (closed || shutdown.IsRequested) { }
        catch (Exception)
        {
            if (!closed && !shutdown.IsRequested)
                UpdateStatusText.Text = "Could not install the update. Try Update again or check for updates.";
        }
        finally { if (!closed && !shutdown.IsRequested) SetUpdateBusy(false); }
    }

    private void SetUpdateBusy(bool busy, string? message = null)
    {
        updateBusy = busy;
        CheckUpdatesButton.IsEnabled = !busy && updates?.CanUpdate == true;
        InstallUpdateButton.IsEnabled = !busy;
        UpdateProgress.Visibility = busy ? Visibility.Visible : Visibility.Collapsed;
        if (message is not null) UpdateStatusText.Text = message;
    }

    private DockAppearanceMode SelectedDockAppearance =>
        Enum.IsDefined((DockAppearanceMode)DockAppearanceModeBox.SelectedIndex)
            ? (DockAppearanceMode)DockAppearanceModeBox.SelectedIndex
            : DockAppearanceMode.Dark;

    private void DockAppearanceChanged(object sender, SelectionChangedEventArgs e)
    {
        if (populating || refreshingGlass || !editingReady || saving || closed) return;
        SelectBuiltInGlass(SelectedDockAppearance);
    }

    private void UpdateDockAppearanceDescription(DockAppearanceMode mode)
    {
        DockAppearanceDescription.Text = mode switch
        {
            DockAppearanceMode.Light => "Soft off-white solid surface with no glass effect.",
            DockAppearanceMode.Dark => "Deep charcoal solid surface with no glass effect.",
            DockAppearanceMode.Frosted => "Soft blurred glass with stronger diffusion and an opaque feel.",
            DockAppearanceMode.Acrylic => "Lighter acrylic-style glass with more background visibility.",
            DockAppearanceMode.Clear => "The clearest glass preset with minimal blur and higher transparency.",
            _ => "Choose the material used by the main dock."
        };
    }

    private DockDisplayMode SelectedDisplayMode =>
        DockDisplayModeBox.SelectedIndex switch
        {
            (int)DockDisplayMode.Pointer => DockDisplayMode.Pointer,
            (int)DockDisplayMode.Foreground => DockDisplayMode.Foreground,
            (int)DockDisplayMode.AllDisplays => DockDisplayMode.AllDisplays,
            _ => DockDisplayMode.Primary
        };

    private void NavigationClick(object sender, RoutedEventArgs e)
    {
        if (sender is Button button && button.Tag is string page)
            ShowSettingsPage(page);
    }

    private void ShowSettingsPage(string page)
    {
        if (!navigation.ContainsKey(page)) return;
        selectedPage = page;
        StickyGlassPreview.Visibility = page == "Appearance" ? Visibility.Visible : Visibility.Collapsed;
        foreach (var definition in SettingsCatalog.Pages)
        {
            if (SettingsRoot.FindName(definition.Id + "Page") is FrameworkElement content)
                content.Visibility = definition.Id == page ? Visibility.Visible : Visibility.Collapsed;
            SetNavigationState(navigation[definition.Id], definition.Id == page);
        }
        PageScroll.ChangeView(null, 0, null, true);
        if (page == "Apps") RefreshMissingPins();
        if (page == "Utilities") RefreshUtilitiesPage();
        if (page == "System")
            HelperStatusText.Text = "The helper is managed by the active dock session. Settings does not have a live helper connection status; use recovery actions below if elevated apps do not respond.";
    }

    private void RefreshMissingPinsClick(object sender, RoutedEventArgs e)
    {
        applicationService.RequestRefresh();
        RefreshMissingPins();
    }

    private void RefreshMissingPins()
    {
        if (closed) return;
        MissingPinsList.Children.Clear();
        var missing = applicationService.GetRecoverablePins();
        MissingPinsStatusText.Text = missing.Count == 0
            ? "No unavailable custom shortcuts. If a target is restored, Doky shows it again automatically."
            : $"{missing.Count} unavailable shortcut(s) saved for recovery.";
        foreach (var pin in missing)
        {
            var row = new StackPanel { Spacing = 6 };
            row.Children.Add(new TextBlock
            {
                Text = pin.Name,
                FontWeight = new global::Windows.UI.Text.FontWeight { Weight = 600 },
                TextTrimming = TextTrimming.CharacterEllipsis
            });
            row.Children.Add(new TextBlock
            {
                Text = pin.Target,
                FontSize = 11,
                Foreground = (Brush)SettingsRoot.Resources["SecondaryBrush"],
                TextTrimming = TextTrimming.CharacterEllipsis
            });
            var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
            var toggle = new Button { Content = pin.Hidden ? "Show in dock" : "Hide from dock" };
            toggle.Click += (_, _) =>
            {
                if (applicationService.SetMissingPinVisible(pin.Id, pin.Hidden)) RefreshMissingPins();
            };
            var forget = new Button { Content = "Remove saved pin" };
            forget.Click += (_, _) =>
            {
                if (applicationService.RemoveRecoverablePin(pin.Id)) RefreshMissingPins();
            };
            actions.Children.Add(toggle);
            actions.Children.Add(forget);
            row.Children.Add(actions);
            row.Children.Add(new Microsoft.UI.Xaml.Shapes.Rectangle
            {
                Height = 1,
                Fill = (Brush)SettingsRoot.Resources["DividerBrush"]
            });
            MissingPinsList.Children.Add(row);
        }
    }

    private void SetNavigationState(Button button, bool selected)
    {
        button.Background = selected ? Brush("SelectionBrush") : new SolidColorBrush(Colors.Transparent);
        button.Foreground = Brush("PrimaryBrush");
        button.Resources["ButtonBackgroundPointerOver"] = Brush("CardBrush");
        button.Resources["ButtonForegroundPointerOver"] = Brush("PrimaryBrush");
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetItemStatus(button, selected ? "Selected" : "");
    }

    private async void ResetClick(object sender, RoutedEventArgs e)
    {
        if (!await ConfirmResetAsync("editable preferences")) return;
        var defaults = settingsSession.CreateDefaultEditableSettings();
        glassDirty = false;
        Populate(defaults);
        ShowSettingsPage("Appearance");
        ApplyClick(this, new RoutedEventArgs());
    }

    private async void ApplyClick(object sender, RoutedEventArgs e)
    {
        if (saving || closed || shutdown.IsRequested)
            return;

        var applyVisuals = !savingNonVisual;
        savingNonVisual = false;
        saving = true;
        ApplyButton.IsEnabled = false;
        SetStatus("Saving…", success: true);

        var startupRegistrationChanged = false;
        var previousStartupRegistration = false;

        try
        {
            var current = settingsSession.Current;
            var desiredStartup = LaunchAtStartupToggle.IsOn;
            previousStartupRegistration = startupService.IsEnabled();

            if (previousStartupRegistration != desiredStartup)
            {
                startupService.SetEnabled(desiredStartup);
                startupRegistrationChanged = true;
            }

            var edited = settingsSession.CreateDockSettingsUpdate(
                BottomMarginBox.Value,
                ToMilliseconds(
                    AutoHideDelayBox.Value,
                    current.AutoHideDelayMilliseconds),
                ToMilliseconds(
                    PeekDelayBox.Value,
                    current.PeekDelayMilliseconds),
                current.GlassMaterialMode,
                IconSizeBox.Value,
                MagnificationScaleBox.Value,
                IconSpacingBox.Value,
                current.GlassBlurAmount,
                current.DockOpacity,
                current.BorderThickness,
                current.BorderOpacity,
                SelectedDisplayMode,
                HoverWaveToggle.IsOn,
                PinDockToggle.IsOn,
                HoverToExpandOnlyToggle.IsOn) with
            {
                DockAppearanceMode = current.DockAppearanceMode,
                LaunchAtStartup = desiredStartup,
                NotificationBadgesEnabled = NotificationBadgesToggle.IsOn,
                ClearRefractionStrength = current.ClearRefractionStrength,
                SpecularHighlightAngle = current.SpecularHighlightAngle,
                CircularHighlightsEnabled = current.CircularHighlightsEnabled,
                ClearCircularHighlightsEnabled = current.ClearCircularHighlightsEnabled,
                DockSize = DockSizeBox.SelectedIndex switch { 1 => .8, 2 => 1, _ => .70 },
                PinnedPlacement = (GlassDock.Core.Desktop.PinnedDockPlacement)Math.Max(0, PinnedPlacementBox.SelectedIndex),
                FloatingDockGap = FloatingDockGapBox.Value
            };

            if (applyVisuals) edited = ApplyGlassDraft(edited);
            await settingsStore.SaveAsync(edited, shutdown.CancellationToken);
            if (closed || shutdown.IsRequested)
                return;

            if (applyVisuals) glassDirty = false;
            settingsSession.Replace(edited);
            Populate(settingsSession.Current);
            SetStatus(applyVisuals ? "Saved. Changes are active now." : "Saved. Glass preview changes still need Apply.", success: true);
        }
        catch (OperationCanceledException) when (shutdown.IsRequested)
        {
            if (startupRegistrationChanged)
                TryRestoreStartupRegistration(previousStartupRegistration);
        }
        catch (Exception error)
        {
            if (startupRegistrationChanged)
                TryRestoreStartupRegistration(previousStartupRegistration);

            if (!closed)
            {
                Populate(settingsSession.Current);
                ApplySettingsAppearance();
                SetStatus($"Settings could not be saved: {error.Message}", success: false);
            }
        }
        finally
        {
            saving = false;
            if (!closed && !shutdown.IsRequested)
                ApplyButton.IsEnabled = true;
        }
    }

    private void TryRestoreStartupRegistration(bool enabled)
    {
        try { startupService.SetEnabled(enabled); }
        catch (Exception error) when (
            error is UnauthorizedAccessException or
            IOException or
            InvalidOperationException or
            System.Security.SecurityException)
        {
        }
    }

    private void RestoreTaskbarClick(object sender, RoutedEventArgs e)
    {
        if (closed || shutdown.IsRequested)
            return;

        restoreTaskbar();
        SetStatus("Windows taskbar restore requested. Suppression is paused for this session.", success: true);
    }

    private void ResumeTaskbarClick(object sender, RoutedEventArgs e)
    {
        if (closed || shutdown.IsRequested)
            return;

        if (safeMode)
        {
            SetStatus("Safe Mode keeps taskbar suppression disabled.", success: false);
            return;
        }

        resumeTaskbar();
        SetStatus("Taskbar suppression resume requested.", success: true);
    }

    private void RestartClick(object sender, RoutedEventArgs e)
    {
        if (closed || shutdown.IsRequested)
            return;

        restartGlassDock();
    }

    private void SafeModeClick(object sender, RoutedEventArgs e)
    {
        if (closed || shutdown.IsRequested)
            return;

        restartSafeMode();
    }

    private async void ResetAppearanceClick(object sender, RoutedEventArgs e)
    {
        if (saving || closed || shutdown.IsRequested)
            return;

        if (!await ConfirmResetAsync("appearance")) return;

        var current = settingsSession.Current;
        var edited = GlassDockSettings.Normalize(current with
        {
            DockAppearanceMode = GlassDockSettings.DefaultDockAppearanceMode,
            GlassMaterialMode = GlassDockSettings.DefaultGlassMaterialMode,
            IconSize = GlassDockSettings.DefaultIconSize,
            MagnificationScale = GlassDockSettings.DefaultMagnificationScale,
            IconSpacing = GlassDockSettings.DefaultIconSpacing,
            GlassBlurAmount = GlassDockSettings.DefaultGlassBlurAmount,
            DockOpacity = GlassDockSettings.DefaultDockOpacity,
            BorderThickness = GlassDockSettings.DefaultBorderThickness,
            BorderOpacity = GlassDockSettings.DefaultBorderOpacity,
            ClearRefractionStrength = GlassDockSettings.DefaultClearRefractionStrength,
            SpecularHighlightAngle = GlassDockSettings.DefaultSpecularHighlightAngle,
            CircularHighlightsEnabled = GlassDockSettings.DefaultCircularHighlightsEnabled,
            ClearCircularHighlightsEnabled = true,
            GlassVisuals = null,
            SelectedCustomGlassPreset = null
        });

        glassDirty = false;
        await SaveRecoverySettingsAsync(edited, "Appearance reset to defaults.");
    }

    private async void ResetPlacementClick(object sender, RoutedEventArgs e)
    {
        if (saving || closed || shutdown.IsRequested)
            return;

        if (!await ConfirmResetAsync("dock placement")) return;

        var current = settingsSession.Current;
        var edited = GlassDockSettings.Normalize(current with
        {
            DockDisplayMode = GlassDockSettings.DefaultDockDisplayMode,
            BottomMargin = GlassDockSettings.DefaultBottomMargin,
            PinDock = GlassDockSettings.DefaultPinDock
        });

        await SaveRecoverySettingsAsync(edited, "Dock placement reset to the primary display defaults.");
    }

    private void ExitClick(object sender, RoutedEventArgs e)
    {
        if (closed || shutdown.IsRequested)
            return;

        exitGlassDock();
    }

    private async Task SaveRecoverySettingsAsync(GlassDockSettings edited, string successMessage)
    {
        saving = true;
        ApplyButton.IsEnabled = false;
        SetStatus("Saving…", success: true);

        try
        {
            await settingsStore.SaveAsync(edited, shutdown.CancellationToken);
            if (closed || shutdown.IsRequested)
                return;

            settingsSession.Replace(edited);
            Populate(settingsSession.Current);
            SetStatus(successMessage, success: true);
        }
        catch (OperationCanceledException) when (shutdown.IsRequested)
        {
        }
        catch (Exception error)
        {
            if (!closed)
                SetStatus($"Settings could not be saved: {error.Message}", success: false);
        }
        finally
        {
            saving = false;
            if (!closed && !shutdown.IsRequested)
                ApplyButton.IsEnabled = true;
        }
    }

    private static int ToMilliseconds(double seconds, int fallback)
    {
        if (!double.IsFinite(seconds))
            return fallback;

        var milliseconds = seconds * 1000;
        if (milliseconds <= int.MinValue)
            return int.MinValue;
        if (milliseconds >= int.MaxValue)
            return int.MaxValue;
        return (int)Math.Round(milliseconds, MidpointRounding.AwayFromZero);
    }

    private void SetStatus(string message, bool success)
    {
        StatusText.Text = message;
        StatusText.Foreground = new SolidColorBrush(success
            ? (settingsSession.Current.DockAppearanceMode == DockAppearanceMode.Light ? ColorHelper.FromArgb(255, 36, 98, 68) : ColorHelper.FromArgb(255, 145, 220, 182))
            : Colors.IndianRed);
    }
}
